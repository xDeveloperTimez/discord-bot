"""
Permission check utilities
"""

import discord
from discord.ext import commands

def is_owner(user: discord.Member) -> bool:
    """Check if user is the server owner"""
    return user == user.guild.owner

def is_admin(user: discord.Member, config) -> bool:
    """Check if user has administrator permissions or admin role"""
    if user.guild_permissions.administrator:
        return True
    
    admin_role_name = config.admin_role
    admin_role = discord.utils.get(user.guild.roles, name=admin_role_name)
    
    if admin_role and admin_role in user.roles:
        return True
    
    return False

def is_moderator(user: discord.Member, config) -> bool:
    """Check if user has moderation permissions or moderator role"""
    # Check if user is admin first
    if is_admin(user, config):
        return True
    
    # Check specific moderation permissions
    perms = user.guild_permissions
    if any([perms.kick_members, perms.ban_members, perms.manage_messages, perms.manage_roles]):
        return True
    
    # Check moderator role
    mod_role_name = config.mod_role
    mod_role = discord.utils.get(user.guild.roles, name=mod_role_name)
    
    if mod_role and mod_role in user.roles:
        return True
    
    return False

def can_execute_action(executor: discord.Member, target: discord.Member) -> bool:
    """Check if executor can perform actions on target based on role hierarchy"""
    if executor == target.guild.owner:
        return True
    
    if target == target.guild.owner:
        return False
    
    return executor.top_role > target.top_role

def bot_has_permissions(**perms) -> bool:
    """Decorator to check if bot has required permissions"""
    def predicate(ctx):
        if not ctx.guild:
            return False
        
        bot_perms = ctx.guild.me.guild_permissions
        missing = [perm for perm, value in perms.items() if getattr(bot_perms, perm) != value]
        
        if missing:
            raise commands.BotMissingPermissions(missing)
        
        return True
    
    return commands.check(predicate)

def user_has_permissions(**perms) -> bool:
    """Decorator to check if user has required permissions"""
    def predicate(ctx):
        if not ctx.guild:
            return False
        
        user_perms = ctx.author.guild_permissions
        missing = [perm for perm, value in perms.items() if getattr(user_perms, perm) != value]
        
        if missing:
            raise commands.MissingPermissions(missing)
        
        return True
    
    return commands.check(predicate)

def is_mod_or_admin():
    """Decorator to check if user is moderator or admin"""
    def predicate(ctx):
        if not ctx.guild:
            return False
        
        return is_moderator(ctx.author, ctx.bot.config)
    
    return commands.check(predicate)

def is_admin_only():
    """Decorator to check if user is admin only"""
    def predicate(ctx):
        if not ctx.guild:
            return False
        
        return is_admin(ctx.author, ctx.bot.config)
    
    return commands.check(predicate)

def has_higher_role(executor: discord.Member, target: discord.Member) -> bool:
    """Check if executor has a higher role than target"""
    if executor == target.guild.owner:
        return True
    
    if target == target.guild.owner:
        return False
    
    return executor.top_role > target.top_role

def can_modify_role(member: discord.Member, role: discord.Role) -> bool:
    """Check if member can modify a specific role"""
    if member == member.guild.owner:
        return True
    
    if not member.guild_permissions.manage_roles:
        return False
    
    return member.top_role > role

def bot_can_modify_role(guild: discord.Guild, role: discord.Role) -> bool:
    """Check if bot can modify a specific role"""
    bot_member = guild.me
    
    if not bot_member.guild_permissions.manage_roles:
        return False
    
    return bot_member.top_role > role

class InsufficientPermissions(commands.CheckFailure):
    """Custom exception for insufficient permissions"""
    def __init__(self, message="You don't have permission to use this command."):
        self.message = message
        super().__init__(message)

class HierarchyError(commands.CheckFailure):
    """Custom exception for role hierarchy errors"""
    def __init__(self, message="Role hierarchy prevents this action."):
        self.message = message
        super().__init__(message)

class BotHierarchyError(commands.CheckFailure):
    """Custom exception for bot role hierarchy errors"""
    def __init__(self, message="Bot role hierarchy prevents this action."):
        self.message = message
        super().__init__(message)
