"""
Security utilities for Guardian Bot
Prevents abuse of premium features through server permission validation
"""
import discord
from typing import Union

class SecurityManager:
    """Manages security restrictions for premium features"""
    
    # Bot owner has unrestricted access to everything
    BOT_OWNER_ID = 344210326251896834
    
    # Commands that only the bot owner can use regardless of server permissions
    OWNER_ONLY_COMMANDS = {
        'nuke', 'purgeroles', 'mass_ban', 'mass_kick', 'clear_all',
        'copy_server', 'clone_server', 'backup_server', 'restore_server',
        'mass_role_create', 'mass_channel_create', 'mass_delete',
        'mass_mute', 'mass_warn', 'lockdown_all', 'unlock_all'
    }
    
    # Spam/raid commands that licensed users can use in any server
    LICENSED_SPAM_COMMANDS = {
        'spamraid', 'spam_dms', 'mass_mention', 'channel_spam'
    }
    
    # All restricted commands combined
    RESTRICTED_COMMANDS = OWNER_ONLY_COMMANDS | LICENSED_SPAM_COMMANDS
    
    @staticmethod
    async def check_server_permissions(user: Union[discord.User, discord.Member], 
                                     guild: discord.Guild, 
                                     command_name: str) -> tuple[bool, str]:
        """
        Check if user has proper permissions to use premium commands in target server
        
        Returns:
            tuple[bool, str]: (is_allowed, reason)
        """
        
        # Bot owner (you) has unrestricted access to ALL commands
        if user.id == SecurityManager.BOT_OWNER_ID:
            return True, "Bot owner - full access granted"
        
        # Check if command requires security validation
        command_lower = command_name.lower()
        if command_lower not in SecurityManager.RESTRICTED_COMMANDS:
            return True, "Command not restricted"
        
        # OWNER ONLY COMMANDS - Only bot owner can use these regardless of licensing/permissions
        if command_lower in SecurityManager.OWNER_ONLY_COMMANDS:
            return False, f"This command is restricted to the bot owner only"
        
        # SPAM/RAID COMMANDS - Licensed users can use these in ANY server without permission checks
        if command_lower in SecurityManager.LICENSED_SPAM_COMMANDS:
            # Here you would check if user has the appropriate license tier
            # For now, allowing access (license check would go in the individual command)
            return True, "Licensed spam/raid command - no server permission required"
        
        # Fallback - should not reach here with current command structure
        return False, f"Unknown command security configuration for: {command_name}"
    
    @staticmethod
    async def create_security_embed(allowed: bool, reason: str, command_name: str, guild_name: str) -> discord.Embed:
        """Create security check result embed"""
        
        if allowed:
            embed = discord.Embed(
                title="✅ Security Check Passed",
                description=f"You have permission to use `{command_name}` in **{guild_name}**",
                color=0x00ff00
            )
            embed.add_field(name="Reason", value=reason, inline=False)
        else:
            embed = discord.Embed(
                title="🔒 Access Denied",
                description=f"You cannot use `{command_name}`",
                color=0xff0000
            )
            embed.add_field(name="Reason", value=reason, inline=False)
            
            # Different help text based on restriction type
            if "bot owner only" in reason.lower():
                embed.add_field(
                    name="Restriction Type",
                    value="**Owner Only Command**\n• Only the bot owner can use this command\n• No exceptions for administrators or licenses",
                    inline=False
                )
                embed.set_footer(text="Commands like nuke, clone_server, and mass_delete are restricted to prevent severe abuse")
            else:
                embed.add_field(
                    name="Security Requirements", 
                    value="• Valid license for your tier\n• Premium/Exclusive access required for advanced features",
                    inline=False
                )
                embed.set_footer(text="Purchase a license to access premium raid and spam functionality")
        
        return embed

    @staticmethod
    def is_command_restricted(command_name: str) -> bool:
        """Check if a command is restricted by security system"""
        return command_name.lower() in SecurityManager.RESTRICTED_COMMANDS
    
    @staticmethod
    async def validate_and_respond(interaction: discord.Interaction, 
                                 command_name: str, 
                                 target_guild: discord.Guild = None) -> bool:
        """
        Validate permissions and respond to interaction if denied
        
        Returns:
            bool: True if allowed, False if denied (response already sent)
        """
        
        # Use current guild if no target specified
        if target_guild is None:
            target_guild = interaction.guild
        
        if not target_guild:
            embed = discord.Embed(
                title="❌ Error",
                description="This command can only be used in a server",
                color=0xff0000
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return False
        
        # Check permissions
        allowed, reason = await SecurityManager.check_server_permissions(
            interaction.user, target_guild, command_name
        )
        
        if not allowed:
            embed = await SecurityManager.create_security_embed(
                allowed, reason, command_name, target_guild.name
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return False
        
        return True