"""
Helper utility functions
"""

import re
from datetime import timedelta

def parse_time(time_str: str) -> int:
    """
    Parse a time string and return seconds
    Supports formats like: 30s, 5m, 2h, 1d, 1w
    """
    if not time_str:
        return None
    
    # Remove spaces and convert to lowercase
    time_str = time_str.replace(" ", "").lower()
    
    # Regex to match number and unit
    match = re.match(r'^(\d+)([smhdw])$', time_str)
    if not match:
        return None
    
    amount = int(match.group(1))
    unit = match.group(2)
    
    multipliers = {
        's': 1,          # seconds
        'm': 60,         # minutes
        'h': 3600,       # hours
        'd': 86400,      # days
        'w': 604800      # weeks
    }
    
    return amount * multipliers.get(unit, 0)

def format_time(seconds: int) -> str:
    """
    Format seconds into a readable time string
    """
    if not seconds:
        return "Unknown"
    
    delta = timedelta(seconds=seconds)
    days = delta.days
    hours, remainder = divmod(delta.seconds, 3600)
    minutes, secs = divmod(remainder, 60)
    
    parts = []
    if days:
        parts.append(f"{days} day{'s' if days != 1 else ''}")
    if hours:
        parts.append(f"{hours} hour{'s' if hours != 1 else ''}")
    if minutes:
        parts.append(f"{minutes} minute{'s' if minutes != 1 else ''}")
    if secs and not (days or hours):
        parts.append(f"{secs} second{'s' if secs != 1 else ''}")
    
    if not parts:
        return "0 seconds"
    
    return ", ".join(parts)

def truncate_text(text: str, max_length: int = 1000) -> str:
    """
    Truncate text to a maximum length
    """
    if len(text) <= max_length:
        return text
    return text[:max_length-3] + "..."

def format_list(items: list, max_items: int = 10, separator: str = ", ") -> str:
    """
    Format a list into a string with optional truncation
    """
    if not items:
        return "None"
    
    if len(items) <= max_items:
        return separator.join(str(item) for item in items)
    
    shown_items = items[:max_items]
    remaining = len(items) - max_items
    
    result = separator.join(str(item) for item in shown_items)
    result += f" and {remaining} more..."
    
    return result

def get_member_status(member) -> str:
    """
    Get a formatted status string for a member
    """
    status_emojis = {
        'online': '🟢',
        'idle': '🟡',
        'dnd': '🔴',
        'offline': '⚫'
    }
    
    status = str(member.status)
    emoji = status_emojis.get(status, '❓')
    
    return f"{emoji} {status.title()}"

def create_progress_bar(current: int, maximum: int, length: int = 10) -> str:
    """
    Create a simple text progress bar
    """
    if maximum == 0:
        return "▱" * length
    
    filled = int((current / maximum) * length)
    return "▰" * filled + "▱" * (length - filled)

def format_permissions(permissions) -> list:
    """
    Format Discord permissions into a readable list
    """
    permission_names = {
        'administrator': 'Administrator',
        'manage_guild': 'Manage Server',
        'manage_roles': 'Manage Roles',
        'manage_channels': 'Manage Channels',
        'kick_members': 'Kick Members',
        'ban_members': 'Ban Members',
        'manage_messages': 'Manage Messages',
        'manage_webhooks': 'Manage Webhooks',
        'manage_emojis': 'Manage Emojis',
        'view_audit_log': 'View Audit Log',
        'priority_speaker': 'Priority Speaker',
        'stream': 'Video',
        'connect': 'Connect',
        'speak': 'Speak',
        'mute_members': 'Mute Members',
        'deafen_members': 'Deafen Members',
        'move_members': 'Move Members',
        'use_voice_activation': 'Use Voice Activity',
        'change_nickname': 'Change Nickname',
        'manage_nicknames': 'Manage Nicknames',
        'external_emojis': 'Use External Emojis',
        'view_guild_insights': 'View Server Insights',
        'mention_everyone': 'Mention Everyone',
        'use_slash_commands': 'Use Slash Commands',
        'request_to_speak': 'Request to Speak',
        'manage_events': 'Manage Events',
        'manage_threads': 'Manage Threads',
        'create_public_threads': 'Create Public Threads',
        'create_private_threads': 'Create Private Threads',
        'send_messages_in_threads': 'Send Messages in Threads',
        'use_external_stickers': 'Use External Stickers',
        'moderate_members': 'Timeout Members'
    }
    
    enabled_perms = []
    for perm, value in permissions:
        if value and perm in permission_names:
            enabled_perms.append(permission_names[perm])
    
    return enabled_perms

def escape_markdown(text: str) -> str:
    """
    Escape Discord markdown characters
    """
    markdown_chars = ['*', '_', '`', '~', '|', '\\']
    
    for char in markdown_chars:
        text = text.replace(char, f'\\{char}')
    
    return text

def clean_content(content: str) -> str:
    """
    Clean message content for logging
    """
    # Remove mentions and replace with readable text
    content = re.sub(r'<@!?(\d+)>', r'@User(\1)', content)
    content = re.sub(r'<@&(\d+)>', r'@Role(\1)', content)
    content = re.sub(r'<#(\d+)>', r'#Channel(\1)', content)
    
    # Remove custom emojis
    content = re.sub(r'<a?:\w+:\d+>', '[Emoji]', content)
    
    return content
