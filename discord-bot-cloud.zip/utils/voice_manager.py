"""
Voice connection manager to handle Discord voice connection stability issues
"""

import discord
import asyncio
import logging
from typing import Optional

logger = logging.getLogger(__name__)

class VoiceManager:
    """Manages stable voice connections with retry logic"""
    
    @staticmethod
    async def connect_with_retry(channel: discord.VoiceChannel, max_retries: int = 5) -> discord.VoiceClient:
        """
        Connect to voice channel with enhanced retry logic for WebSocket 4006 errors
        """
        guild = channel.guild
        
        # Force disconnect any existing connections
        if guild.voice_client:
            try:
                await guild.voice_client.disconnect(force=True)
                await asyncio.sleep(3)  # Extended cleanup time
            except:
                pass
        
        for attempt in range(max_retries):
            try:
                logger.info(f"Voice connection attempt {attempt + 1}/{max_retries} for {channel.name}")
                
                # Extended timeout for problematic connections
                voice_client = await asyncio.wait_for(
                    channel.connect(reconnect=False, cls=discord.VoiceClient),
                    timeout=45.0
                )
                
                # Extended stability check
                await asyncio.sleep(2)
                
                if voice_client and voice_client.is_connected():
                    logger.info(f"✅ Successfully connected to {channel.name}")
                    return voice_client
                else:
                    logger.warning(f"⚠️ Connection unstable for {channel.name}")
                    if voice_client:
                        await voice_client.disconnect(force=True)
                    
            except asyncio.TimeoutError:
                logger.warning(f"🕐 Connection timeout attempt {attempt + 1}")
                await asyncio.sleep(min(10, 3 + attempt * 2))  # Longer backoff
                
            except discord.ConnectionClosed as e:
                if e.code == 4006:
                    logger.warning(f"🔒 WebSocket 4006 (auth) error attempt {attempt + 1}")
                    await asyncio.sleep(min(15, 5 + attempt * 3))  # Extended backoff for auth errors
                else:
                    logger.warning(f"🔌 WebSocket error {e.code} attempt {attempt + 1}")
                    await asyncio.sleep(min(10, 3 + attempt * 2))
                    
            except discord.ClientException as e:
                logger.warning(f"⚡ Discord client error attempt {attempt + 1}: {e}")
                await asyncio.sleep(min(10, 3 + attempt * 2))
                
            except Exception as e:
                logger.error(f"❌ Unexpected error attempt {attempt + 1}: {e}")
                await asyncio.sleep(min(10, 3 + attempt * 2))
        
        raise discord.ClientException(f"Failed to connect to {channel.name} after {max_retries} attempts with WebSocket errors")
    
    @staticmethod
    async def emergency_connect(channel: discord.VoiceChannel) -> Optional[discord.VoiceClient]:
        """
        Emergency fallback connection method for persistent WebSocket 4006 errors
        """
        try:
            logger.info(f"🚨 Attempting emergency connection to {channel.name}")
            
            # Force clean slate
            guild = channel.guild
            if guild.voice_client:
                await guild.voice_client.disconnect(force=True)
                await asyncio.sleep(5)  # Extended cleanup
            
            # Single attempt with minimal settings
            voice_client = await channel.connect(
                reconnect=False,
                timeout=60.0,
                cls=discord.VoiceClient
            )
            
            if voice_client:
                logger.info(f"✅ Emergency connection successful to {channel.name}")
                return voice_client
            else:
                logger.error(f"❌ Emergency connection failed to {channel.name}")
                return None
                
        except Exception as e:
            logger.error(f"💥 Emergency connection error: {e}")
            return None
    
    @staticmethod
    async def safe_disconnect(voice_client: discord.VoiceClient) -> bool:
        """
        Safely disconnect voice client
        """
        if not voice_client:
            return True
            
        try:
            await voice_client.disconnect(force=True)
            await asyncio.sleep(1)  # Allow cleanup
            return True
        except Exception as e:
            logger.error(f"Error disconnecting voice client: {e}")
            return False
    
    @staticmethod
    async def move_to_channel(voice_client: discord.VoiceClient, channel: discord.VoiceChannel) -> bool:
        """
        Move voice client to different channel safely
        """
        try:
            await voice_client.move_to(channel)
            await asyncio.sleep(1)  # Allow connection stabilization
            return voice_client.is_connected()
        except Exception as e:
            logger.error(f"Error moving to channel {channel.name}: {e}")
            return False