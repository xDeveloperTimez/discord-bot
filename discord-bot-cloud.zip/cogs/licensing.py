"""
Comprehensive licensing system for Discord bot sales
Features: Key redemption, payment integration, support tickets, admin panel
"""
import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import aiohttp
import json
from datetime import datetime, timedelta
from typing import Dict, List


class LicenseView(discord.ui.View):
    """Interactive license information view"""
    def __init__(self, license_data: Dict):
        super().__init__(timeout=300)
        self.license_data = license_data

    @discord.ui.button(label="📊 Usage Stats", style=discord.ButtonStyle.secondary)
    async def usage_stats(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Show detailed usage statistics"""
        embed = discord.Embed(
            title="📊 License Usage Statistics",
            color=discord.Color.blue()
        )
        
        embed.add_field(
            name="Commands Used", 
            value=f"{self.license_data.get('commands_used', 0):,}", 
            inline=True
        )
        embed.add_field(
            name="Last Used", 
            value=f"<t:{int(self.license_data.get('last_used', datetime.now()).timestamp())}:R>", 
            inline=True
        )
        embed.add_field(
            name="Account Age", 
            value=f"<t:{int(self.license_data.get('created_at', datetime.now()).timestamp())}:R>", 
            inline=True
        )
        
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @discord.ui.button(label="🎫 Support", style=discord.ButtonStyle.success)
    async def create_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Create a support ticket"""
        await interaction.response.send_modal(SupportTicketModal())


class SupportTicketModal(discord.ui.Modal):
    """Modal for creating support tickets"""
    def __init__(self):
        super().__init__(title="Create Support Ticket")

    subject = discord.ui.TextInput(
        label="Subject",
        placeholder="Brief description of your issue...",
        max_length=200,
        required=True
    )

    description = discord.ui.TextInput(
        label="Description",
        placeholder="Detailed description of your issue...",
        style=discord.TextStyle.paragraph,
        max_length=2000,
        required=True
    )

    category = discord.ui.TextInput(
        label="Category",
        placeholder="GENERAL, TECHNICAL, BILLING, REFUND",
        default="GENERAL",
        max_length=50,
        required=False
    )

    async def on_submit(self, interaction: discord.Interaction):
        # Send immediate response to prevent timeout
        await interaction.response.defer(ephemeral=True)
        
        try:
            # Create ticket channel in specified category
            guild = interaction.guild
            print(f"🔍 DEBUG: Guild: {guild.name if guild else 'None'} (ID: {guild.id if guild else 'None'})")
            
            if not guild:
                await interaction.followup.send("❌ This command can only be used in a server.", ephemeral=True)
                return
            
            # Get the ticket category channel
            ticket_category_id = 1389368950571405414
            print(f"🔍 DEBUG: Looking for category ID: {ticket_category_id}")
            
            category = guild.get_channel(ticket_category_id)
            print(f"🔍 DEBUG: Category found: {category.name if category else 'None'} (Type: {type(category).__name__ if category else 'None'})")
            
            if not category:
                # Let's list all channels to debug
                all_channels = guild.channels
                print(f"🔍 DEBUG: All guild channels ({len(all_channels)}):")
                for ch in all_channels:
                    print(f"  - {ch.name} (ID: {ch.id}, Type: {type(ch).__name__})")
                
                await interaction.followup.send(f"❌ Ticket category channel not found. Looking for ID: {ticket_category_id}. Please contact an administrator.", ephemeral=True)
                return
            
            # Generate unique ticket ID
            import random
            import string
            ticket_number = ''.join(random.choices(string.digits, k=4))
            
            # Create ticket channel
            channel_name = f"ticket-{interaction.user.name}-{ticket_number}"
            print(f"🔍 DEBUG: Creating channel: {channel_name}")
            
            # Set permissions for the ticket channel
            overwrites = {
                guild.default_role: discord.PermissionOverwrite(read_messages=False),
                interaction.user: discord.PermissionOverwrite(
                    read_messages=True,
                    send_messages=True,
                    embed_links=True,
                    attach_files=True,
                    read_message_history=True
                ),
                guild.me: discord.PermissionOverwrite(
                    read_messages=True,
                    send_messages=True,
                    manage_messages=True,
                    embed_links=True,
                    attach_files=True,
                    read_message_history=True
                )
            }
            
            # Add admin permissions (bot owner)
            owner = guild.get_member(344210326251896834)
            print(f"🔍 DEBUG: Bot owner found: {owner.name if owner else 'None'}")
            if owner:
                overwrites[owner] = discord.PermissionOverwrite(
                    read_messages=True,
                    send_messages=True,
                    manage_messages=True,
                    embed_links=True,
                    attach_files=True,
                    read_message_history=True
                )
            
            print(f"🔍 DEBUG: Permission overwrites set up for {len(overwrites)} entities")
            print(f"🔍 DEBUG: Bot permissions in guild: {guild.me.guild_permissions}")
            print(f"🔍 DEBUG: Can manage channels: {guild.me.guild_permissions.manage_channels}")
            
            # Ensure category is a CategoryChannel
            if not isinstance(category, discord.CategoryChannel):
                print(f"🔍 DEBUG: ERROR - Category is not a CategoryChannel! Type: {type(category).__name__}")
                await interaction.followup.send(f"❌ Found channel but it's not a category (Type: {type(category).__name__}). Please ensure ID {ticket_category_id} is a category channel.", ephemeral=True)
                return
            
            # Create the channel
            print(f"🔍 DEBUG: Attempting to create channel in category: {category.name}")
            ticket_channel = await guild.create_text_channel(
                name=channel_name,
                category=category,
                overwrites=overwrites,
                topic=f"Support ticket for {interaction.user} | Subject: {self.subject.value}"
            )
            print(f"🔍 DEBUG: Channel created successfully: {ticket_channel.name} (ID: {ticket_channel.id})")
            print(f"🔍 DEBUG: Channel category: {ticket_channel.category.name if ticket_channel.category else 'None'}")
            
            # Create initial ticket embed
            ticket_embed = discord.Embed(
                title="🎫 Support Ticket Created",
                description=f"**User:** {interaction.user.mention}\n**Subject:** {self.subject.value}\n**Category:** {self.category.value.upper()}",
                color=discord.Color.blue(),
                timestamp=interaction.created_at
            )
            ticket_embed.add_field(
                name="📝 Description",
                value=self.description.value,
                inline=False
            )
            ticket_embed.add_field(
                name="ℹ️ Information",
                value="• A support team member will assist you shortly\n• Use this channel to provide additional details\n• Click 🔒 to close this ticket when resolved",
                inline=False
            )
            ticket_embed.set_footer(text=f"Ticket #{ticket_number}")
            
            # Add close button
            close_view = TicketCloseView()
            
            # Send initial message in ticket channel
            await ticket_channel.send(
                content=f"{interaction.user.mention} | <@344210326251896834>",
                embed=ticket_embed,
                view=close_view
            )
            
            # Store ticket in database for tracking
            db_manager = interaction.client.db_manager
            ticket_id = db_manager.create_support_ticket(
                user_id=interaction.user.id,
                guild_id=interaction.guild.id,
                subject=str(self.subject.value),
                description=f"Channel: {ticket_channel.mention}\n\n{self.description.value}",
                category=str(self.category.value).upper()
            )
            
            # Respond to user
            response_embed = discord.Embed(
                title="✅ Ticket Created Successfully",
                description=f"Your support ticket has been created in {ticket_channel.mention}",
                color=discord.Color.green()
            )
            response_embed.add_field(
                name="Ticket Details",
                value=f"**Number:** #{ticket_number}\n**Subject:** {self.subject.value}\n**Channel:** {ticket_channel.mention}",
                inline=False
            )
            
            await interaction.followup.send(embed=response_embed, ephemeral=True)
            
        except Exception as e:
            error_embed = discord.Embed(
                title="❌ Error Creating Ticket",
                description=f"Failed to create support ticket: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.followup.send(embed=error_embed, ephemeral=True)


class TicketCloseView(discord.ui.View):
    """View for closing tickets"""
    def __init__(self):
        super().__init__(timeout=None)
    
    @discord.ui.button(label="🔒 Close Ticket", style=discord.ButtonStyle.danger, custom_id="close_ticket")
    async def close_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Close the ticket channel"""
        # Only allow ticket creator or bot owner to close
        channel = interaction.channel
        
        # Check if user has permission to close (channel permissions or bot owner)
        if not (interaction.user.id == 344210326251896834 or 
                channel.permissions_for(interaction.user).manage_messages or
                interaction.user in [overwrite[0] for overwrite in channel.overwrites.items() if isinstance(overwrite[0], discord.Member)]):
            await interaction.response.send_message("❌ You don't have permission to close this ticket.", ephemeral=True)
            return
        
        # Confirm closure
        confirm_embed = discord.Embed(
            title="🔒 Close Ticket?",
            description="Are you sure you want to close this ticket? This action cannot be undone.",
            color=discord.Color.orange()
        )
        
        confirm_view = TicketConfirmCloseView()
        await interaction.response.send_message(embed=confirm_embed, view=confirm_view, ephemeral=True)


class TicketConfirmCloseView(discord.ui.View):
    """Confirmation view for closing tickets"""
    def __init__(self):
        super().__init__(timeout=60)
    
    @discord.ui.button(label="✅ Confirm Close", style=discord.ButtonStyle.danger)
    async def confirm_close(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Confirm ticket closure"""
        try:
            channel = interaction.channel
            
            # Create closure embed
            close_embed = discord.Embed(
                title="🔒 Ticket Closed",
                description=f"This ticket has been closed by {interaction.user.mention}",
                color=discord.Color.red(),
                timestamp=interaction.created_at
            )
            
            await interaction.response.send_message(embed=close_embed)
            
            # Wait a moment then delete the channel
            import asyncio
            await asyncio.sleep(5)
            await channel.delete(reason=f"Ticket closed by {interaction.user}")
            
        except Exception as e:
            await interaction.response.send_message(f"❌ Error closing ticket: {str(e)}", ephemeral=True)
    
    @discord.ui.button(label="❌ Cancel", style=discord.ButtonStyle.secondary)
    async def cancel_close(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Cancel ticket closure"""
        await interaction.response.send_message("✅ Ticket closure cancelled.", ephemeral=True)


class PaymentView(discord.ui.View):
    """Payment selection view"""
    def __init__(self, license_type: str, price: str):
        super().__init__(timeout=300)
        self.license_type = license_type
        self.price = price

    @discord.ui.button(label="₿ Bitcoin", style=discord.ButtonStyle.primary, emoji="₿")
    async def bitcoin_payment(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Handle Bitcoin payment"""
        embed = discord.Embed(
            title="₿ Bitcoin Payment",
            description=f"**License:** {self.license_type}\n**Price:** ${self.price} USD",
            color=discord.Color.orange()
        )
        
        # Your BTC address
        btc_address = "bc1qa29gd8cec3n8cndl8ge9nf3p6wks9ddqqcww6s"
        
        embed.add_field(
            name="📍 Send Bitcoin to:",
            value=f"`{btc_address}`",
            inline=False
        )
        embed.add_field(
            name="💰 Amount",
            value=f"Send the current USD equivalent of **${self.price}** in Bitcoin",
            inline=False
        )
        embed.add_field(
            name="✅ After Payment",
            value="Use `/verify btc <transaction_id>` to verify your payment and receive your license key automatically.",
            inline=False
        )
        
        embed.set_footer(text="⚠️ Make sure to send the exact amount and use the verify command after payment!")
        
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @discord.ui.button(label="💳 PayPal", style=discord.ButtonStyle.success, emoji="💳")
    async def paypal_payment(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Handle PayPal payment"""
        embed = discord.Embed(
            title="💳 PayPal Payment",
            description=f"**License:** {self.license_type}\n**Price:** ${self.price} USD",
            color=discord.Color.blue()
        )
        
        embed.add_field(
            name="📧 Send Payment to:",
            value="lanagotcake@gmail.com",
            inline=False
        )
        embed.add_field(
            name="💰 Amount",
            value=f"**${self.price} USD**",
            inline=False
        )
        embed.add_field(
            name="📝 Include Note",
            value=f"License: {self.license_type} for Discord User: {interaction.user.id}",
            inline=False
        )
        embed.add_field(
            name="✅ After Payment",
            value="Contact support with your PayPal transaction ID to receive your license key.",
            inline=False
        )
        
        await interaction.response.send_message(embed=embed, ephemeral=True)


class AdminPanel(discord.ui.View):
    """Admin panel for license management"""
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="📊 Sales Stats", style=discord.ButtonStyle.primary)
    async def sales_stats(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Show sales statistics"""
        db_manager = interaction.client.db_manager
        stats = db_manager.get_sales_stats()
        
        embed = discord.Embed(
            title="📊 Sales Analytics Dashboard",
            color=discord.Color.gold()
        )
        
        embed.add_field(name="💰 Total Revenue", value=stats['total_revenue'], inline=True)
        embed.add_field(name="📈 Total Sales", value=f"{stats['total_sales']:,}", inline=True)
        embed.add_field(name="👥 Active Licenses", value=f"{stats['active_licenses']:,}", inline=True)
        
        embed.add_field(name="🔰 Basic Sales", value=f"{stats['basic_sales']:,}", inline=True)
        embed.add_field(name="⭐ Premium Sales", value=f"{stats['premium_sales']:,}", inline=True)
        embed.add_field(name="💎 Exclusive Sales", value=f"{stats['exclusive_sales']:,}", inline=True)
        
        embed.add_field(name="📅 Recent Sales (30d)", value=f"{stats['recent_sales']:,}", inline=False)
        
        embed.set_footer(text=f"Updated: {datetime.now().strftime('%Y-%m-%d %H:%M UTC')}")
        
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @discord.ui.button(label="🔑 Generate Keys", style=discord.ButtonStyle.secondary)
    async def generate_keys(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Generate license keys"""
        await interaction.response.send_modal(GenerateKeyModal())

    @discord.ui.button(label="🎫 View Tickets", style=discord.ButtonStyle.success)
    async def view_tickets(self, interaction: discord.Interaction, button: discord.ui.Button):
        """View support tickets"""
        # Implementation for viewing support tickets
        embed = discord.Embed(
            title="🎫 Support Tickets",
            description="Support ticket management coming soon...",
            color=discord.Color.blue()
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)


class GenerateKeyModal(discord.ui.Modal):
    """Modal for generating license keys"""
    def __init__(self):
        super().__init__(title="Generate License Key")

    license_type = discord.ui.TextInput(
        label="License Type",
        placeholder="BASIC, PREMIUM, or EXCLUSIVE",
        default="BASIC",
        required=True
    )

    price = discord.ui.TextInput(
        label="Price (USD)",
        placeholder="e.g., 29.99",
        required=True
    )

    duration = discord.ui.TextInput(
        label="Duration (days)",
        placeholder="365 for 1 year, leave empty for permanent",
        required=False
    )

    async def on_submit(self, interaction: discord.Interaction):
        db_manager = interaction.client.db_manager
        
        try:
            duration_days = int(self.duration.value) if self.duration.value else None
        except ValueError:
            duration_days = None
        
        key = db_manager.generate_license_key(
            license_type=str(self.license_type.value).upper(),
            price_usd=str(self.price.value),
            duration_days=duration_days
        )
        
        if key:
            embed = discord.Embed(
                title="🔑 License Key Generated",
                description=f"**Key:** `{key}`\n**Type:** {self.license_type.value}\n**Price:** ${self.price.value}",
                color=discord.Color.green()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
        else:
            embed = discord.Embed(
                title="❌ Error",
                description="Failed to generate license key.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)


def license_required(required_level: str = 'BASIC'):
    """Decorator to check license requirements"""
    def decorator(func):
        async def wrapper(self, interaction: discord.Interaction, *args, **kwargs):
            # Check if user has required license
            db_manager = interaction.client.db_manager
            has_access = db_manager.check_user_access(interaction.user.id, required_level)
            
            if not has_access:
                embed = discord.Embed(
                    title="🔒 License Required",
                    description=f"This command requires a **{required_level}** license or higher.\n\nUse `/buy` to purchase a license.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            # Update usage statistics
            db_manager.update_license_usage(interaction.user.id)
            
            # Call the original function
            return await func(self, interaction, *args, **kwargs)
        return wrapper
    return decorator


class Licensing(commands.Cog):
    """Comprehensive licensing system for bot sales"""
    
    def __init__(self, bot):
        self.bot = bot
        self.pricing = {
            'BASIC_MONTHLY': {'price': '4.99', 'duration': 30, 'features': ['Core moderation', 'Utility commands', 'Auto-moderation']},
            'BASIC_YEARLY': {'price': '29.99', 'duration': 365, 'features': ['Core moderation', 'Utility commands', 'Auto-moderation']},
            'PREMIUM_MONTHLY': {'price': '9.99', 'duration': 30, 'features': ['All Basic features', 'Music system', 'Advanced anti-raid', 'Enhanced spam protection']},
            'PREMIUM_YEARLY': {'price': '59.99', 'duration': 365, 'features': ['All Basic features', 'Music system', 'Advanced anti-raid', 'Enhanced spam protection']},
            'EXCLUSIVE_MONTHLY': {'price': '19.99', 'duration': 30, 'features': ['All Premium features', 'Priority support', 'Custom features']},
            'EXCLUSIVE': {'price': '99.99', 'duration': None, 'features': ['All Premium features', 'Lifetime access', 'Priority support', 'Custom features']},
            'CUSTOM_BOT': {'price': '50.00', 'duration': None, 'features': ['Your own personal bot', 'All Guardian features', 'Custom branding', 'Private hosting', 'Full source code', 'Setup assistance']}
        }

    @app_commands.command(name="buy", description="Purchase a bot license")
    async def buy_license(self, interaction: discord.Interaction):
        """Display license purchase options"""
        embed = discord.Embed(
            title="🛒 Guardian Bot Licenses",
            description="Choose your license tier and duration to unlock powerful Discord moderation features:",
            color=discord.Color.gold()
        )
        
        # Basic Tier
        embed.add_field(
            name="🔰 BASIC License",
            value="**Monthly:** $4.99/month (30 days)\n**Yearly:** $29.99/year (365 days)\n• Core moderation\n• Utility commands\n• Auto-moderation",
            inline=True
        )
        
        # Premium Tier
        embed.add_field(
            name="⭐ PREMIUM License", 
            value="**Monthly:** $9.99/month (30 days)\n**Yearly:** $59.99/year (365 days)\n• All Basic features\n• Music system\n• Advanced anti-raid\n• Enhanced spam protection",
            inline=True
        )
        
        # Exclusive Tier
        embed.add_field(
            name="💎 EXCLUSIVE License",
            value="**Monthly:** $19.99/month (30 days)\n**Lifetime:** $99.99 (Forever)\n• All Premium features\n• Priority support\n• Custom features",
            inline=True
        )
        
        # Custom Bot Tier
        embed.add_field(
            name="🤖 CUSTOM BOT",
            value="**One-time:** $50.00\n• Your own personal bot\n• All Guardian features\n• Custom branding\n• Private hosting\n• Full source code\n• Setup assistance",
            inline=False
        )
        
        embed.add_field(
            name="💳 Payment Methods",
            value="• Bitcoin (₿)\n• PayPal (💳)",
            inline=False
        )
        
        embed.add_field(
            name="💡 Save Money!",
            value="Choose yearly plans to save money compared to monthly subscriptions!",
            inline=False
        )
        
        embed.set_footer(text="Use our Purchase Bot with $buy command for instant activation!")
        
        # Create selection dropdown with all options
        select = discord.ui.Select(
            placeholder="Choose your license type and duration...",
            options=[
                discord.SelectOption(
                    label="BASIC Monthly - $4.99",
                    description="30 days - Core moderation features",
                    value="BASIC_MONTHLY",
                    emoji="🔰"
                ),
                discord.SelectOption(
                    label="BASIC Yearly - $29.99",
                    description="365 days - Save $29.89 vs monthly",
                    value="BASIC_YEARLY", 
                    emoji="🔰"
                ),
                discord.SelectOption(
                    label="PREMIUM Monthly - $9.99",
                    description="30 days - All Basic + Music & Anti-raid",
                    value="PREMIUM_MONTHLY",
                    emoji="⭐"
                ),
                discord.SelectOption(
                    label="PREMIUM Yearly - $59.99",
                    description="365 days - Save $59.89 vs monthly",
                    value="PREMIUM_YEARLY",
                    emoji="⭐"
                ),
                discord.SelectOption(
                    label="EXCLUSIVE Monthly - $19.99",
                    description="30 days - All features + Priority support",
                    value="EXCLUSIVE_MONTHLY",
                    emoji="💎"
                ),
                discord.SelectOption(
                    label="EXCLUSIVE Lifetime - $149.99",
                    description="Forever - One-time payment for lifetime access",
                    value="EXCLUSIVE",
                    emoji="💎"
                ),
                discord.SelectOption(
                    label="CUSTOM BOT - $50.00",
                    description="Your own personal bot with all features",
                    value="CUSTOM_BOT",
                    emoji="🤖"
                )
            ]
        )
        
        async def select_callback(select_interaction):
            license_type = select.values[0]
            price = self.pricing[license_type]['price']
            
            embed = discord.Embed(
                title=f"💳 Payment for {license_type} License",
                description=f"You selected: **{license_type}** license for **${price}**",
                color=discord.Color.blue()
            )
            
            view = PaymentView(license_type, price)
            await select_interaction.response.send_message(embed=embed, view=view, ephemeral=True)
        
        select.callback = select_callback
        view = discord.ui.View()
        view.add_item(select)
        
        await interaction.response.send_message(embed=embed, view=view)

    @app_commands.command(name="redeem", description="Redeem a license key")
    @app_commands.describe(key="Your license key (format: GUARD-XXXX-XXXX-XXXX)")
    async def redeem_key(self, interaction: discord.Interaction, key: str):
        """Redeem a license key"""
        await interaction.response.defer(ephemeral=True)
        
        db_manager = self.bot.db_manager
        
        # Attempt to redeem the key
        success = db_manager.redeem_license_key(interaction.user.id, key.upper())
        
        if success:
            # Get license info
            license_obj = db_manager.get_user_license(interaction.user.id)
            
            embed = discord.Embed(
                title="✅ License Key Redeemed!",
                description=f"Welcome to Guardian Bot **{license_obj.license_type}**!",
                color=discord.Color.green()
            )
            
            embed.add_field(name="License Type", value=license_obj.license_type, inline=True)
            embed.add_field(name="Status", value="ACTIVE", inline=True)
            
            if license_obj.expires_at:
                embed.add_field(
                    name="Expires", 
                    value=f"<t:{int(license_obj.expires_at.timestamp())}:D>", 
                    inline=True
                )
            else:
                embed.add_field(name="Duration", value="Lifetime", inline=True)
            
            embed.add_field(
                name="Features Unlocked",
                value="\n".join([f"• {feature}" for feature in self.pricing[license_obj.license_type]['features']]),
                inline=False
            )
            
            embed.set_footer(text="Use /license to view your license details anytime")
            
        else:
            embed = discord.Embed(
                title="❌ Invalid License Key",
                description="The license key you entered is invalid, already used, or expired.",
                color=discord.Color.red()
            )
            embed.add_field(
                name="Need Help?",
                value="• Double-check your key format\n• Contact support if you believe this is an error\n• Use `/buy` to purchase a new license",
                inline=False
            )
        
        await interaction.followup.send(embed=embed, ephemeral=True)

    @app_commands.command(name="license", description="View your license information")
    async def view_license(self, interaction: discord.Interaction):
        """View current license information"""
        db_manager = self.bot.db_manager
        license_obj = db_manager.get_user_license(interaction.user.id)
        
        if not license_obj:
            embed = discord.Embed(
                title="❌ No License Found",
                description="You don't have an active license.",
                color=discord.Color.red()
            )
            embed.add_field(
                name="Get Started",
                value="Use `/buy` to purchase a license and unlock all features!",
                inline=False
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Check if expired
        is_expired = False
        if license_obj.expires_at and datetime.utcnow() > license_obj.expires_at:
            is_expired = True
        
        embed = discord.Embed(
            title=f"🔑 Your {license_obj.license_type} License",
            description=f"Status: {'❌ EXPIRED' if is_expired else '✅ ACTIVE'}",
            color=discord.Color.red() if is_expired else discord.Color.green()
        )
        
        embed.add_field(name="License Key", value=f"`{license_obj.license_key}`", inline=False)
        embed.add_field(name="Type", value=license_obj.license_type, inline=True)
        embed.add_field(name="Commands Used", value=f"{license_obj.commands_used:,}", inline=True)
        
        if license_obj.expires_at:
            embed.add_field(
                name="Expires", 
                value=f"<t:{int(license_obj.expires_at.timestamp())}:D>", 
                inline=True
            )
        else:
            embed.add_field(name="Duration", value="Lifetime", inline=True)
        
        if license_obj.last_used:
            embed.add_field(
                name="Last Used", 
                value=f"<t:{int(license_obj.last_used.timestamp())}:R>", 
                inline=True
            )
        
        embed.add_field(
            name="Created", 
            value=f"<t:{int(license_obj.created_at.timestamp())}:D>", 
            inline=True
        )
        
        # Add features
        if license_obj.license_type in self.pricing:
            features_text = "\n".join([f"• {feature}" for feature in self.pricing[license_obj.license_type]['features']])
            embed.add_field(name="Features", value=features_text, inline=False)
        
        # License data for view
        license_data = {
            'commands_used': license_obj.commands_used,
            'last_used': license_obj.last_used or datetime.now(),
            'created_at': license_obj.created_at
        }
        
        view = LicenseView(license_data)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

    @app_commands.command(name="verify", description="Verify payment and get license key")
    @app_commands.describe(
        method="Payment method",
        transaction_id="Transaction ID or reference"
    )
    @app_commands.choices(method=[
        app_commands.Choice(name="Bitcoin", value="btc"),
        app_commands.Choice(name="PayPal", value="paypal")
    ])
    async def verify_payment(self, interaction: discord.Interaction, method: str, transaction_id: str):
        """Verify payment and automatically issue license"""
        await interaction.response.defer(ephemeral=True)
        
        if method == "btc":
            # Use existing BTC verification logic
            success, result = await self.verify_btc_transaction(transaction_id)
            if success:
                # Extract amount and determine license type
                amount_btc = result.get('amount', 0)
                amount_usd = await self.btc_to_usd(amount_btc)
                license_type = self.determine_license_type(amount_usd)
                
                if license_type:
                    # Create transaction record
                    db_manager = self.bot.db_manager
                    db_manager.create_payment_transaction(
                        user_id=interaction.user.id,
                        transaction_id=transaction_id,
                        payment_method="BTC",
                        amount=str(amount_usd),
                        license_type=license_type
                    )
                    
                    # Confirm transaction and generate license
                    success = db_manager.confirm_payment_transaction(transaction_id)
                    
                    if success:
                        embed = discord.Embed(
                            title="✅ Payment Verified!",
                            description=f"Your Bitcoin payment has been verified and your **{license_type}** license has been activated!",
                            color=discord.Color.green()
                        )
                        embed.add_field(name="Transaction ID", value=transaction_id, inline=False)
                        embed.add_field(name="Amount", value=f"${amount_usd:.2f} USD", inline=True)
                        embed.add_field(name="License Type", value=license_type, inline=True)
                    else:
                        embed = discord.Embed(
                            title="❌ Processing Error",
                            description="Payment verified but license generation failed. Contact support.",
                            color=discord.Color.red()
                        )
                else:
                    embed = discord.Embed(
                        title="❌ Invalid Amount",
                        description=f"Payment amount (${amount_usd:.2f}) doesn't match any license tier.",
                        color=discord.Color.red()
                    )
            else:
                embed = discord.Embed(
                    title="❌ Verification Failed",
                    description="Could not verify Bitcoin transaction. Please check the transaction ID.",
                    color=discord.Color.red()
                )
        
        elif method == "paypal":
            embed = discord.Embed(
                title="💳 PayPal Verification",
                description="PayPal verification requires manual processing. Our team will review your payment and activate your license within 24 hours.",
                color=discord.Color.blue()
            )
            embed.add_field(
                name="Transaction ID Recorded",
                value=f"`{transaction_id}`",
                inline=False
            )
            embed.add_field(
                name="Next Steps",
                value="• Our team will verify your PayPal payment\n• License will be activated automatically\n• You'll receive a confirmation message",
                inline=False
            )
        
        await interaction.followup.send(embed=embed, ephemeral=True)

    async def verify_btc_transaction(self, tx_id: str):
        """Verify Bitcoin transaction using Blockstream API"""
        try:
            async with aiohttp.ClientSession() as session:
                url = f"https://blockstream.info/api/tx/{tx_id}"
                async with session.get(url) as response:
                    if response.status == 200:
                        data = await response.json()
                        
                        # Check if transaction exists and get outputs
                        for output in data.get('vout', []):
                            if output.get('scriptpubkey_address') == "bc1qa29gd8cec3n8cndl8ge9nf3p6wks9ddqqcww6s":
                                amount_satoshi = output.get('value', 0)
                                amount_btc = amount_satoshi / 100000000  # Convert satoshi to BTC
                                return True, {'amount': amount_btc, 'confirmed': data.get('status', {}).get('confirmed', False)}
                        
                        return False, "Address not found in transaction"
                    else:
                        return False, "Transaction not found"
        except Exception as e:
            return False, f"Error verifying transaction: {str(e)}"

    async def btc_to_usd(self, btc_amount: float) -> float:
        """Convert BTC amount to USD"""
        try:
            async with aiohttp.ClientSession() as session:
                url = "https://api.coindesk.com/v1/bpi/currentprice.json"
                async with session.get(url) as response:
                    if response.status == 200:
                        data = await response.json()
                        btc_price = float(data['bpi']['USD']['rate'].replace(',', ''))
                        return btc_amount * btc_price
        except:
            pass
        return 0.0

    def determine_license_type(self, amount_usd: float) -> str:
        """Determine license type based on payment amount"""
        if amount_usd >= 90:  # Within $10 of EXCLUSIVE lifetime price
            return "EXCLUSIVE"
        elif amount_usd >= 55:  # Within $5 of PREMIUM yearly price
            return "PREMIUM"
        elif amount_usd >= 45:  # Within $5 of CUSTOM_BOT price
            return "CUSTOM_BOT"
        elif amount_usd >= 25:  # Within $5 of BASIC yearly price
            return "BASIC"
        elif amount_usd >= 15:  # Within $5 of EXCLUSIVE monthly price
            return "EXCLUSIVE"
        elif amount_usd >= 7:  # Within $3 of PREMIUM monthly price
            return "PREMIUM"
        elif amount_usd >= 3:  # Within $2 of BASIC monthly price
            return "BASIC"
        return None

    @app_commands.command(name="ticket", description="Manage support tickets")
    @app_commands.describe(action="Ticket action")
    @app_commands.choices(action=[
        app_commands.Choice(name="Create", value="create"),
        app_commands.Choice(name="Status", value="status"),
        app_commands.Choice(name="List", value="list")
    ])
    async def ticket_command(self, interaction: discord.Interaction, action: str):
        """Support ticket management"""
        db_manager = self.bot.db_manager
        
        if action == "create":
            modal = SupportTicketModal()
            await interaction.response.send_modal(modal)
        
        elif action == "status" or action == "list":
            tickets = db_manager.get_user_tickets(interaction.user.id)
            
            if not tickets:
                embed = discord.Embed(
                    title="📋 No Tickets Found",
                    description="You don't have any support tickets.",
                    color=discord.Color.blue()
                )
                embed.add_field(
                    name="Create a Ticket",
                    value="Use `/ticket create` to create a new support ticket.",
                    inline=False
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            embed = discord.Embed(
                title="🎫 Your Support Tickets",
                color=discord.Color.blue()
            )
            
            for ticket in tickets[:10]:  # Show last 10 tickets
                status_emoji = "🟢" if ticket.status == "OPEN" else "🟡" if ticket.status == "IN_PROGRESS" else "🔴"
                embed.add_field(
                    name=f"{status_emoji} {ticket.ticket_id}",
                    value=f"**Subject:** {ticket.subject}\n**Status:** {ticket.status}\n**Created:** <t:{int(ticket.created_at.timestamp())}:R>",
                    inline=False
                )
            
            await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="admin_panel", description="Admin panel for license management")
    async def admin_panel(self, interaction: discord.Interaction):
        """Admin panel for managing licenses (Owner only)"""
        if interaction.user.id != 344210326251896834:  # Your user ID
            embed = discord.Embed(
                title="❌ Access Denied",
                description="This command is restricted to bot administrators.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        embed = discord.Embed(
            title="🔧 Guardian Bot Admin Panel",
            description="License management and analytics dashboard",
            color=discord.Color.purple()
        )
        
        view = AdminPanel()
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

    @app_commands.command(name="grantlicense", description="Manually grant license to user (Admin only)")
    @app_commands.describe(
        user="The user to grant license to",
        license_type="License type to grant",
        duration="Duration in days (leave empty for permanent)"
    )
    @app_commands.choices(license_type=[
        app_commands.Choice(name="Basic ($29.99/year)", value="BASIC"),
        app_commands.Choice(name="Premium ($49.99/year)", value="PREMIUM"), 
        app_commands.Choice(name="Exclusive ($99.99 lifetime)", value="EXCLUSIVE")
    ])
    async def whitelist_user(self, interaction: discord.Interaction, user: discord.Member, license_type: str, duration: int = None):
        """Manually grant license to a user (Owner only)"""
        if interaction.user.id != 344210326251896834:  # Your user ID
            embed = discord.Embed(
                title="❌ Access Denied",
                description="This command is restricted to bot administrators.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        await interaction.response.defer(ephemeral=True)
        
        try:
            db_manager = self.bot.db_manager
            
            # Check if user already has a license
            existing_license = db_manager.get_user_license(user.id)
            if existing_license and existing_license.status == 'ACTIVE':
                embed = discord.Embed(
                    title="⚠️ User Already Licensed",
                    description=f"{user.mention} already has an active **{existing_license.license_type}** license.",
                    color=discord.Color.orange()
                )
                embed.add_field(
                    name="Current License",
                    value=f"Type: {existing_license.license_type}\nExpires: {'Never' if not existing_license.expires_at else f'<t:{int(existing_license.expires_at.timestamp())}:F>'}",
                    inline=False
                )
                await interaction.followup.send(embed=embed, ephemeral=True)
                return
            
            # Generate license key
            price_map = {"BASIC": "29.99", "PREMIUM": "49.99", "EXCLUSIVE": "99.99"}
            price = price_map.get(license_type, "0.00")
            
            # Create license
            expires_at = None
            if duration and license_type != "EXCLUSIVE":  # Exclusive is lifetime
                expires_at = datetime.now() + timedelta(days=duration)
            elif license_type in ["BASIC", "PREMIUM"] and not duration:
                expires_at = datetime.now() + timedelta(days=365)  # Default 1 year
            
            license_key = db_manager.generate_license_key(license_type, price, duration or (365 if license_type != "EXCLUSIVE" else None))
            
            success = db_manager.create_license(
                user_id=user.id,
                license_key=license_key,
                license_type=license_type,
                expires_at=expires_at,
                payment_method="ADMIN_GRANT",
                payment_reference=f"Granted by {interaction.user}",
                amount_paid=price
            )
            
            if success:
                # Success embed
                embed = discord.Embed(
                    title="✅ License Granted Successfully",
                    description=f"**{license_type}** license has been granted to {user.mention}",
                    color=discord.Color.green()
                )
                embed.add_field(name="User", value=f"{user.mention} (`{user.id}`)", inline=True)
                embed.add_field(name="License Type", value=license_type, inline=True)
                embed.add_field(name="License Key", value=f"`{license_key}`", inline=False)
                
                if expires_at:
                    embed.add_field(name="Expires", value=f"<t:{int(expires_at.timestamp())}:F>", inline=True)
                else:
                    embed.add_field(name="Duration", value="Lifetime", inline=True)
                
                embed.add_field(name="Granted By", value=interaction.user.mention, inline=True)
                embed.set_footer(text=f"Granted on {datetime.now().strftime('%Y-%m-%d at %H:%M UTC')}")
                
                # Send confirmation to admin
                await interaction.followup.send(embed=embed, ephemeral=True)
                
                # Try to notify the user
                try:
                    user_embed = discord.Embed(
                        title="🎉 License Activated!",
                        description=f"You have been granted a **{license_type}** license for Guardian Bot!",
                        color=discord.Color.green()
                    )
                    user_embed.add_field(name="License Key", value=f"`{license_key}`", inline=False)
                    user_embed.add_field(
                        name="Access Unlocked",
                        value="Your license has been automatically activated. Use `/license` to view your access level.",
                        inline=False
                    )
                    if expires_at:
                        user_embed.add_field(name="Valid Until", value=f"<t:{int(expires_at.timestamp())}:F>", inline=False)
                    
                    await user.send(embed=user_embed)
                    
                    # Update admin about notification
                    notify_embed = discord.Embed(
                        title="📬 User Notified",
                        description=f"Successfully sent license details to {user.mention} via DM.",
                        color=discord.Color.blue()
                    )
                    await interaction.followup.send(embed=notify_embed, ephemeral=True)
                    
                except discord.Forbidden:
                    # User has DMs disabled
                    notify_embed = discord.Embed(
                        title="⚠️ DM Failed",
                        description=f"Could not send DM to {user.mention}. User has been granted license but not notified directly.",
                        color=discord.Color.orange()
                    )
                    await interaction.followup.send(embed=notify_embed, ephemeral=True)
                
            else:
                embed = discord.Embed(
                    title="❌ License Grant Failed",
                    description="Failed to create license in database. Please try again.",
                    color=discord.Color.red()
                )
                await interaction.followup.send(embed=embed, ephemeral=True)
                
        except Exception as e:
            embed = discord.Embed(
                title="❌ Error",
                description=f"An error occurred while granting license: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.followup.send(embed=embed, ephemeral=True)

    @app_commands.command(name="activelicenses", description="View all active licenses (Admin only)")
    async def active_licenses(self, interaction: discord.Interaction):
        """View all active licenses in the system (Owner only)"""
        if interaction.user.id != 344210326251896834:  # Your user ID
            embed = discord.Embed(
                title="❌ Access Denied",
                description="This command is restricted to bot administrators.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        await interaction.response.send_message("Loading active licenses...", ephemeral=True)
        
        try:
            db_manager = self.bot.db_manager
            session = db_manager.get_session()
            
            # Get all active licenses
            from models import License
            active_licenses = session.query(License).filter(License.status == 'ACTIVE').all()
            
            if not active_licenses:
                embed = discord.Embed(
                    title="📋 No Active Licenses",
                    description="There are currently no active licenses in the system.",
                    color=discord.Color.blue()
                )
                await interaction.edit_original_response(content=None, embed=embed)
                db_manager.close_session(session)
                return
            
            # Group licenses by type
            license_groups = {"BASIC": [], "PREMIUM": [], "EXCLUSIVE": []}
            for license_obj in active_licenses:
                if license_obj.license_type in license_groups:
                    license_groups[license_obj.license_type].append(license_obj)
            
            embed = discord.Embed(
                title="📊 Active Licenses Summary",
                description=f"Total active licenses: **{len(active_licenses)}**",
                color=discord.Color.green()
            )
            
            # Add summary field
            summary_text = []
            for license_type, licenses in license_groups.items():
                if licenses:
                    summary_text.append(f"**{license_type}**: {len(licenses)} users")
            
            if summary_text:
                embed.add_field(name="License Distribution", value="\n".join(summary_text), inline=False)
            
            # Add detailed breakdown (limited to prevent message being too long)
            for license_type, licenses in license_groups.items():
                if licenses:
                    license_list = []
                    for i, license_obj in enumerate(licenses[:10]):  # Show max 10 per type
                        try:
                            user = self.bot.get_user(license_obj.user_id)
                            username = f"{user.name}" if user else f"User {license_obj.user_id}"
                        except:
                            username = f"User {license_obj.user_id}"
                        
                        expiry_info = "Lifetime" if not license_obj.expires_at else f"<t:{int(license_obj.expires_at.timestamp())}:R>"
                        license_list.append(f"`{username}` - Expires: {expiry_info}")
                    
                    if len(licenses) > 10:
                        license_list.append(f"... and {len(licenses) - 10} more")
                    
                    embed.add_field(
                        name=f"{license_type} Licenses ({len(licenses)})",
                        value="\n".join(license_list) if license_list else "None",
                        inline=False
                    )
            
            # Add revenue information
            total_revenue = 0
            revenue_breakdown = {"BASIC": 0, "PREMIUM": 0, "EXCLUSIVE": 0}
            price_map = {"BASIC": 29.99, "PREMIUM": 49.99, "EXCLUSIVE": 99.99}
            
            for license_obj in active_licenses:
                if license_obj.license_type in price_map:
                    price = price_map[license_obj.license_type]
                    revenue_breakdown[license_obj.license_type] += price
                    total_revenue += price
            
            revenue_text = []
            for license_type, revenue in revenue_breakdown.items():
                if revenue > 0:
                    revenue_text.append(f"**{license_type}**: ${revenue:,.2f}")
            
            if revenue_text:
                revenue_text.append(f"**TOTAL**: ${total_revenue:,.2f}")
                embed.add_field(name="💰 Revenue Generated", value="\n".join(revenue_text), inline=False)
            
            embed.set_footer(text=f"Generated on {datetime.now().strftime('%Y-%m-%d at %H:%M UTC')}")
            
            await interaction.edit_original_response(content=None, embed=embed)
            db_manager.close_session(session)
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ Error",
                description=f"An error occurred while fetching license data: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.followup.send(embed=embed, ephemeral=True)

    # Command access decorators for existing commands
    def apply_license_checks(self):
        """Apply license checks to existing bot commands"""
        # This would be called during bot initialization to wrap existing commands
        pass


async def setup(bot):
    cog = Licensing(bot)
    await bot.add_cog(cog)
    # Apply license checks to existing commands if needed
    # cog.apply_license_checks()