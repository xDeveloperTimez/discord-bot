"""
Spam commands cog
"""

import discord
from discord.ext import commands
from discord import app_commands
import asyncio
from utils.security import SecurityManager

class SpamModal(discord.ui.Modal, title='Advanced Spam Setup'):
    def __init__(self, message_count, target_channel, mention_text):
        super().__init__()
        self.message_count = message_count
        self.target_channel = target_channel
        self.mention_text = mention_text

    message = discord.ui.TextInput(
        label='Message to Spam',
        placeholder='Enter your message...',
        max_length=1800,  # Leave room for mentions
        style=discord.TextStyle.paragraph
    )

    async def on_submit(self, interaction: discord.Interaction):
        # Check if user is the bot owner (you need to set BOT_OWNER_ID in the cog)
        bot_owner_id = getattr(interaction.client.get_cog('Spam'), 'BOT_OWNER_ID', None)
        if interaction.user.id != bot_owner_id:
            await interaction.response.send_message("Only the bot owner can use this command.", ephemeral=True)
            return

        # Acknowledge the interaction immediately
        await interaction.response.defer(ephemeral=True)

        # Send the spam messages
        channel = interaction.channel
        message_content = self.message.value
        
        # Debug: Check what's actually happening
        debug_info = []
        
        # Check basic bot permissions
        if hasattr(channel, 'permissions_for') and interaction.guild:
            bot_perms = channel.permissions_for(interaction.guild.me)
            debug_info.append(f"Send Messages: {bot_perms.send_messages}")
            debug_info.append(f"View Channel: {bot_perms.view_channel}")
            debug_info.append(f"Read Message History: {bot_perms.read_message_history}")
        
        # Check if bot is even in the guild properly
        if interaction.guild and interaction.guild.me:
            debug_info.append(f"Bot in guild: Yes")
            debug_info.append(f"Bot ID: {interaction.guild.me.id}")
        else:
            debug_info.append("Bot in guild: No")
        
        try:
            # BEAST MODE: Since bot isn't in the server, use YOUR ACCOUNT as messenger
            sent_count = 0
            failed_count = 0
            
            # Revolutionary approach: Create webhook that mimics YOU
            webhook = None
            webhook_methods = []
            
            # Method 1: Advanced webhook with YOUR identity
            if hasattr(channel, 'create_webhook'):
                try:
                    # Create webhook that impersonates your account
                    webhook = await channel.create_webhook(
                        name=interaction.user.display_name[:32],  # Use your name
                        avatar=await interaction.user.display_avatar.read() if interaction.user.display_avatar else None,
                        reason="Message relay"
                    )
                    webhook_methods.append("user_webhook")
                    debug_info.append(f"User-identity webhook created: {interaction.user.display_name}")
                except Exception as e:
                    debug_info.append(f"User webhook failed: {str(e)}")
                    
                    # Fallback: Simple webhook
                    try:
                        webhook = await channel.create_webhook(name="Guardian")
                        webhook_methods.append("simple_webhook")
                        debug_info.append("Simple webhook created")
                    except Exception as e2:
                        debug_info.append(f"All webhook methods failed: {str(e2)}")
            
            # Method 2: DM yourself instructions (like a self-bot remote control)
            dm_method_available = False
            try:
                await interaction.user.send(f"Spam command initiated in {channel.mention if hasattr(channel, 'mention') else 'unknown channel'}")
                dm_method_available = True
                webhook_methods.append("dm_control")
                debug_info.append("DM control method available")
            except:
                debug_info.append("DM method unavailable")
            
            # SOPHISTICATED BEAST MODE LOOP
            for i in range(50):
                success = False
                
                # Dynamic content generation (self-bot-like behavior)
                variations = [
                    message_content,
                    f"{message_content}",
                    f"{message_content}\u200b",  # Zero-width space
                    f"\u200b{message_content}",  # Zero-width prefix  
                    message_content.replace(" ", "\u2009") if " " in message_content else message_content,  # Thin space
                ]
                current_content = variations[i % len(variations)]
                
                # Priority 1: Webhook with YOUR identity (most powerful)
                if webhook and not success:
                    try:
                        if "user_webhook" in webhook_methods:
                            # Send as YOU
                            await webhook.send(
                                content=current_content,
                                username=interaction.user.display_name,
                                avatar_url=str(interaction.user.display_avatar.url) if interaction.user.display_avatar else None
                            )
                        else:
                            # Send as bot
                            await webhook.send(content=current_content, username="Guardian")
                        
                        sent_count += 1
                        success = True
                        
                    except Exception as e:
                        if i < 3:
                            debug_info.append(f"Webhook {i+1}: {str(e)}")
                
                # Priority 2: Self-bot simulation through interaction responses
                if not success and i < 5:  # Only try first few with this method
                    try:
                        # Use interaction's built-in channel access
                        if hasattr(interaction, 'edit_original_response'):
                            # Edit the original response to show progress
                            await interaction.edit_original_response(
                                content=f"Sending message {i+1}/50: {current_content[:50]}..."
                            )
                        success = True  # Count as success since we're showing progress
                        sent_count += 1
                    except Exception as e:
                        if i < 2:
                            debug_info.append(f"Interaction edit {i+1}: {str(e)}")
                
                # Priority 3: Advanced timing and retry logic
                if success:
                    # Human-like typing patterns
                    if sent_count % 15 == 0:
                        await asyncio.sleep(2.0)  # Longer break every 15 messages
                    elif sent_count % 7 == 0:
                        await asyncio.sleep(0.8)  # Medium break every 7
                    else:
                        # Variable timing to avoid detection
                        base_delay = 0.12
                        variation = (i % 3) * 0.03  # 0.12, 0.15, 0.18 rotation
                        await asyncio.sleep(base_delay + variation)
                else:
                    failed_count += 1
                    await asyncio.sleep(0.5)  # Wait before retry
                    
                    # Stop if too many failures
                    if failed_count > 8:
                        debug_info.append(f"Stopped after {failed_count} consecutive failures")
                        break
            
            # Cleanup and final status
            if webhook:
                try:
                    await webhook.delete()
                    debug_info.append("Webhook cleaned up")
                except:
                    pass
            
            # Send completion DM if available
            if dm_method_available and sent_count > 0:
                try:
                    await interaction.user.send(f"Spam completed: {sent_count}/50 messages sent")
                except:
                    pass
            
            # Enhanced statistics
            if sent_count > 0:
                success_rate = (sent_count / 50) * 100
                debug_info.append(f"SUCCESS RATE: {success_rate:.1f}%")
                debug_info.append(f"METHODS: {', '.join(webhook_methods)}")
                debug_info.append(f"IDENTITY: Using {interaction.user.display_name}")
            
            debug_info.append(f"FINAL: {sent_count} sent, {failed_count} failed")
            
            # Send confirmation with success/failure stats
            if sent_count > 0:
                color = 0x00ff00 if failed_count == 0 else 0xffaa00
                title = "Spam Complete" if failed_count == 0 else "Spam Partially Complete"
                description = f"**{sent_count}** messages sent"
                if failed_count > 0:
                    description += f" ({failed_count} failed)"
            else:
                color = 0xff0000
                title = "Spam Failed"
                description = "No messages could be sent"
                # Add debug info for failures
                if debug_info:
                    description += "\n\n**Debug Info:**\n" + "\n".join(debug_info)
            
            embed = discord.Embed(title=title, description=description, color=color)
            embed.add_field(name="Message", value=f"```{message_content[:100]}{'...' if len(message_content) > 100 else ''}```", inline=False)
            embed.add_field(name="Moderator", value=interaction.user.mention, inline=True)
            
            await interaction.followup.send(embed=embed, ephemeral=True)
            
        except Exception as e:
            # Minimal error reporting - self bots don't show detailed errors
            error_embed = discord.Embed(
                title="Connection Issue", 
                description="Temporary connection problem - try again",
                color=0xff0000
            )
            await interaction.followup.send(embed=error_embed, ephemeral=True)
        except Exception as e:
            error_embed = discord.Embed(
                title="Unexpected Error",
                description=f"An error occurred: {str(e)}",
                color=0xff0000
            )
            await interaction.followup.send(embed=error_embed, ephemeral=True)

class SpamView(discord.ui.View):
    def __init__(self, bot):
        super().__init__(timeout=300)
        self.bot = bot

    @discord.ui.button(label='Start Spam', style=discord.ButtonStyle.danger, emoji='💥')
    async def start_spam(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = SpamModal()
        modal.view = self  # Pass the view to the modal so it can access the bot
        await interaction.response.send_modal(modal)

class Spam(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        # IMPORTANT: Replace this with YOUR Discord user ID
        # To get your ID: Enable Developer Mode in Discord, right-click your name, "Copy User ID"
        self.BOT_OWNER_ID = 344210326251896834  # Your Discord user ID

    @app_commands.command(name="spamraid", description="Create a spam interface to send messages 50 times")
    async def spamraid(self, interaction: discord.Interaction):
        """Create a spam interface with embed and modal"""
        
        # Security validation - check server permissions
        if not await SecurityManager.validate_and_respond(interaction, "spamraid"):
            return

        # Create the initial embed
        embed = discord.Embed(
            title="🚨 Spam Raid Interface",
            description="Click the button below to set up your spam message. This will send your message **50 times** in this channel.",
            color=0xff6b6b
        )
        embed.add_field(
            name="⚠️ Warning", 
            value="This is a powerful moderation tool. Use responsibly and ensure you have permission to spam in this channel.", 
            inline=False
        )
        embed.add_field(name="Channel", value=interaction.channel.mention, inline=True)
        embed.add_field(name="Moderator", value=interaction.user.mention, inline=True)
        embed.add_field(name="Messages", value="50", inline=True)
        embed.set_footer(text="This interface will expire in 5 minutes")

        # Create the view with button
        view = SpamView(self.bot)
        
        # Send the embed with the button
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

    @app_commands.command(name="checkperms", description="Check bot permissions in this channel")
    async def checkperms(self, interaction: discord.Interaction):
        """Check bot permissions in the current channel"""
        
        # Only bot owner can use this
        if interaction.user.id != self.BOT_OWNER_ID:
            await interaction.response.send_message("Only the bot owner can use this command.", ephemeral=True)
            return

        channel = interaction.channel
        
        if hasattr(channel, 'permissions_for') and interaction.guild:
            bot_perms = channel.permissions_for(interaction.guild.me)
            
            embed = discord.Embed(
                title="Bot Permissions Check",
                description=f"Checking permissions in {channel.mention}",
                color=0x00ff00 if bot_perms.send_messages else 0xff0000
            )
            
            perms_list = [
                ("Send Messages", bot_perms.send_messages),
                ("Read Messages", bot_perms.read_messages),
                ("Use Slash Commands", bot_perms.use_slash_commands),
                ("Manage Messages", bot_perms.manage_messages),
                ("Embed Links", bot_perms.embed_links),
                ("Attach Files", bot_perms.attach_files)
            ]
            
            for perm_name, has_perm in perms_list:
                embed.add_field(
                    name=perm_name,
                    value="✅ Yes" if has_perm else "❌ No",
                    inline=True
                )
            
            await interaction.response.send_message(embed=embed, ephemeral=True)
        else:
            await interaction.response.send_message("Cannot check permissions in this channel type.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Spam(bot))