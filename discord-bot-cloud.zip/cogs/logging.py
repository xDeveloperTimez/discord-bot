"""
Logging and audit cog
"""

import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime
from utils.checks import is_admin

class Logging(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="setlogchannel", description="Set the log channel for moderation actions")
    @app_commands.describe(channel="The channel to send logs to")
    async def setlogchannel(self, interaction: discord.Interaction, channel: discord.TextChannel):
        """Set the log channel"""
        if not is_admin(interaction.user, self.bot.config):
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You need administrator permissions to use this command.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        self.bot.config.set("log_channel", channel.id)
        
        embed = discord.Embed(
            title="✅ Log Channel Set",
            description=f"Log channel has been set to {channel.mention}.",
            color=discord.Color.green()
        )
        embed.add_field(name="Set by", value=interaction.user.mention, inline=False)
        
        await interaction.response.send_message(embed=embed)
        
        # Send test message to log channel
        try:
            test_embed = discord.Embed(
                title="🔧 Log Channel Configured",
                description="This channel has been set as the moderation log channel.",
                color=discord.Color.blue(),
                timestamp=datetime.now()
            )
            test_embed.add_field(name="Configured by", value=str(interaction.user), inline=False)
            await channel.send(embed=test_embed)
        except:
            pass
    
    @app_commands.command(name="removelogchannel", description="Remove the current log channel")
    async def removelogchannel(self, interaction: discord.Interaction):
        """Remove the log channel"""
        if not is_admin(interaction.user, self.bot.config):
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You need administrator permissions to use this command.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        if not self.bot.config.log_channel:
            embed = discord.Embed(
                title="❌ No Log Channel",
                description="No log channel is currently set.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        self.bot.config.set("log_channel", None)
        
        embed = discord.Embed(
            title="✅ Log Channel Removed",
            description="The log channel has been removed.",
            color=discord.Color.green()
        )
        embed.add_field(name="Removed by", value=interaction.user.mention, inline=False)
        
        await interaction.response.send_message(embed=embed)
    
    @commands.Cog.listener()
    async def on_member_join(self, member):
        """Log when a member joins"""
        if not self.bot.config.log_channel:
            return
        
        log_channel = member.guild.get_channel(self.bot.config.log_channel)
        if not log_channel:
            return
        
        embed = discord.Embed(
            title="📥 Member Joined",
            color=discord.Color.green(),
            timestamp=datetime.now()
        )
        
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.add_field(name="Member", value=f"{member} ({member.id})", inline=True)
        embed.add_field(name="Account Created", value=f"<t:{int(member.created_at.timestamp())}:R>", inline=True)
        embed.add_field(name="Total Members", value=member.guild.member_count, inline=True)
        
        # Check account age
        account_age = (datetime.now() - member.created_at.replace(tzinfo=None)).days
        if account_age < 7:
            embed.add_field(name="⚠️ Warning", value=f"New account ({account_age} days old)", inline=False)
        
        try:
            await log_channel.send(embed=embed)
        except:
            pass
    
    @commands.Cog.listener()
    async def on_member_remove(self, member):
        """Log when a member leaves"""
        if not self.bot.config.log_channel:
            return
        
        log_channel = member.guild.get_channel(self.bot.config.log_channel)
        if not log_channel:
            return
        
        embed = discord.Embed(
            title="📤 Member Left",
            color=discord.Color.red(),
            timestamp=datetime.now()
        )
        
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.add_field(name="Member", value=f"{member} ({member.id})", inline=True)
        embed.add_field(name="Joined", value=f"<t:{int(member.joined_at.timestamp())}:R>", inline=True)
        embed.add_field(name="Total Members", value=member.guild.member_count, inline=True)
        
        # Show roles the member had
        roles = [role.mention for role in member.roles[1:]]  # Exclude @everyone
        if roles:
            embed.add_field(name="Roles", value=" ".join(roles) if len(" ".join(roles)) <= 1024 else f"{len(roles)} roles", inline=False)
        
        try:
            await log_channel.send(embed=embed)
        except:
            pass
    
    @commands.Cog.listener()
    async def on_message_delete(self, message):
        """Log when a message is deleted"""
        if not self.bot.config.log_channel or message.author.bot:
            return
        
        log_channel = message.guild.get_channel(self.bot.config.log_channel)
        if not log_channel or message.channel == log_channel:
            return
        
        embed = discord.Embed(
            title="🗑️ Message Deleted",
            color=discord.Color.orange(),
            timestamp=datetime.now()
        )
        
        embed.add_field(name="Author", value=f"{message.author} ({message.author.id})", inline=True)
        embed.add_field(name="Channel", value=message.channel.mention, inline=True)
        embed.add_field(name="Message ID", value=message.id, inline=True)
        
        if message.content:
            content = message.content[:1000] + "..." if len(message.content) > 1000 else message.content
            embed.add_field(name="Content", value=f"```{content}```", inline=False)
        
        if message.attachments:
            attachments = "\n".join([attachment.filename for attachment in message.attachments])
            embed.add_field(name="Attachments", value=attachments, inline=False)
        
        try:
            await log_channel.send(embed=embed)
        except:
            pass
    
    @commands.Cog.listener()
    async def on_message_edit(self, before, after):
        """Log when a message is edited"""
        if not self.bot.config.log_channel or before.author.bot or before.content == after.content:
            return
        
        log_channel = before.guild.get_channel(self.bot.config.log_channel)
        if not log_channel or before.channel == log_channel:
            return
        
        embed = discord.Embed(
            title="✏️ Message Edited",
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        
        embed.add_field(name="Author", value=f"{before.author} ({before.author.id})", inline=True)
        embed.add_field(name="Channel", value=before.channel.mention, inline=True)
        embed.add_field(name="Message ID", value=before.id, inline=True)
        
        if before.content:
            before_content = before.content[:500] + "..." if len(before.content) > 500 else before.content
            embed.add_field(name="Before", value=f"```{before_content}```", inline=False)
        
        if after.content:
            after_content = after.content[:500] + "..." if len(after.content) > 500 else after.content
            embed.add_field(name="After", value=f"```{after_content}```", inline=False)
        
        embed.add_field(name="Jump to Message", value=f"[Click here]({after.jump_url})", inline=False)
        
        try:
            await log_channel.send(embed=embed)
        except:
            pass
    
    @commands.Cog.listener()
    async def on_member_update(self, before, after):
        """Log when a member is updated (roles, nickname, etc.)"""
        if not self.bot.config.log_channel:
            return
        
        log_channel = before.guild.get_channel(self.bot.config.log_channel)
        if not log_channel:
            return
        
        changes = []
        
        # Check nickname change
        if before.nick != after.nick:
            changes.append(f"**Nickname:** {before.nick or 'None'} → {after.nick or 'None'}")
        
        # Check role changes
        added_roles = set(after.roles) - set(before.roles)
        removed_roles = set(before.roles) - set(after.roles)
        
        if added_roles:
            roles = ", ".join([role.mention for role in added_roles])
            changes.append(f"**Added roles:** {roles}")
        
        if removed_roles:
            roles = ", ".join([role.mention for role in removed_roles])
            changes.append(f"**Removed roles:** {roles}")
        
        if not changes:
            return
        
        embed = discord.Embed(
            title="👤 Member Updated",
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        
        embed.add_field(name="Member", value=f"{after} ({after.id})", inline=True)
        embed.add_field(name="Changes", value="\n".join(changes), inline=False)
        
        try:
            await log_channel.send(embed=embed)
        except:
            pass
    
    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel):
        """Log when a channel is created"""
        if not self.bot.config.log_channel:
            return
        
        log_channel = channel.guild.get_channel(self.bot.config.log_channel)
        if not log_channel:
            return
        
        embed = discord.Embed(
            title="📢 Channel Created",
            color=discord.Color.green(),
            timestamp=datetime.now()
        )
        
        embed.add_field(name="Channel", value=f"{channel.mention} ({channel.id})", inline=True)
        embed.add_field(name="Type", value=str(channel.type).title(), inline=True)
        
        if hasattr(channel, 'category') and channel.category:
            embed.add_field(name="Category", value=channel.category.name, inline=True)
        
        try:
            await log_channel.send(embed=embed)
        except:
            pass
    
    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        """Log when a channel is deleted"""
        if not self.bot.config.log_channel:
            return
        
        log_channel = channel.guild.get_channel(self.bot.config.log_channel)
        if not log_channel or channel == log_channel:
            return
        
        embed = discord.Embed(
            title="🗑️ Channel Deleted",
            color=discord.Color.red(),
            timestamp=datetime.now()
        )
        
        embed.add_field(name="Channel", value=f"#{channel.name} ({channel.id})", inline=True)
        embed.add_field(name="Type", value=str(channel.type).title(), inline=True)
        
        if hasattr(channel, 'category') and channel.category:
            embed.add_field(name="Category", value=channel.category.name, inline=True)
        
        try:
            await log_channel.send(embed=embed)
        except:
            pass

async def setup(bot):
    await bot.add_cog(Logging(bot))
