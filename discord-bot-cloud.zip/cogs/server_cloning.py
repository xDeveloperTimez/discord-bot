"""
Advanced server cloning functionality
"""

import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import datetime
from utils.security import SecurityManager

def get_time_rn():
    """Get current time formatted"""
    date = datetime.datetime.now()
    return date.strftime("%H:%M:%S")

class ServerCloning(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="clone")
    async def clone_server(self, ctx, source_guild_id: int, target_guild_id: int):
        """Clone a server's structure to another server"""
        source_guild = self.bot.get_guild(source_guild_id)
        target_guild = self.bot.get_guild(target_guild_id)

        if not source_guild or not target_guild:
            await ctx.send("`-` **GUILD NOT FOUND**")
            await ctx.message.delete()
            return

        # Security validation - check permissions in BOTH source and target servers
        source_allowed, source_reason = await SecurityManager.check_server_permissions(ctx.author, source_guild, "copy_server")
        target_allowed, target_reason = await SecurityManager.check_server_permissions(ctx.author, target_guild, "copy_server")
        
        if not source_allowed:
            embed = await SecurityManager.create_security_embed(source_allowed, f"Source server: {source_reason}", "copy_server", source_guild.name)
            await ctx.send(embed=embed)
            return
            
        if not target_allowed:
            embed = await SecurityManager.create_security_embed(target_allowed, f"Target server: {target_reason}", "copy_server", target_guild.name)
            await ctx.send(embed=embed)
            return

        # Delete all channels in the target guild
        for channel in target_guild.channels:
            try:
                await channel.delete()
                print(f"[ {get_time_rn()} ] CHANNEL {channel.name} HAS BEEN DELETED ON THE TARGET GUILD")
            except Exception as e:
                print(f"[ {get_time_rn()} ] ERROR DELETING CHANNEL {channel.name}: {e}")

        # Delete all roles in the target guild except for @everyone
        for role in target_guild.roles:
            if role.name != "@everyone":
                try:
                    await role.delete()
                    print(f"[ {get_time_rn()} ] ROLE {role.name} HAS BEEN DELETED ON THE TARGET GUILD")
                except Exception as e:
                    print(f"[ {get_time_rn()} ] ERROR DELETING ROLE {role.name}: {e}")

        # Clone roles from source to target in correct order (highest to lowest)
        roles_to_create = sorted(
            [role for role in source_guild.roles if role.name != "@everyone"],
            key=lambda r: r.position,
            reverse=True
        )

        # Create roles in correct order
        role_mapping = {}
        for role in roles_to_create:
            try:
                new_role = await target_guild.create_role(
                    name=role.name,
                    permissions=role.permissions,
                    color=role.color,
                    hoist=role.hoist,
                    mentionable=role.mentionable
                )
                role_mapping[role.id] = new_role
                print(f"[ {get_time_rn()} ] {role.name} HAS BEEN CREATED ON THE TARGET GUILD")
            except Exception as e:
                print(f"[ {get_time_rn()} ] ERROR CREATING ROLE {role.name}: {e}")

        # Create @everyone role permissions
        everyone_role = target_guild.default_role
        source_everyone = discord.utils.get(source_guild.roles, name="@everyone")
        if source_everyone:
            try:
                await everyone_role.edit(permissions=source_everyone.permissions)
                print(f"[ {get_time_rn()} ] UPDATED @everyone PERMISSIONS")
            except Exception as e:
                print(f"[ {get_time_rn()} ] ERROR UPDATING @everyone PERMISSIONS: {e}")

        # Clone categories and channels with proper permissions
        category_mapping = {}
        
        # Process categories in order
        categories = sorted(source_guild.categories, key=lambda c: c.position)
        for category in categories:
            try:
                # Create category with same permissions
                overwrites = {}
                for target, overwrite in category.overwrites.items():
                    if isinstance(target, discord.Role):
                        if target.id in role_mapping:
                            overwrites[role_mapping[target.id]] = overwrite
                    elif isinstance(target, discord.Member):
                        # Skip member-specific overwrites for simplicity
                        continue
                
                new_category = await target_guild.create_category(
                    name=category.name,
                    overwrites=overwrites,
                    position=category.position
                )
                category_mapping[category.id] = new_category
                print(f"[ {get_time_rn()} ] CATEGORY {category.name} CREATED")
            except Exception as e:
                print(f"[ {get_time_rn()} ] ERROR CREATING CATEGORY {category.name}: {e}")

        # Process channels in order
        channels = sorted(source_guild.channels, key=lambda c: c.position)
        for channel in channels:
            try:
                # Skip if channel is a category
                if isinstance(channel, discord.CategoryChannel):
                    continue
                    
                # Get the category for this channel
                category = None
                if channel.category and channel.category.id in category_mapping:
                    category = category_mapping[channel.category.id]
                
                # Prepare permission overwrites
                overwrites = {}
                for target, overwrite in channel.overwrites.items():
                    if isinstance(target, discord.Role):
                        if target.id in role_mapping:
                            overwrites[role_mapping[target.id]] = overwrite
                    elif isinstance(target, discord.Member):
                        # Skip member-specific overwrites for simplicity
                        continue
                
                # Create the channel with proper permissions
                if isinstance(channel, discord.TextChannel):
                    new_channel = await target_guild.create_text_channel(
                        name=channel.name,
                        category=category,
                        overwrites=overwrites,
                        position=channel.position,
                        topic=channel.topic,
                        slowmode_delay=channel.slowmode_delay,
                        nsfw=channel.nsfw
                    )
                elif isinstance(channel, discord.VoiceChannel):
                    new_channel = await target_guild.create_voice_channel(
                        name=channel.name,
                        category=category,
                        overwrites=overwrites,
                        position=channel.position,
                        bitrate=channel.bitrate,
                        user_limit=channel.user_limit
                    )
                
                print(f"[ {get_time_rn()} ] CHANNEL {channel.name} CREATED")
            except Exception as e:
                print(f"[ {get_time_rn()} ] ERROR CREATING CHANNEL {channel.name}: {e}")

        await ctx.send("`-` **SERVER CLONED SUCCESSFULLY**")
        await ctx.message.delete()

    @app_commands.command(name="cloneserver", description="Clone a server's structure to another server")
    @app_commands.describe(
        source_guild_id="Source server ID to clone from",
        target_guild_id="Target server ID to clone to"
    )
    @app_commands.default_permissions(administrator=True)
    async def clone_server_slash(self, interaction: discord.Interaction, source_guild_id: str, target_guild_id: str):
        """Clone a server's structure with slash command interface"""
        
        # Security validation - check permissions in both servers
        source_guild = self.bot.get_guild(int(source_guild_id))
        target_guild = self.bot.get_guild(int(target_guild_id))
        
        if not source_guild or not target_guild:
            embed = discord.Embed(
                title="❌ Error",
                description="One or both servers not found",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
            
        # Check permissions in both servers
        source_allowed, source_reason = await SecurityManager.check_server_permissions(interaction.user, source_guild, "clone_server")
        target_allowed, target_reason = await SecurityManager.check_server_permissions(interaction.user, target_guild, "clone_server")
        
        if not source_allowed:
            embed = await SecurityManager.create_security_embed(source_allowed, f"Source server: {source_reason}", "clone_server", source_guild.name)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
            
        if not target_allowed:
            embed = await SecurityManager.create_security_embed(target_allowed, f"Target server: {target_reason}", "clone_server", target_guild.name)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        class ConfirmView(discord.ui.View):
            def __init__(self, cog, source_id, target_id):
                super().__init__(timeout=60)
                self.cog = cog
                self.source_id = int(source_id)
                self.target_id = int(target_id)
            
            @discord.ui.button(label="CONFIRM CLONE", style=discord.ButtonStyle.danger)
            async def confirm_clone(self, interaction: discord.Interaction, button: discord.ui.Button):
                await interaction.response.defer(ephemeral=True)
                
                source_guild = self.cog.bot.get_guild(self.source_id)
                target_guild = self.cog.bot.get_guild(self.target_id)

                if not source_guild or not target_guild:
                    embed = discord.Embed(
                        title="❌ Error",
                        description="One or both servers not found",
                        color=discord.Color.red()
                    )
                    await interaction.followup.send(embed=embed)
                    return

                embed = discord.Embed(
                    title="🔄 Cloning Server",
                    description=f"Cloning {source_guild.name} → {target_guild.name}\nThis may take several minutes...",
                    color=discord.Color.orange()
                )
                await interaction.followup.send(embed=embed)

                # Perform the cloning operation (same logic as prefix command)
                try:
                    # Delete all channels in target guild
                    for channel in target_guild.channels:
                        try:
                            await channel.delete()
                        except:
                            continue

                    # Delete all roles except @everyone
                    for role in target_guild.roles:
                        if role.name != "@everyone":
                            try:
                                await role.delete()
                            except:
                                continue

                    # Clone roles
                    roles_to_create = sorted(
                        [role for role in source_guild.roles if role.name != "@everyone"],
                        key=lambda r: r.position,
                        reverse=True
                    )

                    role_mapping = {}
                    for role in roles_to_create:
                        try:
                            new_role = await target_guild.create_role(
                                name=role.name,
                                permissions=role.permissions,
                                color=role.color,
                                hoist=role.hoist,
                                mentionable=role.mentionable
                            )
                            role_mapping[role.id] = new_role
                        except:
                            continue

                    # Clone categories and channels
                    category_mapping = {}
                    categories = sorted(source_guild.categories, key=lambda c: c.position)
                    for category in categories:
                        try:
                            overwrites = {}
                            for target, overwrite in category.overwrites.items():
                                if isinstance(target, discord.Role) and target.id in role_mapping:
                                    overwrites[role_mapping[target.id]] = overwrite
                            
                            new_category = await target_guild.create_category(
                                name=category.name,
                                overwrites=overwrites,
                                position=category.position
                            )
                            category_mapping[category.id] = new_category
                        except:
                            continue

                    channels = sorted(source_guild.channels, key=lambda c: c.position)
                    for channel in channels:
                        if isinstance(channel, discord.CategoryChannel):
                            continue
                            
                        try:
                            category = None
                            if channel.category and channel.category.id in category_mapping:
                                category = category_mapping[channel.category.id]
                            
                            overwrites = {}
                            for target, overwrite in channel.overwrites.items():
                                if isinstance(target, discord.Role) and target.id in role_mapping:
                                    overwrites[role_mapping[target.id]] = overwrite
                            
                            if isinstance(channel, discord.TextChannel):
                                await target_guild.create_text_channel(
                                    name=channel.name,
                                    category=category,
                                    overwrites=overwrites,
                                    position=channel.position,
                                    topic=channel.topic,
                                    slowmode_delay=channel.slowmode_delay,
                                    nsfw=channel.nsfw
                                )
                            elif isinstance(channel, discord.VoiceChannel):
                                await target_guild.create_voice_channel(
                                    name=channel.name,
                                    category=category,
                                    overwrites=overwrites,
                                    position=channel.position,
                                    bitrate=channel.bitrate,
                                    user_limit=channel.user_limit
                                )
                        except:
                            continue

                    final_embed = discord.Embed(
                        title="✅ Server Cloned",
                        description="Server structure cloned successfully",
                        color=discord.Color.green()
                    )
                    await interaction.followup.send(embed=final_embed)

                except Exception as e:
                    error_embed = discord.Embed(
                        title="❌ Clone Failed",
                        description=f"Error during cloning: {str(e)}",
                        color=discord.Color.red()
                    )
                    await interaction.followup.send(embed=error_embed)
            
            @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
            async def cancel_clone(self, interaction: discord.Interaction, button: discord.ui.Button):
                embed = discord.Embed(
                    title="❌ Cancelled",
                    description="Server cloning cancelled",
                    color=discord.Color.green()
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)

        source_guild = self.bot.get_guild(int(source_guild_id))
        target_guild = self.bot.get_guild(int(target_guild_id))
        
        if not source_guild or not target_guild:
            embed = discord.Embed(
                title="❌ Error",
                description="One or both server IDs are invalid",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        embed = discord.Embed(
            title="⚠️ DANGER: CLONE SERVER",
            description=f"**This will completely replace {target_guild.name} with {source_guild.name}'s structure!**\n\nAll channels, roles, and permissions will be deleted and recreated.\n\nThis action cannot be undone. Are you absolutely sure?",
            color=discord.Color.red()
        )
        view = ConfirmView(self, source_guild_id, target_guild_id)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

async def setup(bot):
    await bot.add_cog(ServerCloning(bot))