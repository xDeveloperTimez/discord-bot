"""
Utility commands cog
"""

import discord
from discord.ext import commands
from discord import app_commands
import random
import asyncio
from datetime import datetime
import platform
import psutil

class Utility(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="ping", description="Check bot latency")
    async def ping(self, interaction: discord.Interaction):
        """Check bot ping and latency"""
        embed = discord.Embed(
            title="🏓 Pong!",
            color=discord.Color.blue()
        )
        embed.add_field(name="Latency", value=f"{round(self.bot.latency * 1000)}ms", inline=True)
        embed.add_field(name="Response Time", value="Calculating...", inline=True)
        
        start_time = datetime.now()
        await interaction.response.send_message(embed=embed)
        end_time = datetime.now()
        
        response_time = (end_time - start_time).total_seconds() * 1000
        embed.set_field_at(1, name="Response Time", value=f"{round(response_time)}ms", inline=True)
        
        await interaction.edit_original_response(embed=embed)
    
    @app_commands.command(name="serverinfo", description="Get information about the server")
    async def serverinfo(self, interaction: discord.Interaction):
        """Display server information"""
        guild = interaction.guild
        
        embed = discord.Embed(
            title=f"📊 {guild.name}",
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)
        
        # Basic info
        embed.add_field(name="Owner", value=guild.owner.mention if guild.owner else "Unknown", inline=True)
        embed.add_field(name="Created", value=f"<t:{int(guild.created_at.timestamp())}:F>", inline=True)
        embed.add_field(name="Members", value=guild.member_count, inline=True)
        
        # Counts
        text_channels = len([c for c in guild.channels if isinstance(c, discord.TextChannel)])
        voice_channels = len([c for c in guild.channels if isinstance(c, discord.VoiceChannel)])
        categories = len(guild.categories)
        
        embed.add_field(name="Text Channels", value=text_channels, inline=True)
        embed.add_field(name="Voice Channels", value=voice_channels, inline=True)
        embed.add_field(name="Categories", value=categories, inline=True)
        
        embed.add_field(name="Roles", value=len(guild.roles), inline=True)
        embed.add_field(name="Emojis", value=len(guild.emojis), inline=True)
        embed.add_field(name="Boost Level", value=guild.premium_tier, inline=True)
        
        # Features
        features = []
        if "COMMUNITY" in guild.features:
            features.append("Community Server")
        if "PARTNERED" in guild.features:
            features.append("Partnered")
        if "VERIFIED" in guild.features:
            features.append("Verified")
        if "VANITY_URL" in guild.features:
            features.append("Vanity URL")
        
        if features:
            embed.add_field(name="Features", value=", ".join(features), inline=False)
        
        embed.set_footer(text=f"Server ID: {guild.id}")
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="userinfo", description="Get information about a user")
    @app_commands.describe(member="The member to get info about")
    async def userinfo(self, interaction: discord.Interaction, member: discord.Member = None):
        """Display user information"""
        if member is None:
            member = interaction.user
        
        embed = discord.Embed(
            title=f"👤 {member}",
            color=member.color if member.color != discord.Color.default() else discord.Color.blue(),
            timestamp=datetime.now()
        )
        
        embed.set_thumbnail(url=member.display_avatar.url)
        
        # Basic info
        embed.add_field(name="Username", value=f"{member.name}#{member.discriminator}", inline=True)
        embed.add_field(name="Display Name", value=member.display_name, inline=True)
        embed.add_field(name="ID", value=member.id, inline=True)
        
        # Dates
        embed.add_field(name="Account Created", value=f"<t:{int(member.created_at.timestamp())}:F>", inline=True)
        embed.add_field(name="Joined Server", value=f"<t:{int(member.joined_at.timestamp())}:F>", inline=True)
        embed.add_field(name="Bot Account", value="Yes" if member.bot else "No", inline=True)
        
        # Roles (excluding @everyone)
        roles = [role.mention for role in member.roles[1:]]
        if roles:
            embed.add_field(name=f"Roles ({len(roles)})", value=" ".join(roles) if len(" ".join(roles)) <= 1024 else f"{len(roles)} roles", inline=False)
        
        # Permissions
        key_perms = []
        if member.guild_permissions.administrator:
            key_perms.append("Administrator")
        elif member.guild_permissions.manage_guild:
            key_perms.append("Manage Server")
        elif member.guild_permissions.manage_channels:
            key_perms.append("Manage Channels")
        elif member.guild_permissions.manage_messages:
            key_perms.append("Manage Messages")
        elif member.guild_permissions.kick_members:
            key_perms.append("Kick Members")
        elif member.guild_permissions.ban_members:
            key_perms.append("Ban Members")
        
        if key_perms:
            embed.add_field(name="Key Permissions", value=", ".join(key_perms), inline=False)
        
        embed.set_footer(text=f"Requested by {interaction.user}")
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="avatar", description="Get a user's avatar")
    @app_commands.describe(member="The member to get avatar from")
    async def avatar(self, interaction: discord.Interaction, member: discord.Member = None):
        """Display user's avatar"""
        if member is None:
            member = interaction.user
        
        embed = discord.Embed(
            title=f"🖼️ {member.display_name}'s Avatar",
            color=member.color if member.color != discord.Color.default() else discord.Color.blue()
        )
        
        embed.set_image(url=member.display_avatar.url)
        embed.add_field(name="Download Links", 
                       value=f"[PNG]({member.display_avatar.with_format('png').url}) | [JPG]({member.display_avatar.with_format('jpg').url}) | [WEBP]({member.display_avatar.with_format('webp').url})", 
                       inline=False)
        
        await interaction.response.send_message(embed=embed)

    @commands.command(name="pfp", aliases=["avatar"])
    async def pfp_prefix(self, ctx, member: discord.Member = None):
        """Display user's avatar (prefix version)"""
        if member is None:
            member = ctx.author
        
        embed = discord.Embed(
            title=f"🖼️ {member.display_name}'s Avatar",
            color=member.color if member.color != discord.Color.default() else discord.Color.blue()
        )
        
        embed.set_image(url=member.display_avatar.url)
        embed.add_field(name="Download Links", 
                       value=f"[PNG]({member.display_avatar.with_format('png').url}) | [JPG]({member.display_avatar.with_format('jpg').url}) | [WEBP]({member.display_avatar.with_format('webp').url})", 
                       inline=False)
        
        await ctx.send(embed=embed)
    
    @app_commands.command(name="poll", description="Create a poll")
    @app_commands.describe(
        question="The poll question",
        option1="First option",
        option2="Second option",
        option3="Third option (optional)",
        option4="Fourth option (optional)",
        option5="Fifth option (optional)"
    )
    async def poll(self, interaction: discord.Interaction, question: str, option1: str, option2: str, 
                  option3: str = None, option4: str = None, option5: str = None):
        """Create a poll with reactions"""
        options = [option1, option2]
        if option3:
            options.append(option3)
        if option4:
            options.append(option4)
        if option5:
            options.append(option5)
        
        reactions = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣"]
        
        embed = discord.Embed(
            title="📊 Poll",
            description=question,
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        
        for i, option in enumerate(options):
            embed.add_field(name=f"{reactions[i]} Option {i+1}", value=option, inline=False)
        
        embed.set_footer(text=f"Poll created by {interaction.user}")
        
        await interaction.response.send_message(embed=embed)
        message = await interaction.original_response()
        
        for i in range(len(options)):
            await message.add_reaction(reactions[i])
    
    @app_commands.command(name="8ball", description="Ask the magic 8-ball a question")
    @app_commands.describe(question="Your question for the 8-ball")
    async def eightball(self, interaction: discord.Interaction, question: str):
        """Magic 8-ball command"""
        responses = [
            "It is certain.", "It is decidedly so.", "Without a doubt.",
            "Yes definitely.", "You may rely on it.", "As I see it, yes.",
            "Most likely.", "Outlook good.", "Yes.", "Signs point to yes.",
            "Reply hazy, try again.", "Ask again later.", "Better not tell you now.",
            "Cannot predict now.", "Concentrate and ask again.", "Don't count on it.",
            "My reply is no.", "My sources say no.", "Outlook not so good.",
            "Very doubtful."
        ]
        
        embed = discord.Embed(
            title="🎱 Magic 8-Ball",
            color=discord.Color.purple()
        )
        embed.add_field(name="Question", value=question, inline=False)
        embed.add_field(name="Answer", value=random.choice(responses), inline=False)
        embed.set_footer(text=f"Asked by {interaction.user}")
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="flip", description="Flip a coin")
    async def flip(self, interaction: discord.Interaction):
        """Flip a coin"""
        result = random.choice(["Heads", "Tails"])
        emoji = "🪙"
        
        embed = discord.Embed(
            title=f"{emoji} Coin Flip",
            description=f"The coin landed on **{result}**!",
            color=discord.Color.gold()
        )
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="roll", description="Roll dice")
    @app_commands.describe(
        dice="Number of dice to roll (default: 1)",
        sides="Number of sides on each die (default: 6)"
    )
    async def roll(self, interaction: discord.Interaction, dice: int = 1, sides: int = 6):
        """Roll dice"""
        if dice < 1 or dice > 10:
            embed = discord.Embed(
                title="❌ Invalid Input",
                description="Number of dice must be between 1 and 10.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        if sides < 2 or sides > 100:
            embed = discord.Embed(
                title="❌ Invalid Input",
                description="Number of sides must be between 2 and 100.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        rolls = [random.randint(1, sides) for _ in range(dice)]
        total = sum(rolls)
        
        embed = discord.Embed(
            title="🎲 Dice Roll",
            color=discord.Color.blue()
        )
        
        if dice == 1:
            embed.add_field(name="Result", value=f"**{rolls[0]}**", inline=False)
        else:
            embed.add_field(name="Rolls", value=" + ".join(map(str, rolls)), inline=False)
            embed.add_field(name="Total", value=f"**{total}**", inline=False)
        
        embed.add_field(name="Dice", value=f"{dice}d{sides}", inline=True)
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="choose", description="Choose randomly from a list of options")
    @app_commands.describe(options="Options separated by commas")
    async def choose(self, interaction: discord.Interaction, options: str):
        """Choose randomly from options"""
        choices = [choice.strip() for choice in options.split(",")]
        
        if len(choices) < 2:
            embed = discord.Embed(
                title="❌ Not Enough Options",
                description="Please provide at least 2 options separated by commas.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        if len(choices) > 10:
            embed = discord.Embed(
                title="❌ Too Many Options",
                description="Please provide no more than 10 options.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        chosen = random.choice(choices)
        
        embed = discord.Embed(
            title="🎯 Random Choice",
            description=f"I choose: **{chosen}**",
            color=discord.Color.green()
        )
        embed.add_field(name="Options", value=", ".join(choices), inline=False)
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="botinfo", description="Get information about the bot")
    async def botinfo(self, interaction: discord.Interaction):
        """Display bot information"""
        embed = discord.Embed(
            title="🤖 Bot Information",
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        
        embed.set_thumbnail(url=self.bot.user.display_avatar.url)
        
        # Basic info
        embed.add_field(name="Bot Name", value=self.bot.user.name, inline=True)
        embed.add_field(name="Bot ID", value=self.bot.user.id, inline=True)
        embed.add_field(name="Created", value=f"<t:{int(self.bot.user.created_at.timestamp())}:F>", inline=True)
        
        # Stats
        embed.add_field(name="Servers", value=len(self.bot.guilds), inline=True)
        embed.add_field(name="Users", value=sum(guild.member_count for guild in self.bot.guilds), inline=True)
        embed.add_field(name="Commands", value=len(self.bot.tree.get_commands()), inline=True)
        
        # Technical info
        embed.add_field(name="Python Version", value=platform.python_version(), inline=True)
        embed.add_field(name="discord.py Version", value=discord.__version__, inline=True)
        embed.add_field(name="Latency", value=f"{round(self.bot.latency * 1000)}ms", inline=True)
        
        # System info
        try:
            memory = psutil.virtual_memory()
            cpu_percent = psutil.cpu_percent()
            embed.add_field(name="Memory Usage", value=f"{memory.percent}%", inline=True)
            embed.add_field(name="CPU Usage", value=f"{cpu_percent}%", inline=True)
        except:
            pass
        
        embed.set_footer(text=f"Requested by {interaction.user}")
        
        await interaction.response.send_message(embed=embed)

    # Prefix command versions
    @commands.command(name="ping")
    async def ping_prefix(self, ctx):
        """Check bot latency (prefix version)"""
        latency = round(self.bot.latency * 1000)
        embed = discord.Embed(
            title="🏓 Pong!",
            color=discord.Color.green()
        )
        embed.add_field(name="Latency", value=f"{latency}ms", inline=True)
        await ctx.send(embed=embed)

    @commands.command(name="serverinfo")
    async def serverinfo_prefix(self, ctx):
        """Get information about the server (prefix version)"""
        guild = ctx.guild
        embed = discord.Embed(
            title=f"📊 {guild.name}",
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)
        
        embed.add_field(name="Owner", value=guild.owner.mention if guild.owner else "Unknown", inline=True)
        embed.add_field(name="Created", value=f"<t:{int(guild.created_at.timestamp())}:F>", inline=True)
        embed.add_field(name="Members", value=guild.member_count, inline=True)
        
        text_channels = len([c for c in guild.channels if isinstance(c, discord.TextChannel)])
        voice_channels = len([c for c in guild.channels if isinstance(c, discord.VoiceChannel)])
        categories = len(guild.categories)
        
        embed.add_field(name="Text Channels", value=text_channels, inline=True)
        embed.add_field(name="Voice Channels", value=voice_channels, inline=True)
        embed.add_field(name="Categories", value=categories, inline=True)
        
        await ctx.send(embed=embed)

    @commands.command(name="userinfo")
    async def userinfo_prefix(self, ctx, member: discord.Member = None):
        """Get information about a user (prefix version)"""
        if member is None:
            member = ctx.author
        
        embed = discord.Embed(
            title=f"👤 {member.display_name}",
            color=member.color if member.color != discord.Color.default() else discord.Color.blue(),
            timestamp=datetime.now()
        )
        
        embed.set_thumbnail(url=member.display_avatar.url)
        
        embed.add_field(name="Username", value=str(member), inline=True)
        embed.add_field(name="ID", value=member.id, inline=True)
        embed.add_field(name="Joined Server", value=f"<t:{int(member.joined_at.timestamp())}:F>", inline=True)
        embed.add_field(name="Account Created", value=f"<t:{int(member.created_at.timestamp())}:F>", inline=True)
        
        roles = [role.mention for role in member.roles[1:]]  # Exclude @everyone
        if roles:
            embed.add_field(name=f"Roles ({len(roles)})", value=" ".join(roles) if len(" ".join(roles)) <= 1024 else f"{len(roles)} roles", inline=False)
        
        await ctx.send(embed=embed)

    @commands.command(name="roll")
    async def roll_prefix(self, ctx, dice: int = 1, sides: int = 6):
        """Roll dice (prefix version)"""
        if dice < 1 or dice > 10 or sides < 2 or sides > 100:
            await ctx.send("❌ Invalid input. Dice must be 1-10, sides must be 2-100.")
            return
        
        rolls = [random.randint(1, sides) for _ in range(dice)]
        total = sum(rolls)
        
        embed = discord.Embed(title="🎲 Dice Roll", color=discord.Color.blue())
        if dice == 1:
            embed.add_field(name="Result", value=f"**{rolls[0]}**", inline=False)
        else:
            embed.add_field(name="Rolls", value=" + ".join(map(str, rolls)), inline=False)
            embed.add_field(name="Total", value=f"**{total}**", inline=False)
        
        await ctx.send(embed=embed)

    @commands.command(name="choose")
    async def choose_prefix(self, ctx, *, choices):
        """Choose randomly from options (prefix version)"""
        choices = [choice.strip() for choice in choices.split(",")]
        if len(choices) < 2:
            await ctx.send("❌ Please provide at least 2 choices separated by commas.")
            return
        
        chosen = random.choice(choices)
        embed = discord.Embed(
            title="🎯 Random Choice",
            description=f"I choose: **{chosen}**",
            color=discord.Color.green()
        )
        await ctx.send(embed=embed)

    @commands.command(name="botinfo")
    async def botinfo_prefix(self, ctx):
        """Display bot information (prefix version)"""
        embed = discord.Embed(
            title="🤖 Bot Information",
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        
        embed.set_thumbnail(url=self.bot.user.display_avatar.url)
        embed.add_field(name="Bot Name", value=self.bot.user.name, inline=True)
        embed.add_field(name="Servers", value=len(self.bot.guilds), inline=True)
        embed.add_field(name="Users", value=sum(guild.member_count for guild in self.bot.guilds), inline=True)
        
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Utility(bot))
