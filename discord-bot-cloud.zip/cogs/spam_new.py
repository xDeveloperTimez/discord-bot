"""
Ultimate spam system with maximum compatibility
"""
import discord
from discord.ext import commands
from discord import app_commands
import asyncio

class UltimateSpamModal(discord.ui.Modal, title='Ultimate Spam System'):
    def __init__(self, message_count, target_channel):
        super().__init__()
        self.message_count = message_count
        self.target_channel = target_channel

    message = discord.ui.TextInput(
        label='Message to Spam',
        placeholder='Enter your message...',
        max_length=2000,
        style=discord.TextStyle.paragraph
    )

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)

        message_content = self.message.value
        channel = self.target_channel
        
        debug_info = []
        debug_info.append(f"Target: #{channel.name}")
        debug_info.append(f"Count: {self.message_count}")

        try:
            sent_count = 0
            failed_count = 0
            methods_used = []

            # Ultimate spam loop - multiple attack vectors
            for i in range(self.message_count):
                success = False
                
                # Content variation for evasion
                current_content = message_content
                if i > 0:
                    variations = [
                        message_content,
                        f"{message_content}\u200b",  # Zero-width space
                        f"\u200b{message_content}",  # Zero-width prefix
                        message_content + ("\u2009" if i % 5 == 0 else ""),  # Thin space
                    ]
                    current_content = variations[i % len(variations)]

                # Method 1: Direct message send (fastest)
                if not success:
                    try:
                        await channel.send(current_content)
                        sent_count += 1
                        success = True
                        if "direct" not in methods_used:
                            methods_used.append("direct")
                    except Exception as e:
                        if failed_count < 3:
                            debug_info.append(f"Direct failed: {str(e)[:50]}")

                # Method 2: Webhook creation and send
                if not success and hasattr(channel, 'create_webhook'):
                    try:
                        webhook = await channel.create_webhook(name="Guardian")
                        await webhook.send(
                            content=current_content,
                            username="Guardian"
                        )
                        await webhook.delete()
                        sent_count += 1
                        success = True
                        if "webhook" not in methods_used:
                            methods_used.append("webhook")
                    except Exception as e:
                        if failed_count < 3:
                            debug_info.append(f"Webhook failed: {str(e)[:50]}")

                # Failure tracking
                if not success:
                    failed_count += 1

                # Timing for maximum throughput
                if success:
                    if sent_count % 8 == 0:
                        await asyncio.sleep(1.0)  # Break every 8 messages
                    else:
                        await asyncio.sleep(0.08)  # Fast sending
                else:
                    await asyncio.sleep(0.2)

                # Emergency stop
                if failed_count > 15:
                    debug_info.append("Too many failures - stopped")
                    break

            # Results
            if sent_count > 0:
                success_rate = (sent_count / self.message_count) * 100
                color = 0x00ff00 if success_rate > 80 else 0xffaa00 if success_rate > 40 else 0xff0000
                title = "Spam Complete" if success_rate > 80 else "Partial Success"
                description = f"**{sent_count}/{self.message_count}** sent ({success_rate:.1f}%)"
            else:
                color = 0xff0000
                title = "Spam Failed"
                description = "No messages sent - check permissions"

            embed = discord.Embed(title=title, description=description, color=color)
            embed.add_field(name="Message", value=f"```{message_content[:100]}```", inline=False)
            embed.add_field(name="Channel", value=f"#{channel.name}", inline=True)
            embed.add_field(name="Methods", value=", ".join(methods_used) or "None", inline=True)
            
            if debug_info:
                embed.add_field(name="Debug", value="\n".join(debug_info[-5:]), inline=False)

            await interaction.followup.send(embed=embed, ephemeral=True)

        except Exception as e:
            error_embed = discord.Embed(
                title="System Error",
                description=f"Error: {str(e)}",
                color=0xff0000
            )
            await interaction.followup.send(embed=error_embed, ephemeral=True)


class UltimateSpamView(discord.ui.View):
    def __init__(self, message_count, target_channel):
        super().__init__(timeout=300)
        self.message_count = message_count
        self.target_channel = target_channel

    @discord.ui.button(label='🚀 START SPAM', style=discord.ButtonStyle.danger)
    async def start_spam(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != 344210326251896834:
            await interaction.response.send_message("Owner only.", ephemeral=True)
            return

        modal = UltimateSpamModal(self.message_count, self.target_channel)
        await interaction.response.send_modal(modal)


class UltimateSpam(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="spam", description="Ultimate spam system")
    @app_commands.describe(
        count="Messages to send (1-100)",
        channel="Target channel"
    )
    async def spam(
        self, 
        interaction: discord.Interaction, 
        count: int = 50,
        channel: discord.TextChannel = None
    ):
        """Ultimate spam command"""
        
        if interaction.user.id != 344210326251896834:
            await interaction.response.send_message("Owner only.", ephemeral=True)
            return

        if count < 1 or count > 100:
            await interaction.response.send_message("Count must be 1-100.", ephemeral=True)
            return

        target = channel or interaction.channel

        embed = discord.Embed(
            title="🚀 Ultimate Spam System",
            description=f"Ready to send **{count} messages** to {target.mention}",
            color=0xff0000
        )
        
        embed.add_field(name="Target", value=target.mention, inline=True)
        embed.add_field(name="Count", value=str(count), inline=True)
        embed.add_field(name="User", value=interaction.user.mention, inline=True)

        view = UltimateSpamView(count, target)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)


async def setup(bot):
    await bot.add_cog(UltimateSpam(bot))