"""
Role management cog
"""

import discord
from discord.ext import commands
from discord import app_commands
from utils.checks import is_moderator, is_admin

class Roles(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="addrole", description="Add a role to a member")
    @app_commands.describe(
        member="The member to add the role to",
        role="The role to add"
    )
    async def addrole(self, interaction: discord.Interaction, member: discord.Member, role: discord.Role):
        """Add a role to a member"""
        if not is_moderator(interaction.user, self.bot.config):
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You need moderator permissions to use this command.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        if role >= interaction.user.top_role and interaction.user != interaction.guild.owner:
            embed = discord.Embed(
                title="❌ Insufficient Permissions",
                description="You cannot assign this role due to role hierarchy.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        if role >= interaction.guild.me.top_role:
            embed = discord.Embed(
                title="❌ Bot Insufficient Permissions",
                description="I cannot assign this role due to role hierarchy.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        if role in member.roles:
            embed = discord.Embed(
                title="❌ Role Already Assigned",
                description=f"{member.mention} already has the {role.mention} role.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            await member.add_roles(role, reason=f"Role added by {interaction.user}")
            
            embed = discord.Embed(
                title="✅ Role Added",
                description=f"Successfully added {role.mention} to {member.mention}.",
                color=discord.Color.green()
            )
            embed.add_field(name="Moderator", value=interaction.user.mention, inline=False)
            
            await interaction.response.send_message(embed=embed)
            
        except discord.Forbidden:
            embed = discord.Embed(
                title="❌ Missing Permissions",
                description="I don't have permission to manage roles for this member.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="removerole", description="Remove a role from a member")
    @app_commands.describe(
        member="The member to remove the role from",
        role="The role to remove"
    )
    async def removerole(self, interaction: discord.Interaction, member: discord.Member, role: discord.Role):
        """Remove a role from a member"""
        if not is_moderator(interaction.user, self.bot.config):
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You need moderator permissions to use this command.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        if role >= interaction.user.top_role and interaction.user != interaction.guild.owner:
            embed = discord.Embed(
                title="❌ Insufficient Permissions",
                description="You cannot remove this role due to role hierarchy.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        if role >= interaction.guild.me.top_role:
            embed = discord.Embed(
                title="❌ Bot Insufficient Permissions",
                description="I cannot remove this role due to role hierarchy.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        if role not in member.roles:
            embed = discord.Embed(
                title="❌ Role Not Found",
                description=f"{member.mention} doesn't have the {role.mention} role.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            await member.remove_roles(role, reason=f"Role removed by {interaction.user}")
            
            embed = discord.Embed(
                title="✅ Role Removed",
                description=f"Successfully removed {role.mention} from {member.mention}.",
                color=discord.Color.green()
            )
            embed.add_field(name="Moderator", value=interaction.user.mention, inline=False)
            
            await interaction.response.send_message(embed=embed)
            
        except discord.Forbidden:
            embed = discord.Embed(
                title="❌ Missing Permissions",
                description="I don't have permission to manage roles for this member.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="createrole", description="Create a new role")
    @app_commands.describe(
        name="Name of the role",
        color="Hex color code (e.g., #ff0000)",
        mentionable="Whether the role can be mentioned",
        hoisted="Whether the role is displayed separately"
    )
    async def createrole(self, interaction: discord.Interaction, name: str, 
                        color: str = None, mentionable: bool = False, hoisted: bool = False):
        """Create a new role"""
        if not is_admin(interaction.user, self.bot.config):
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You need administrator permissions to use this command.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        if not interaction.guild.me.guild_permissions.manage_roles:
            embed = discord.Embed(
                title="❌ Missing Permissions",
                description="I don't have permission to manage roles.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Parse color
        role_color = discord.Color.default()
        if color:
            try:
                if color.startswith('#'):
                    color = color[1:]
                role_color = discord.Color(int(color, 16))
            except ValueError:
                embed = discord.Embed(
                    title="❌ Invalid Color",
                    description="Please provide a valid hex color code (e.g., #ff0000).",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
        
        try:
            role = await interaction.guild.create_role(
                name=name,
                color=role_color,
                mentionable=mentionable,
                hoist=hoisted,
                reason=f"Role created by {interaction.user}"
            )
            
            embed = discord.Embed(
                title="✅ Role Created",
                description=f"Successfully created role {role.mention}.",
                color=role.color
            )
            embed.add_field(name="Name", value=role.name, inline=True)
            embed.add_field(name="Color", value=str(role.color), inline=True)
            embed.add_field(name="Mentionable", value="Yes" if role.mentionable else "No", inline=True)
            embed.add_field(name="Hoisted", value="Yes" if role.hoist else "No", inline=True)
            embed.add_field(name="Created by", value=interaction.user.mention, inline=False)
            
            await interaction.response.send_message(embed=embed)
            
        except discord.Forbidden:
            embed = discord.Embed(
                title="❌ Missing Permissions",
                description="I don't have permission to create roles.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
        except discord.HTTPException as e:
            embed = discord.Embed(
                title="❌ Failed to Create Role",
                description=f"An error occurred: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="deleterole", description="Delete a role")
    @app_commands.describe(role="The role to delete")
    async def deleterole(self, interaction: discord.Interaction, role: discord.Role):
        """Delete a role"""
        if not is_admin(interaction.user, self.bot.config):
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You need administrator permissions to use this command.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        if role >= interaction.user.top_role and interaction.user != interaction.guild.owner:
            embed = discord.Embed(
                title="❌ Insufficient Permissions",
                description="You cannot delete this role due to role hierarchy.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        if role >= interaction.guild.me.top_role:
            embed = discord.Embed(
                title="❌ Bot Insufficient Permissions",
                description="I cannot delete this role due to role hierarchy.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        if role == interaction.guild.default_role:
            embed = discord.Embed(
                title="❌ Cannot Delete",
                description="The @everyone role cannot be deleted.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            role_name = role.name
            await role.delete(reason=f"Role deleted by {interaction.user}")
            
            embed = discord.Embed(
                title="✅ Role Deleted",
                description=f"Successfully deleted role **{role_name}**.",
                color=discord.Color.green()
            )
            embed.add_field(name="Deleted by", value=interaction.user.mention, inline=False)
            
            await interaction.response.send_message(embed=embed)
            
        except discord.Forbidden:
            embed = discord.Embed(
                title="❌ Missing Permissions",
                description="I don't have permission to delete this role.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
        except discord.HTTPException as e:
            embed = discord.Embed(
                title="❌ Failed to Delete Role",
                description=f"An error occurred: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="roleinfo", description="Get information about a role")
    @app_commands.describe(role="The role to get information about")
    async def roleinfo(self, interaction: discord.Interaction, role: discord.Role):
        """Display role information"""
        embed = discord.Embed(
            title=f"📋 Role Information: {role.name}",
            color=role.color if role.color != discord.Color.default() else discord.Color.blue()
        )
        
        embed.add_field(name="Name", value=role.name, inline=True)
        embed.add_field(name="ID", value=role.id, inline=True)
        embed.add_field(name="Color", value=str(role.color), inline=True)
        
        embed.add_field(name="Created", value=f"<t:{int(role.created_at.timestamp())}:F>", inline=True)
        embed.add_field(name="Position", value=role.position, inline=True)
        embed.add_field(name="Members", value=len(role.members), inline=True)
        
        embed.add_field(name="Mentionable", value="Yes" if role.mentionable else "No", inline=True)
        embed.add_field(name="Hoisted", value="Yes" if role.hoist else "No", inline=True)
        embed.add_field(name="Managed", value="Yes" if role.managed else "No", inline=True)
        
        # Key permissions
        perms = role.permissions
        key_perms = []
        if perms.administrator:
            key_perms.append("Administrator")
        if perms.manage_guild:
            key_perms.append("Manage Server")
        if perms.manage_channels:
            key_perms.append("Manage Channels")
        if perms.manage_messages:
            key_perms.append("Manage Messages")
        if perms.kick_members:
            key_perms.append("Kick Members")
        if perms.ban_members:
            key_perms.append("Ban Members")
        if perms.manage_roles:
            key_perms.append("Manage Roles")
        
        if key_perms:
            embed.add_field(name="Key Permissions", value=", ".join(key_perms), inline=False)
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="rolemembers", description="List members with a specific role")
    @app_commands.describe(role="The role to list members for")
    async def rolemembers(self, interaction: discord.Interaction, role: discord.Role):
        """List members with a specific role"""
        if not role.members:
            embed = discord.Embed(
                title=f"📋 Members with {role.name}",
                description="No members have this role.",
                color=discord.Color.blue()
            )
            await interaction.response.send_message(embed=embed)
            return
        
        # Limit to first 20 members to avoid message length issues
        members = role.members[:20]
        member_list = "\n".join([f"• {member.mention} ({member.name})" for member in members])
        
        embed = discord.Embed(
            title=f"📋 Members with {role.name}",
            description=member_list,
            color=role.color if role.color != discord.Color.default() else discord.Color.blue()
        )
        
        embed.add_field(name="Total Members", value=len(role.members), inline=True)
        
        if len(role.members) > 20:
            embed.set_footer(text=f"Showing first 20 of {len(role.members)} members")
        
        await interaction.response.send_message(embed=embed)

async def setup(bot):
    await bot.add_cog(Roles(bot))
