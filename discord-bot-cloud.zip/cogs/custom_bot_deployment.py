"""
Custom Bot Deployment System
Owner-only command to create personalized bot instances for customers
"""

import discord
from discord.ext import commands
from discord import app_commands
import uuid
import os
from database import DatabaseManager

class CustomBotView(discord.ui.View):
    """View for custom bot deployment button"""
    
    def __init__(self, db_manager):
        super().__init__(timeout=300)
        self.db_manager = db_manager
    
    @discord.ui.button(label="Deploy Custom Bot", style=discord.ButtonStyle.primary, emoji="🤖")
    async def deploy_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Handle deploy button click"""
        modal = CustomBotModal(self.db_manager)
        await interaction.response.send_modal(modal)

class CustomBotModal(discord.ui.Modal):
    """Modal for custom bot deployment"""
    
    def __init__(self, db_manager):
        super().__init__(title="Deploy Custom Bot")
        self.db_manager = db_manager
    
    bot_token = discord.ui.TextInput(
        label="Bot Token",
        placeholder="Enter the customer's Discord bot token...",
        style=discord.TextStyle.short,
        max_length=100,
        required=True
    )
    
    bot_name = discord.ui.TextInput(
        label="Bot Name",
        placeholder="Enter the custom bot name...",
        style=discord.TextStyle.short,
        max_length=50,
        required=True
    )
    
    customer_id = discord.ui.TextInput(
        label="Customer Discord ID",
        placeholder="Enter the customer's Discord user ID...",
        style=discord.TextStyle.short,
        max_length=20,
        required=True
    )
    
    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        
        try:
            # Generate unique deployment ID
            deployment_id = str(uuid.uuid4())[:8].upper()
            
            # Validate inputs
            try:
                customer_discord_id = int(self.customer_id.value)
            except ValueError:
                await interaction.followup.send("❌ Invalid Discord ID format!", ephemeral=True)
                return
            
            # Create custom bot configuration
            custom_bot_config = {
                'deployment_id': deployment_id,
                'customer_id': customer_discord_id,
                'bot_token': self.bot_token.value,
                'bot_name': self.bot_name.value,
                'status': 'ACTIVE'
            }
            
            # Save to database
            self.db_manager.create_custom_bot(
                deployment_id=deployment_id,
                customer_id=customer_discord_id,
                bot_token=self.bot_token.value,
                bot_name=self.bot_name.value
            )
            
            # Create deployment package
            file_content = self.create_deployment_package(custom_bot_config)
            
            # Save to temporary file
            filename = f"custom_bot_{deployment_id}.py"
            with open(filename, "w") as f:
                f.write(file_content)
            
            # Send deployment confirmation
            embed = discord.Embed(
                title="🤖 Custom Bot Deployment Created",
                description=f"Custom bot **{self.bot_name.value}** has been deployed successfully!",
                color=0x00ff00
            )
            
            embed.add_field(
                name="📋 Deployment Details",
                value=f"**Deployment ID:** `{deployment_id}`\n"
                      f"**Bot Name:** {self.bot_name.value}\n"
                      f"**Customer ID:** {customer_discord_id}",
                inline=False
            )
            
            embed.add_field(
                name="📁 Deployment File",
                value="The complete bot file has been generated and is ready for deployment.",
                inline=False
            )
            
            # Send file
            file = discord.File(filename, filename=f"{self.bot_name.value.lower()}_bot.py")
            await interaction.followup.send(embed=embed, file=file, ephemeral=True)
            
            # Clean up
            os.remove(filename)
            
            # Send DM to customer
            try:
                user = interaction.client.get_user(customer_discord_id)
                if user:
                    dm_embed = discord.Embed(
                        title="🎉 Your Custom Bot is Ready!",
                        description=f"Your personalized Discord bot **{self.bot_name.value}** has been deployed!",
                        color=0x17a2b8
                    )
                    
                    dm_embed.add_field(
                        name="🚀 Next Steps",
                        value="1. Upload the bot file to a new Replit project\n"
                              "2. Set your DISCORD_BOT_TOKEN environment variable\n"
                              "3. Click 'Run' to start your bot\n"
                              "4. Add to UptimeRobot for 24/7 hosting",
                        inline=False
                    )
                    
                    dm_embed.add_field(
                        name="💬 Support",
                        value="Join our Discord server for support: https://discord.gg/FQvU3DAgCk",
                        inline=False
                    )
                    
                    with open(filename, "w") as f:
                        f.write(file_content)
                    dm_file = discord.File(filename, filename=f"{self.bot_name.value.lower()}_bot.py")
                    await user.send(embed=dm_embed, file=dm_file)
                    os.remove(filename)
                    
            except Exception as e:
                print(f"Failed to send DM to customer: {e}")
            
        except Exception as e:
            print(f"Custom bot deployment error: {e}")
            error_embed = discord.Embed(
                title="❌ Deployment Failed",
                description=f"Failed to deploy custom bot: {str(e)}",
                color=0xff0000
            )
            await interaction.followup.send(embed=error_embed, ephemeral=True)
    
    def create_deployment_package(self, config):
        """Create a complete bot deployment package"""
        bot_name = config['bot_name']
        deployment_id = config['deployment_id']
        customer_id = config['customer_id']
        
        return f'''#!/usr/bin/env python3
"""
{bot_name} - Custom Discord Bot
Deployment ID: {deployment_id}
Powered by Guardian Bot Technology
"""

import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import json
import os
import sqlite3
from datetime import datetime
import threading
from flask import Flask

# Bot Configuration
BOT_NAME = "{bot_name}"
DEPLOYMENT_ID = "{deployment_id}"
CUSTOMER_ID = {customer_id}

# Discord Bot Setup
class CustomBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = True
        
        super().__init__(
            command_prefix='.',
            intents=intents,
            help_command=None,
            case_insensitive=True,
            activity=discord.Activity(
                type=discord.ActivityType.watching,
                name="for attacks"
            )
        )

bot = CustomBot()

# Flask Web Server for 24/7 hosting
app = Flask(__name__)

@app.route('/')
def home():
    return f"<h1>{{BOT_NAME}} - Status: Online</h1><p>Deployment ID: {{DEPLOYMENT_ID}}</p>"

@app.route('/health')
def health():
    return {{"status": "healthy", "deployment_id": DEPLOYMENT_ID}}

# Database Setup
class Database:
    def __init__(self):
        self.db_path = "bot_data.db"
        self.init_database()
    
    def init_database(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""CREATE TABLE IF NOT EXISTS guilds (
            guild_id INTEGER PRIMARY KEY,
            guild_name TEXT,
            prefix TEXT DEFAULT '.',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
        
        cursor.execute("""CREATE TABLE IF NOT EXISTS warnings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            guild_id INTEGER,
            user_id INTEGER,
            moderator_id INTEGER,
            reason TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
        
        conn.commit()
        conn.close()

# Initialize database
db = Database()

@bot.event
async def on_ready():
    print(f"🤖 {{BOT_NAME}} is now online!")
    print(f"📊 Connected to {{len(bot.guilds)}} guilds")
    print(f"👥 Serving {{len(set(bot.get_all_members()))}} users")
    print(f"🆔 Deployment ID: {{DEPLOYMENT_ID}}")
    
    # Sync commands
    try:
        synced = await bot.tree.sync()
        print(f"✓ Synced {{len(synced)}} slash commands")
    except Exception as e:
        print(f"Failed to sync commands: {{e}}")

@bot.tree.command(name="info", description=f"Information about {{BOT_NAME}}")
async def info_command(interaction: discord.Interaction):
    embed = discord.Embed(
        title=f"🤖 {{BOT_NAME}} Information",
        description=f"Custom Discord bot powered by Guardian Bot technology",
        color=0x17a2b8,
        timestamp=datetime.utcnow()
    )
    
    embed.add_field(
        name="📊 Statistics",
        value=f"**Servers:** {{len(bot.guilds)}}\\n"
              f"**Users:** {{len(set(bot.get_all_members()))}}\\n"
              f"**Commands:** 25+",
        inline=True
    )
    
    embed.add_field(
        name="⚡ Features",
        value="✓ Moderation Tools\\n"
              "✓ Auto-Moderation\\n"
              "✓ Role Management\\n"
              "✓ Utility Commands",
        inline=True
    )
    
    embed.add_field(
        name="🔧 Deployment",
        value=f"**ID:** `{{DEPLOYMENT_ID}}`\\n"
              f"**Version:** 1.0.0\\n"
              f"**Uptime:** 24/7",
        inline=False
    )
    
    await interaction.response.send_message(embed=embed)

# Essential moderation commands
@bot.tree.command(name="kick", description="Kick a member from the server")
@app_commands.describe(member="Member to kick", reason="Reason for kick")
async def kick_command(interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
    if not interaction.user.guild_permissions.kick_members:
        await interaction.response.send_message("❌ You don't have permission to kick members!", ephemeral=True)
        return
    
    try:
        await member.kick(reason=reason)
        
        embed = discord.Embed(
            title="👢 Member Kicked",
            description=f"**{{member.mention}}** has been kicked from the server.",
            color=0xff9900,
            timestamp=datetime.utcnow()
        )
        embed.add_field(name="Reason", value=reason, inline=False)
        embed.add_field(name="Moderator", value=interaction.user.mention, inline=True)
        
        await interaction.response.send_message(embed=embed)
        
    except Exception as e:
        await interaction.response.send_message(f"❌ Failed to kick member: {{str(e)}}", ephemeral=True)

@bot.tree.command(name="ban", description="Ban a member from the server")
@app_commands.describe(member="Member to ban", reason="Reason for ban")
async def ban_command(interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
    if not interaction.user.guild_permissions.ban_members:
        await interaction.response.send_message("❌ You don't have permission to ban members!", ephemeral=True)
        return
    
    try:
        await member.ban(reason=reason)
        
        embed = discord.Embed(
            title="🔨 Member Banned",
            description=f"**{{member.mention}}** has been banned from the server.",
            color=0xff0000,
            timestamp=datetime.utcnow()
        )
        embed.add_field(name="Reason", value=reason, inline=False)
        embed.add_field(name="Moderator", value=interaction.user.mention, inline=True)
        
        await interaction.response.send_message(embed=embed)
        
    except Exception as e:
        await interaction.response.send_message(f"❌ Failed to ban member: {{str(e)}}", ephemeral=True)

@bot.tree.command(name="warn", description="Warn a member")
@app_commands.describe(member="Member to warn", reason="Reason for warning")
async def warn_command(interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
    if not interaction.user.guild_permissions.moderate_members:
        await interaction.response.send_message("❌ You don't have permission to warn members!", ephemeral=True)
        return
    
    try:
        # Add warning to database
        conn = sqlite3.connect(db.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""INSERT INTO warnings (guild_id, user_id, moderator_id, reason)
                         VALUES (?, ?, ?, ?)""", 
                      (interaction.guild.id, member.id, interaction.user.id, reason))
        
        # Get warning count
        cursor.execute("""SELECT COUNT(*) FROM warnings 
                         WHERE guild_id = ? AND user_id = ?""", 
                      (interaction.guild.id, member.id))
        
        warning_count = cursor.fetchone()[0]
        conn.commit()
        conn.close()
        
        embed = discord.Embed(
            title="⚠️ Member Warned",
            description=f"**{{member.mention}}** has been warned.",
            color=0xffaa00,
            timestamp=datetime.utcnow()
        )
        embed.add_field(name="Reason", value=reason, inline=False)
        embed.add_field(name="Warning Count", value=f"{{warning_count}}", inline=True)
        embed.add_field(name="Moderator", value=interaction.user.mention, inline=True)
        
        await interaction.response.send_message(embed=embed)
        
    except Exception as e:
        await interaction.response.send_message(f"❌ Failed to warn member: {{str(e)}}", ephemeral=True)

@bot.tree.command(name="clear", description="Clear messages from the channel")
@app_commands.describe(amount="Number of messages to delete (1-100)", member="Optional: Only delete messages from this member")
async def clear_command(interaction: discord.Interaction, amount: int, member: discord.Member = None):
    if not interaction.user.guild_permissions.manage_messages:
        await interaction.response.send_message("❌ You don't have permission to manage messages!", ephemeral=True)
        return
    
    if amount < 1 or amount > 100:
        await interaction.response.send_message("❌ Amount must be between 1 and 100!", ephemeral=True)
        return
    
    try:
        deleted = 0
        if member:
            # Delete messages from specific member
            async for message in interaction.channel.history(limit=amount * 2):
                if message.author == member:
                    await message.delete()
                    deleted += 1
                    if deleted >= amount:
                        break
        else:
            # Delete all messages
            deleted_messages = await interaction.channel.purge(limit=amount)
            deleted = len(deleted_messages)
        
        embed = discord.Embed(
            title="🧹 Messages Cleared",
            description=f"Successfully deleted **{{deleted}}** messages.",
            color=0x00ff00,
            timestamp=datetime.utcnow()
        )
        if member:
            embed.add_field(name="Target", value=member.mention, inline=True)
        embed.add_field(name="Moderator", value=interaction.user.mention, inline=True)
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
        
    except Exception as e:
        await interaction.response.send_message(f"❌ Failed to clear messages: {{str(e)}}", ephemeral=True)

# Utility commands
@bot.tree.command(name="ping", description="Check bot latency")
async def ping_command(interaction: discord.Interaction):
    latency = round(bot.latency * 1000)
    embed = discord.Embed(
        title="🏓 Pong!",
        description=f"Bot latency: **{{latency}}ms**",
        color=0x00ff00
    )
    await interaction.response.send_message(embed=embed)

@bot.tree.command(name="serverinfo", description="Get server information")
async def serverinfo_command(interaction: discord.Interaction):
    guild = interaction.guild
    
    embed = discord.Embed(
        title=f"📊 {{guild.name}} Information",
        color=0x17a2b8,
        timestamp=datetime.utcnow()
    )
    
    if guild.icon:
        embed.set_thumbnail(url=guild.icon.url)
    
    embed.add_field(name="👑 Owner", value=guild.owner.mention if guild.owner else "Unknown", inline=True)
    embed.add_field(name="👥 Members", value=guild.member_count, inline=True)
    embed.add_field(name="📅 Created", value=guild.created_at.strftime("%B %d, %Y"), inline=True)
    embed.add_field(name="💬 Text Channels", value=len(guild.text_channels), inline=True)
    embed.add_field(name="🔊 Voice Channels", value=len(guild.voice_channels), inline=True)
    embed.add_field(name="📁 Categories", value=len(guild.categories), inline=True)
    embed.add_field(name="🎭 Roles", value=len(guild.roles), inline=True)
    embed.add_field(name="😀 Emojis", value=len(guild.emojis), inline=True)
    embed.add_field(name="⚡ Boost Level", value=guild.premium_tier, inline=True)
    
    await interaction.response.send_message(embed=embed)

def start_web_server():
    """Start Flask web server for 24/7 hosting"""
    app.run(host='0.0.0.0', port=5000, debug=False)

if __name__ == "__main__":
    # Start web server in background thread for 24/7 hosting
    web_thread = threading.Thread(target=start_web_server, daemon=True)
    web_thread.start()
    
    # Run Discord bot
    bot.run(os.getenv('DISCORD_BOT_TOKEN'))
'''


class CustomBotDeployment(commands.Cog):
    """Custom bot deployment system for Guardian Bot customers"""
    
    def __init__(self, bot):
        self.bot = bot
        self.db_manager = DatabaseManager()
    
    @app_commands.command(name="custombotadd", description="Deploy a custom bot for a customer (Owner Only)")
    async def custom_bot_add(self, interaction: discord.Interaction):
        """Owner-only command to deploy custom bots"""
        
        # Send immediate response
        await interaction.response.defer(ephemeral=True)
        
        # Check if user is bot owner
        if interaction.user.id != 344210326251896834:
            await interaction.followup.send("❌ This command is restricted to the bot owner only!", ephemeral=True)
            return
        
        # Show custom bot deployment interface
        embed = discord.Embed(
            title="🤖 Custom Bot Deployment",
            description="Click the button below to deploy a custom bot for a customer.",
            color=0x17a2b8
        )
        
        embed.add_field(
            name="📋 Instructions",
            value="You will need:\n"
                  "• Customer's Discord bot token\n"
                  "• Desired bot name\n"
                  "• Customer's Discord user ID",
            inline=False
        )
        
        view = CustomBotView(self.db_manager)
        await interaction.followup.send(embed=embed, view=view, ephemeral=True)

async def setup(bot):
    await bot.add_cog(CustomBotDeployment(bot))