"""
Selfbot-style features integrated into the main bot
"""

import discord
from discord.ext import commands, tasks
from discord import app_commands
import os
import json
import asyncio
import random
import datetime
import requests
import aiohttp
import sys
from colorama import Fore, init
from pystyle import Center, Colorate, Colors
from utils.security import SecurityManager

# Initialize colorama
init()

class SelfbotFeatures(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.status_rotator_running = False
        self.status_list = self.load_statuses()
        self.http_session = None
        self.config = self.load_config()
        
    def load_config(self):
        """Load configuration from config.json"""
        try:
            with open("config.json", "r") as file:
                return json.load(file)
        except FileNotFoundError:
            return {
                "BTC": "bc1qa29gd8cec3n8cndl8ge9nf3p6wks9ddqqcww6s",
                "PPL": "lanagotcake@gmail.com",
                "SERVER_LINK": "https://discord.gg/radiantrp",
                "Token": ""
            }
    
    def load_statuses(self):
        """Load status list from file or use defaults"""
        if os.path.exists("status_list.txt"):
            with open("status_list.txt", "r") as file:
                return [line.strip() for line in file.readlines() if line.strip()]
        else:
            return [
                "Custom Status 1",
                "Custom Status 2", 
                "Custom Status 3",
                "Custom Status 4"
            ]

    @tasks.loop(seconds=10)
    async def status_rotator(self):
        """Rotate bot status every 10 seconds"""
        if self.status_rotator_running:
            new_status = random.choice(self.status_list)
            await self.bot.change_presence(activity=discord.Game(name=new_status))

    @app_commands.command(name="startstatusrotator", description="Start rotating bot status")
    async def start_status_rotator(self, interaction: discord.Interaction):
        """Start the status rotator"""
        if not self.status_rotator_running:
            self.status_rotator_running = True
            self.status_rotator.start()
            embed = discord.Embed(
                title="✅ Status Rotator",
                description="Status rotator started successfully",
                color=discord.Color.green()
            )
        else:
            embed = discord.Embed(
                title="⚠️ Status Rotator",
                description="Status rotator is already running",
                color=discord.Color.orange()
            )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="stopstatusrotator", description="Stop rotating bot status")
    async def stop_status_rotator(self, interaction: discord.Interaction):
        """Stop the status rotator"""
        if self.status_rotator_running:
            self.status_rotator_running = False
            self.status_rotator.stop()
            await self.bot.change_presence(activity=None)
            embed = discord.Embed(
                title="🛑 Status Rotator",
                description="Status rotator stopped and status cleared",
                color=discord.Color.red()
            )
        else:
            embed = discord.Embed(
                title="⚠️ Status Rotator",
                description="Status rotator is not running",
                color=discord.Color.orange()
            )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="vouch", description="Show vouching information")
    async def vouch(self, interaction: discord.Interaction):
        """Display vouching format and server link"""
        embed = discord.Embed(
            title="💬 Vouch Information",
            color=discord.Color.blue()
        )
        embed.add_field(
            name="Server Link",
            value=f"{self.config.get('SERVER_LINK', 'discord.gg/')}",
            inline=False
        )
        embed.add_field(
            name="Vouch Format",
            value="`+rep @user x... (product) for (price)`",
            inline=False
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="paypal", description="Show PayPal payment information")
    async def paypal(self, interaction: discord.Interaction):
        """Display PayPal payment info"""
        embed = discord.Embed(
            title="💳 PayPal Payment",
            description=f"**Email:** {self.config.get('PPL', 'lanagotcake@gmail.com')}\n⚠️ Friends & Family, 0 notes, FROM BALANCE, Send in Discord",
            color=discord.Color.blue()
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="btc", description="Show Bitcoin address")
    async def btc(self, interaction: discord.Interaction):
        """Display BTC address"""
        embed = discord.Embed(
            title="₿ Bitcoin Payment",
            description=f"{self.config.get('BTC', 'bc1qa29gd8cec3n8cndl8ge9nf3p6wks9ddqqcww6s')}\n⚠️ Send in Discord **€**",
            color=discord.Color.gold()
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="btcproof", description="Generate BTC transaction proof")
    @app_commands.describe(transaction_id="The Bitcoin transaction ID")
    async def btc_proof(self, interaction: discord.Interaction, transaction_id: str):
        """Generate BTC transaction proof link"""
        blockstream_url = f"https://blockstream.info/tx/{transaction_id}"
        embed = discord.Embed(
            title="🔗 BTC Transaction Proof",
            description=f"[View Transaction]({blockstream_url})",
            color=discord.Color.gold()
        )
        embed.add_field(name="Transaction ID", value=transaction_id, inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="checktx", description="Check Bitcoin transaction status")
    @app_commands.describe(transaction_id="The Bitcoin transaction ID to check")
    async def check_transaction(self, interaction: discord.Interaction, transaction_id: str):
        """Check if a Bitcoin transaction has been received"""
        await interaction.response.defer(ephemeral=True)
        
        blockstream_url = f"https://blockstream.info/api/tx/{transaction_id}"
        
        try:
            response = requests.get(blockstream_url, timeout=10)
            data = response.json()

            if response.status_code == 200:
                confirmations = data.get("status", {}).get("confirmed", False)
                embed = discord.Embed(
                    title="💰 Transaction Status",
                    color=discord.Color.green() if confirmations else discord.Color.orange()
                )
                
                if confirmations:
                    embed.description = f"✅ BTC Received - Transaction Confirmed"
                else:
                    embed.description = f"⏳ Pending - Transaction Unconfirmed"
                    
                embed.add_field(name="Transaction ID", value=transaction_id, inline=False)
            else:
                embed = discord.Embed(
                    title="❌ Error",
                    description="Invalid transaction ID or API error",
                    color=discord.Color.red()
                )
        except Exception as e:
            embed = discord.Embed(
                title="❌ Error",
                description=f"Failed to check transaction: {str(e)}",
                color=discord.Color.red()
            )
        
        await interaction.followup.send(embed=embed)

    @app_commands.command(name="ipinfo", description="Get IP address information")
    @app_commands.describe(ip="IP address to lookup")
    async def ip_info(self, interaction: discord.Interaction, ip: str):
        """Get information about an IP address"""
        await interaction.response.defer(ephemeral=True)
        
        try:
            api_url = f"http://ip-api.com/json/{ip}"
            response = requests.get(api_url, timeout=10)
            data = response.json()
            
            if data.get('status') == 'success':
                embed = discord.Embed(
                    title="🌐 IP Information",
                    description=f"Results for IP: `{ip}`",
                    color=discord.Color.blue()
                )
                embed.add_field(name="Country", value=data.get('country', 'N/A'), inline=True)
                embed.add_field(name="City", value=data.get('city', 'N/A'), inline=True)
                embed.add_field(name="ISP", value=data.get('isp', 'N/A'), inline=True)
                embed.add_field(name="Timezone", value=data.get('timezone', 'N/A'), inline=True)
                embed.set_footer(text=f"Requested by {interaction.user.display_name}")
            else:
                embed = discord.Embed(
                    title="❌ Error",
                    description="Invalid IP address or API error",
                    color=discord.Color.red()
                )
        except Exception as e:
            embed = discord.Embed(
                title="❌ Error",
                description=f"Failed to lookup IP: {str(e)}",
                color=discord.Color.red()
            )
            
        await interaction.followup.send(embed=embed)

    @app_commands.command(name="massreact", description="Add reactions to recent messages")
    @app_commands.describe(emoji="Emoji to react with", count="Number of messages to react to (max 10)")
    async def mass_react(self, interaction: discord.Interaction, emoji: str, count: int = 10):
        """Add reactions to recent messages"""
        if count > 10:
            count = 10
        
        await interaction.response.defer(ephemeral=True)
        
        try:
            reacted = 0
            async for message in interaction.channel.history(limit=count):
                try:
                    await message.add_reaction(emoji)
                    reacted += 1
                    await asyncio.sleep(0.5)  # Rate limit protection
                except:
                    continue
            
            embed = discord.Embed(
                title="✅ Mass React",
                description=f"Added {emoji} reaction to {reacted} messages",
                color=discord.Color.green()
            )
        except Exception as e:
            embed = discord.Embed(
                title="❌ Error",
                description=f"Failed to add reactions: {str(e)}",
                color=discord.Color.red()
            )
            
        await interaction.followup.send(embed=embed)

    @app_commands.command(name="servericon", description="Get server icon URL")
    async def server_icon(self, interaction: discord.Interaction):
        """Get server icon URL"""
        if interaction.guild.icon:
            embed = discord.Embed(
                title="🖼️ Server Icon",
                color=discord.Color.blue()
            )
            embed.set_image(url=interaction.guild.icon.url)
            embed.add_field(name="Icon URL", value=f"[Click Here]({interaction.guild.icon.url})", inline=False)
        else:
            embed = discord.Embed(
                title="❌ No Icon",
                description="This server has no icon set",
                color=discord.Color.red()
            )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="serverbanner", description="Get server banner URL")
    async def server_banner(self, interaction: discord.Interaction):
        """Get server banner URL"""
        if interaction.guild.banner:
            embed = discord.Embed(
                title="🎨 Server Banner",
                color=discord.Color.blue()
            )
            embed.set_image(url=interaction.guild.banner.url)
            embed.add_field(name="Banner URL", value=f"[Click Here]({interaction.guild.banner.url})", inline=False)
        else:
            embed = discord.Embed(
                title="❌ No Banner",
                description="This server has no banner set",
                color=discord.Color.red()
            )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="setstatus", description="Set bot status")
    @app_commands.describe(status="Status text to set")
    async def set_status(self, interaction: discord.Interaction, status: str):
        """Set bot status"""
        await self.bot.change_presence(activity=discord.Game(name=status))
        embed = discord.Embed(
            title="✅ Status Updated",
            description=f"Status set to: {status}",
            color=discord.Color.green()
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="clearstatus", description="Clear bot status")
    async def clear_status(self, interaction: discord.Interaction):
        """Clear bot status"""
        await self.bot.change_presence(activity=None)
        embed = discord.Embed(
            title="✅ Status Cleared",
            description="Bot status has been cleared",
            color=discord.Color.green()
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="createcustomrole", description="Create a new role")
    @app_commands.describe(role_name="Name of the role", color="Hex color code (optional)")
    @app_commands.default_permissions(manage_roles=True)
    async def create_role_slash(self, interaction: discord.Interaction, role_name: str, color: str = None):
        """Create a new role"""
        await interaction.response.defer(ephemeral=True)
        
        try:
            if color:
                color_int = int(color.replace('#', ''), 16)
                new_role = await interaction.guild.create_role(name=role_name, color=discord.Color(color_int))
            else:
                new_role = await interaction.guild.create_role(name=role_name)
            
            embed = discord.Embed(
                title="✅ Role Created",
                description=f"Role '{role_name}' created successfully",
                color=new_role.color
            )
        except Exception as e:
            embed = discord.Embed(
                title="❌ Error",
                description=f"Failed to create role: {str(e)}",
                color=discord.Color.red()
            )
        
        await interaction.followup.send(embed=embed)

    @app_commands.command(name="joinvc", description="Join a voice channel")
    @app_commands.describe(channel_id="Voice channel ID to join")
    async def join_vc_slash(self, interaction: discord.Interaction, channel_id: str):
        """Join a voice channel by ID with improved stability"""
        await interaction.response.send_message(f"🔄 Attempting to join voice channel...", ephemeral=True)
        
        try:
            channel = self.bot.get_channel(int(channel_id))
            if not channel or not isinstance(channel, discord.VoiceChannel):
                await interaction.edit_original_response(content="❌ Invalid voice channel ID")
                return
            
            # Use VoiceManager for stable connection
            from utils.voice_manager import VoiceManager
            voice_client = await VoiceManager.connect_with_retry(channel, max_retries=2)
            await interaction.edit_original_response(content=f"✅ Successfully joined {channel.name}")
                
        except discord.ClientException as e:
            # Try emergency fallback for persistent WebSocket errors
            from utils.voice_manager import VoiceManager
            emergency_client = await VoiceManager.emergency_connect(channel)
            
            if emergency_client:
                await interaction.edit_original_response(content=f"✅ Emergency connection successful to {channel.name}")
            else:
                # Provide detailed feedback about the issue
                embed = discord.Embed(
                    title="🔧 Voice Connection Issue",
                    description="Unable to establish stable voice connection due to Discord WebSocket errors (4006).\n\n"
                               "**This is a known Discord infrastructure issue that affects hosted bots.**\n\n"
                               "**Alternatives:**\n"
                               "• Try again in a few minutes\n"
                               "• Use voice commands when Discord's voice servers are more stable\n"
                               "• Consider using the bot during off-peak hours",
                    color=discord.Color.orange()
                )
                embed.add_field(
                    name="🎵 Voice Features",
                    value="All other bot features work normally.\nVoice commands will retry automatically when connection improves.",
                    inline=False
                )
                await interaction.edit_original_response(content="", embed=embed)
                
        except Exception as e:
            await interaction.edit_original_response(content=f"❌ Failed to join {channel.name}: {str(e)}")

    @app_commands.command(name="leavevc", description="Leave voice channel")
    async def leave_vc_slash(self, interaction: discord.Interaction):
        """Leave the voice channel"""
        await interaction.response.defer(ephemeral=True)
        
        try:
            if interaction.guild.voice_client:
                await interaction.guild.voice_client.disconnect()
                embed = discord.Embed(
                    title="✅ Voice Channel",
                    description="Left voice channel",
                    color=discord.Color.green()
                )
            else:
                embed = discord.Embed(
                    title="⚠️ Warning",
                    description="Not in a voice channel",
                    color=discord.Color.orange()
                )
        except Exception as e:
            embed = discord.Embed(
                title="❌ Error",
                description=f"Failed to leave voice channel: {str(e)}",
                color=discord.Color.red()
            )
        
        await interaction.followup.send(embed=embed)

    @app_commands.command(name="deletecategory", description="Delete all channels in a category")
    @app_commands.describe(category_id="Category ID to delete channels from")
    @app_commands.default_permissions(manage_channels=True)
    async def delete_category_slash(self, interaction: discord.Interaction, category_id: str):
        """Delete all channels in a specific category"""
        
        # Security validation - check server permissions
        if not await SecurityManager.validate_and_respond(interaction, "mass_delete"):
            return
            
        await interaction.response.defer(ephemeral=True)
        
        try:
            category = discord.utils.get(interaction.guild.categories, id=int(category_id))
            if not category:
                embed = discord.Embed(
                    title="❌ Error",
                    description="Category not found",
                    color=discord.Color.red()
                )
                await interaction.followup.send(embed=embed)
                return
            
            deleted_count = 0
            for channel in category.channels:
                try:
                    await channel.delete()
                    deleted_count += 1
                except:
                    continue
            
            embed = discord.Embed(
                title="✅ Channels Deleted",
                description=f"Deleted {deleted_count} channels in category {category.name}",
                color=discord.Color.green()
            )
        except Exception as e:
            embed = discord.Embed(
                title="❌ Error",
                description=f"Failed to delete channels: {str(e)}",
                color=discord.Color.red()
            )
        
        await interaction.followup.send(embed=embed)

    @app_commands.command(name="website", description="Show website link")
    async def website(self, interaction: discord.Interaction):
        """Show website link"""
        embed = discord.Embed(
            title="🌐 Website",
            description="https://nfaa.mysellauth.com/",
            color=discord.Color.blue()
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    # Traditional prefix commands for compatibility
    @commands.command(name="vouch")
    async def vouch_prefix(self, ctx):
        await ctx.send(
            f"`-` **SERVER LINK** : {self.config.get('SERVER_LINK', 'discord.gg/')}\n`-` **VOUCH FORMAT** : `+rep @user x... (product) for (price)`"
        )
        await ctx.message.delete()

    @commands.command(name="ppl")
    async def ppl_prefix(self, ctx):
        await ctx.send(
            f"**Email:** {self.config.get('PPL', 'lanagotcake@gmail.com')}\n⚠️ Friends & Family, 0 notes, FROM BALANCE, Send in Discord"
        )
        await ctx.message.delete()

    @commands.command(name="btc")
    async def btc_prefix(self, ctx):
        await ctx.send(
            f"{self.config.get('BTC', 'bc1qa29gd8cec3n8cndl8ge9nf3p6wks9ddqqcww6s')}\n⚠️ Send in Discord **€**"
        )
        await ctx.message.delete()

    @commands.command(name="web")
    async def web_prefix(self, ctx):
        await ctx.send("https://nfaa.mysellauth.com/")
        await ctx.message.delete()

    @commands.command(name="btcproof")
    async def btcproof_prefix(self, ctx, transaction_id: str):
        blockstream_url = f"https://blockstream.info/tx/{transaction_id}"
        await ctx.send(f"`-` **BTC TRANSACTION PROOF**: {blockstream_url}")
        await ctx.message.delete()

    @commands.command(name="check")
    async def check_prefix(self, ctx, transaction_id: str):
        blockstream_url = f"https://blockstream.info/api/tx/{transaction_id}"
        try:
            response = requests.get(blockstream_url)
            data = response.json()

            if response.status_code == 200:
                confirmed = data.get("status", {}).get("confirmed", False)
                if confirmed:
                    await ctx.send(f"`-` **BTC RECEIVED**: Transaction ID `{transaction_id}` is confirmed.")
                else:
                    await ctx.send(f"`-` **BTC NOT RECEIVED**: Transaction ID `{transaction_id}` is unconfirmed.")
            else:
                await ctx.send(f"`-` **ERROR**: Invalid transaction ID or API error.")
        except Exception as e:
            await ctx.send(f"`-` **ERROR**: {str(e)}")
        await ctx.message.delete()

    @commands.command(name="ip")
    async def ip_prefix(self, ctx, ip: str):
        try:
            api_url = f"http://ip-api.com/json/{ip}"
            response = requests.get(api_url)
            data = response.json()
            
            if data.get('status') == 'success':
                country = data.get('country', 'N/A')
                city = data.get('city', 'N/A')
                isp = data.get('isp', 'N/A')
                timezone = data.get('timezone', 'N/A')
                
                message = (
                    f"# __𝓢𝓮𝓵𝓯𝓫𝓸𝓽\n`-` **RESULTS FOR IP** : __`{ip}`__ \n`-` **COUNTRY** : `{country}`\n`-` **CITY** : `{city}`\n`-` **ISP** : `{isp}`\n`-` **TIMEZONE** : `{timezone}`\n\n`-` **ASKED BY** : `{self.bot.user.name}`"
                )
                await ctx.send(message)
            else:
                await ctx.send("# __𝓢𝓮𝓵𝓯𝓫𝓸𝓽\n`-` **INVALID IP OR API ERROR !**")
        except Exception as e:
            await ctx.send(f"# __𝓢𝓮𝓵𝓯𝓫𝓸𝓽\n`-` **AN ERROR OCCURRED**: `{str(e)}`")
        await ctx.message.delete()

    @commands.command(name="clean")
    async def clean_prefix(self, ctx, amount: int):
        if amount <= 0:
            await ctx.send("`-` **AMOUNT MUST BE GREATER THAN 0**", delete_after=5)
            await ctx.message.delete()
            return

        await ctx.message.delete()

        def is_user(m):
            return m.author == ctx.author

        deleted = await ctx.channel.purge(limit=amount, check=is_user)
        await ctx.send(f"`-` **CLEANED {len(deleted)} MESSAGES**", delete_after=5)

    @commands.command(name="spam")
    async def spam_prefix(self, ctx, amount: int, *, message: str):
        if amount <= 0:
            await ctx.send("`-` **AMOUNT MUST BE GREATER THAN 0**")
            await ctx.message.delete()
            return
        for _ in range(amount):
            await ctx.send(message)
            await asyncio.sleep(1)
        await ctx.message.delete()

    @commands.command(name="massreact")
    async def massreact_prefix(self, ctx, emoji: str):
        async for message in ctx.channel.history(limit=10):
            await message.add_reaction(emoji)
        await ctx.message.delete()

    @commands.command(name="banner")
    async def banner_prefix(self, ctx):
        if ctx.guild.banner:
            await ctx.send(f"`-` **BANNER URL**: {ctx.guild.banner.url}")
        else:
            await ctx.send("`-` **NO BANNER SET**")
        await ctx.message.delete()

    @commands.command(name="icon")
    async def icon_prefix(self, ctx):
        if ctx.guild.icon:
            await ctx.send(f"`-` **ICON URL**: {ctx.guild.icon.url}")
        else:
            await ctx.send("`-` **NO ICON SET**")
        await ctx.message.delete()

    @commands.command(name="status")
    async def status_prefix(self, ctx, *, text: str):
        await self.bot.change_presence(activity=discord.Game(name=text))
        await ctx.send(f"Status set to: {text}")
        await ctx.message.delete()

    @commands.command(name="clearstatus")
    async def clearstatus_prefix(self, ctx):
        await self.bot.change_presence(activity=None)
        await ctx.send("Status cleared")
        await ctx.message.delete()

    @commands.command(name="startstatusrotator")
    async def startstatusrotator_prefix(self, ctx):
        if not self.status_rotator_running:
            self.status_rotator_running = True
            self.status_rotator.start()
            await ctx.send("`-` **STATUS ROTATOR STARTED**")
        else:
            await ctx.send("`-` **STATUS ROTATOR IS ALREADY RUNNING**")
        await ctx.message.delete()

    @commands.command(name="stopstatusrotator")
    async def stopstatusrotator_prefix(self, ctx):
        if self.status_rotator_running:
            self.status_rotator_running = False
            self.status_rotator.stop()
            await self.bot.change_presence(activity=None)
            await ctx.send("`-` **STATUS ROTATOR STOPPED AND STATUS CLEARED**")
        else:
            await ctx.send("`-` **STATUS ROTATOR IS NOT RUNNING**")
        await ctx.message.delete()

    @commands.command(name="bal")
    async def bal_prefix(self, ctx):
        """Show BTC balance"""
        # This is a placeholder - in real implementation you'd connect to a wallet API
        btc_balance = 0.5  # Example balance
        await ctx.send(f"`-` **BTC BALANCE**: `{btc_balance} BTC`")
        await ctx.message.delete()

    @app_commands.command(name="btcbalance", description="Show BTC balance")
    async def btc_balance_slash(self, interaction: discord.Interaction):
        """Show BTC balance"""
        btc_balance = 0.5  # Example balance - replace with real wallet API integration
        embed = discord.Embed(
            title="₿ BTC Balance",
            description=f"Current balance: **{btc_balance} BTC**",
            color=discord.Color.gold()
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @commands.command(name="change_hypesquad")
    async def change_hypesquad_prefix(self, ctx):
        """Original interactive HypeSquad change"""
        choices = {
            1: "BRAVERY",
            2: "BRILLIANCE", 
            3: "BALANCED"
        }
        
        await ctx.send("`[1] Bravery`\n`[2] Brilliance`\n`[3] Balance`")
        await ctx.send("`-` **ENTER YOUR CHOICE**: `1,2,3`")
        
        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel
        
        try:
            msg = await self.bot.wait_for('message', check=check, timeout=60)
            choice = int(msg.content)
        except asyncio.TimeoutError:
            await ctx.send("`-` **COMMAND TIMED OUT**")
            await ctx.message.delete()
            return
        except ValueError:
            await ctx.send("`-` **INVALID CHOICE PLEASE ENTER** : `1 , 2 , 3`")
            await ctx.message.delete()
            return
        
        # Get token from config
        try:
            with open("config.json", "r") as file:
                config = json.load(file)
                token = config.get("Token", "")
        except:
            token = ""
        
        if not token:
            await ctx.send("`-` **TOKEN NOT FOUND IN CONFIG.JSON**")
            await ctx.message.delete()
            return
        
        headers = {'Authorization': token}
        payload = {'house_id': choice}
        
        try:
            await ctx.send(f"`-` **CHANGING HYPESQUAD TO {choices.get(choice, 'Unknown')}**")
            
            if not self.http_session:
                import aiohttp
                self.http_session = aiohttp.ClientSession()
            
            async with self.http_session.post(
                "https://discord.com/api/v8/hypesquad/online", 
                json=payload, 
                headers=headers
            ) as response:
                if response.status == 204:
                    await ctx.send("`-` **HYPESQUAD CHANGED SUCCESSFULLY**")
                elif response.status == 401:
                    await ctx.send("`-` **TOKEN INVALID OR EXPIRED**")
                elif response.status == 429:
                    await ctx.send("`-` **PLEASE WAIT FOR 2 MINUTES**")
                else:
                    await ctx.send("`-` **WE CAUGHT WITH AN ERROR**")
        except Exception as e:
            await ctx.send(f"`-` **AN ERROR OCCURRED**: `{str(e)}`")
        await ctx.message.delete()

    @commands.command(name="help")
    async def help_prefix(self, ctx):
        """Custom help command"""
        help_message = """
### 𝓢𝓮𝓵𝓯𝓫𝓸𝓽 𝓫𝔂 UncleAlvin

- `!vouch` Send your message for the vouchs
- `!ppl` Send your PayPal email
- `!btc` Send your BTC address
- `!btcproof <transaction_id>` Get a link to verify a Bitcoin transaction
- `!check <transaction_id>` Check if BTC has been received
- `!bal` Show your BTC balance
- `!ip <ip>` Lookup IP information
- `!clear <amount>` Delete X number of messages
- `!spam <amount> <message>` Allows you to spam X number of messages
- `!massreact <emoji>` Allows you to react to many messages 
- `!banner` Displays the banner of the server in which the command is made
- `!icon` Shows the icon of the server in which the command is made
- `!restart` Allows you to restart the Selfbot
- `!create_role <n> <color>` Allows you to create a role on a server
- `!addar <trigger>, <response>` Allows you to add an automatic reply to a message 
- `!removear <trigger>` Allows you to remove an automatic response to a message
- `!lister` Displays the list of automatic messages
- `!change_hypesquad` Allows you to change your hypesquad badge in 1s
- `!joinvc <channel_id>` Join a voice channel by ID
- `!leavevc` Leave the current voice channel
- `!nuke` Delete all channels in the server (Dangerous)
- `!purgeroles` Delete all roles in the server (Dangerous)
- `!status <text>` Set custom status
- `!clearstatus` Clear custom status
- `.startstatusrotator` Start the status rotator
- `.stopstatusrotator` Stop the status rotator and clear status
- `.clone <source_guild_id> <target_guild_id>` Clone a server's structure to another server
- `.clean <amount>` Remove messages sent by the bot itself
- `.delete <category_id>` Delete all channels in a specific category
- `.web` Sends website
"""
        await ctx.send(help_message)
        await ctx.message.delete()

async def setup(bot):
    await bot.add_cog(SelfbotFeatures(bot))