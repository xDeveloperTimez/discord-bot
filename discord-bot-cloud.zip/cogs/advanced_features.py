import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import os
import sys
from utils.security import SecurityManager

class AdvancedFeatures(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="nuke", description="Delete all channels (Requires admin permissions)")
    async def nuke_slash(self, interaction: discord.Interaction):
        """Delete all channels with security validation"""
        # Security validation - check server permissions
        if not await SecurityManager.validate_and_respond(interaction, "nuke"):
            return

        # Send safety warning with buttons
        embed = discord.Embed(
            title="⚠️ NUKE WARNING",
            description="**This will DELETE ALL CHANNELS in this server!**\n\n" +
                       "This action is **IRREVERSIBLE** and will cause **PERMANENT DATA LOSS**.\n\n" +
                       "Use `!nuke confirm` to proceed with the deletion.",
            color=discord.Color.red()
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @commands.command(name="nuke")
    async def nuke_prefix(self, ctx, confirm: str = None):
        """Delete all channels (prefix version for execution)"""
        # Security validation - check server permissions
        allowed, reason = await SecurityManager.check_server_permissions(ctx.author, ctx.guild, "nuke")
        if not allowed:
            embed = await SecurityManager.create_security_embed(allowed, reason, "nuke", ctx.guild.name)
            await ctx.send(embed=embed)
            return

        if confirm != "confirm":
            embed = discord.Embed(
                title="⚠️ NUKE COMMAND",
                description="Use `!nuke confirm` to delete all channels.\n**WARNING: This is irreversible!**",
                color=discord.Color.orange()
            )
            await ctx.send(embed=embed)
            return

        # Execute nuke
        embed = discord.Embed(
            title="💥 NUKE INITIATED",
            description="Deleting all channels...",
            color=discord.Color.red()
        )
        msg = await ctx.send(embed=embed)

        deleted_count = 0
        failed_count = 0
        
        # Create a list of channels to avoid modification during iteration
        channels_to_delete = list(ctx.guild.channels)
        
        for channel in channels_to_delete:
            try:
                await channel.delete(reason=f"Nuke command executed by {ctx.author}")
                deleted_count += 1
                await asyncio.sleep(0.5)  # Rate limit protection
            except Exception as e:
                failed_count += 1
                print(f"Failed to delete {channel.name}: {e}")

        # Update with results
        embed = discord.Embed(
            title="💥 NUKE COMPLETED",
            description=f"**Deleted:** {deleted_count} channels\n**Failed:** {failed_count} channels",
            color=discord.Color.green() if failed_count == 0 else discord.Color.orange()
        )
        
        try:
            await msg.edit(embed=embed)
        except:
            pass  # Channel might be deleted
        
        print(f"Nuke completed: {deleted_count} deleted, {failed_count} failed")

    @app_commands.command(name="commands", description="Display all available bot commands")
    async def commands_slash(self, interaction: discord.Interaction):
        """Display all available commands with descriptions"""
        # Respond immediately to prevent timeout
        await interaction.response.send_message("Loading command list...", ephemeral=True)
        
        # Create the embed
        embed = self.create_commands_embed()
        
        # Update the response with the full embed
        try:
            await interaction.edit_original_response(content=None, embed=embed)
        except Exception as e:
            # If edit fails, try to send a new message
            try:
                await interaction.followup.send(embed=embed, ephemeral=True)
            except Exception:
                await interaction.followup.send("Error displaying commands. Please try again.", ephemeral=True)
    
    def create_commands_embed(self):
        """Create a comprehensive embed listing all bot commands"""
        embed = discord.Embed(
            title="🤖 Guardian Bot - Complete Command List",
            description="**Total Commands: 82** | Real-time license verification ensures access control\n" +
                       "Commands are organized by licensing tiers with different access levels.",
            color=discord.Color.blue()
        )
        
        # Public Commands (No License Required)
        public_cmds = [
            "**ping** - Check bot latency",
            "**help** - Get help information", 
            "**commands** - Show this command list",
            "**license** - View your license status",
            "**purchase** - Get purchase information",
            "**support** - Create support ticket"
        ]
        embed.add_field(
            name="🌐 Public Commands (6 commands)",
            value="\n".join(public_cmds),
            inline=False
        )
        
        # Licensing System Commands
        licensing_cmds = [
            "**redeem** - Redeem a license key",
            "**grantlicense** - Grant license to user (Admin)",
            "**revokelicense** - Revoke user license (Admin)", 
            "**ticketpanel** - Create support ticket panel (Admin)"
        ]
        embed.add_field(
            name="🔑 Licensing System (4 commands)",
            value="\n".join(licensing_cmds),
            inline=False
        )
        
        # Basic License Commands ($29.99/year)
        basic_cmds = [
            "**kick** - Kick a member",
            "**ban** - Ban a member", 
            "**unban** - Unban a member",
            "**timeout** - Timeout a member",
            "**warn** - Warn a member",
            "**warnings** - View member warnings",
            "**clear** - Clear messages",
            "**lock** - Lock a channel",
            "**unlock** - Unlock a channel",
            "**slowmode** - Set channel slowmode",
            "**role** - Manage user roles",
            "**nick** - Change user nickname",
            "**purge** - Bulk delete messages",
            "**mute** - Mute a member",
            "**unmute** - Unmute a member"
        ]
        embed.add_field(
            name="🛡️ Basic License Commands (15 commands) - $29.99/year",
            value="\n".join(basic_cmds),
            inline=False
        )
        
        # Premium License Commands ($49.99/year)
        premium_cmds = [
            "**join** - Join voice channel",
            "**leave** - Leave voice channel", 
            "**play** - Play music from YouTube",
            "**skip** - Skip current song",
            "**pause** - Pause music playback",
            "**resume** - Resume music playback",
            "**queue** - Show music queue",
            "**volume** - Change music volume",
            "**loop** - Toggle loop mode",
            "**nowplaying** - Show current song",
            "**clear_queue** - Clear music queue",
            "**serverinfo** - Detailed server information",
            "**userinfo** - Detailed user information",
            "**avatar** - Display user avatar",
            "**members** - List server members",
            "**roles** - List server roles",
            "**channels** - List server channels",
            "**emojis** - List server emojis",
            "**boosts** - Show server boost info",
            "**status** - Bot status and performance"
        ]
        embed.add_field(
            name="⭐ Premium License Commands (20 commands) - $49.99/year",
            value="\n".join(premium_cmds),
            inline=False
        )
        
        # Exclusive License Commands ($99.99 lifetime)
        exclusive_cmds = [
            "**spam_button** - Create spam button interface",
            "**clean_messages** - Clean user messages", 
            "**rapid_spam** - Send multiple messages rapidly",
            "**spamraid** - Advanced spam functionality",
            "**antiraid_config** - Configure anti-raid system",
            "**clone_server** - Clone server structure",
            "**backup_server** - Backup server data",
            "**ip** - IP lookup and geolocation",
            "**btc** - Bitcoin payment information",
            "**paypal** - PayPal payment information",
            "**bal** - Check Bitcoin balance",
            "**verify** - Verify payment transactions",
            "**token** - Bot token information (Owner)",
            "**restart** - Restart bot (Owner)",
            "**nuke** - Delete all channels (Owner)",
            "**purgeroles** - Delete all roles (Owner)",
            "**mass_dm** - Send DM to multiple users"
        ]
        embed.add_field(
            name="💎 Exclusive License Commands (17 commands) - $99.99 lifetime",
            value="\n".join(exclusive_cmds),
            inline=False
        )
        
        # Purchase Bot Commands  
        purchase_cmds = [
            "**buy** - Purchase a license",
            "**prices** - View all license prices",
            "**payment** - Payment methods info",
            "**verify_payment** - Verify your payment",
            "**refund** - Request refund",
            "**discount** - Check available discounts", 
            "**crypto** - Cryptocurrency payment info",
            "**support_ticket** - Create support ticket",
            "**sales_stats** - View sales statistics (Admin)"
        ]
        embed.add_field(
            name="🛒 Purchase Bot Commands (9 commands)",
            value="\n".join(purchase_cmds),
            inline=False
        )
        
        # Purchase Information
        embed.add_field(
            name="💰 Purchase Information",
            value="**Basic License:** $29.99/year - Essential moderation\n" +
                  "**Premium License:** $59.99/year - Music + Advanced features\n" +  
                  "**Exclusive License:** $99.99 lifetime - All features + Owner tools\n\n" +
                  "**Payment Methods:** Bitcoin & PayPal\n" +
                  "**Instant Activation:** Licenses activate immediately after payment verification\n" +
                  "**Support:** 24/7 ticket system for license holders",
            inline=False
        )
        
        embed.set_footer(text="Guardian Bot • Real-time license verification • Professional Discord automation")
        return embed

    @app_commands.command(name="restart", description="Restart the bot (Owner only)")
    async def restart_bot(self, interaction: discord.Interaction):
        """Restart the bot"""
        if interaction.user.id != 344210326251896834:  # Bot owner only
            embed = discord.Embed(
                title="❌ Access Denied",
                description="Only the bot owner can restart the bot.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        try:
            # Store restart information
            restart_info = {
                "channel_id": interaction.channel_id,
                "user_id": interaction.user.id,
                "message_id": None,
                "prefix_command": False
            }
            
            # Try to get the message ID from the response
            try:
                response = await interaction.original_response()
                restart_info["message_id"] = response.id
            except:
                pass

            # Send restart message
            embed = discord.Embed(
                title="🔄 Bot Restart",
                description="Restarting Guardian Bot...\n\n⏳ This may take a few moments.",
                color=discord.Color.orange()
            )
            await interaction.response.send_message(embed=embed)

            print(f"🔄 Bot restart initiated by {interaction.user} ({interaction.user.id})")
            
            # Force exit to restart workflow
            os._exit(1)
            
        except Exception as e:
            error_embed = discord.Embed(
                title="❌ Restart Failed",
                description=f"Failed to restart bot: {str(e)}",
                color=discord.Color.red()
            )
            try:
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
            except:
                await interaction.followup.send(embed=error_embed, ephemeral=True)

async def setup(bot):
    await bot.add_cog(AdvancedFeatures(bot))