"""
Moderation commands cog
"""

import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime, timedelta
import asyncio
from utils.checks import is_moderator, is_admin
from utils.helpers import parse_time, format_time

class Moderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    async def log_action(self, guild, action, moderator, target, reason=None, duration=None):
        """Log moderation actions to the log channel"""
        if not self.bot.config.log_channel:
            return
        
        log_channel = guild.get_channel(self.bot.config.log_channel)
        if not log_channel:
            return
        
        embed = discord.Embed(
            title=f"🔨 {action}",
            color=discord.Color.orange(),
            timestamp=datetime.now()
        )
        
        embed.add_field(name="Target", value=f"{target} ({target.id})", inline=True)
        embed.add_field(name="Moderator", value=f"{moderator} ({moderator.id})", inline=True)
        
        if reason:
            embed.add_field(name="Reason", value=reason, inline=False)
        
        if duration:
            embed.add_field(name="Duration", value=duration, inline=True)
        
        try:
            await log_channel.send(embed=embed)
        except:
            pass
    
    @app_commands.command(name="kick", description="Kick a member from the server")
    @app_commands.describe(
        member="The member to kick",
        reason="Reason for kicking"
    )
    async def kick(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
        """Kick a member from the server"""
        if not is_moderator(interaction.user, self.bot.config):
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You need moderator permissions to use this command.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        if member.top_role >= interaction.user.top_role and interaction.user != interaction.guild.owner:
            embed = discord.Embed(
                title="❌ Insufficient Permissions",
                description="You cannot kick this member due to role hierarchy.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        if not interaction.guild.me.guild_permissions.kick_members:
            embed = discord.Embed(
                title="❌ Missing Permissions",
                description="I don't have permission to kick members.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            # Send DM to user before kicking
            try:
                dm_embed = discord.Embed(
                    title="⚠️ You have been kicked",
                    description=f"You were kicked from **{interaction.guild.name}**",
                    color=discord.Color.orange()
                )
                dm_embed.add_field(name="Reason", value=reason, inline=False)
                dm_embed.add_field(name="Moderator", value=str(interaction.user), inline=False)
                await member.send(embed=dm_embed)
            except:
                pass  # User has DMs disabled
            
            await member.kick(reason=f"{reason} | Moderator: {interaction.user}")
            
            embed = discord.Embed(
                title="✅ Member Kicked",
                description=f"**{member}** has been kicked from the server.",
                color=discord.Color.green()
            )
            embed.add_field(name="Reason", value=reason, inline=False)
            embed.add_field(name="Moderator", value=str(interaction.user), inline=False)
            
            await interaction.response.send_message(embed=embed)
            await self.log_action(interaction.guild, "Kick", interaction.user, member, reason)
            
        except discord.Forbidden:
            embed = discord.Embed(
                title="❌ Failed to Kick",
                description="I don't have permission to kick this member.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="ban", description="Ban a member from the server")
    @app_commands.describe(
        member="The member to ban",
        reason="Reason for banning",
        delete_days="Days of messages to delete (0-7)"
    )
    async def ban(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided", delete_days: int = 0):
        """Ban a member from the server"""
        if not is_moderator(interaction.user, self.bot.config):
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You need moderator permissions to use this command.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        if member.top_role >= interaction.user.top_role and interaction.user != interaction.guild.owner:
            embed = discord.Embed(
                title="❌ Insufficient Permissions",
                description="You cannot ban this member due to role hierarchy.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        if not interaction.guild.me.guild_permissions.ban_members:
            embed = discord.Embed(
                title="❌ Missing Permissions",
                description="I don't have permission to ban members.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        if delete_days < 0 or delete_days > 7:
            delete_days = 0
        
        try:
            # Send DM to user before banning
            try:
                dm_embed = discord.Embed(
                    title="🔨 You have been banned",
                    description=f"You were banned from **{interaction.guild.name}**",
                    color=discord.Color.red()
                )
                dm_embed.add_field(name="Reason", value=reason, inline=False)
                dm_embed.add_field(name="Moderator", value=str(interaction.user), inline=False)
                await member.send(embed=dm_embed)
            except:
                pass  # User has DMs disabled
            
            await member.ban(reason=f"{reason} | Moderator: {interaction.user}", delete_message_days=delete_days)
            
            embed = discord.Embed(
                title="✅ Member Banned",
                description=f"**{member}** has been banned from the server.",
                color=discord.Color.red()
            )
            embed.add_field(name="Reason", value=reason, inline=False)
            embed.add_field(name="Moderator", value=str(interaction.user), inline=False)
            if delete_days > 0:
                embed.add_field(name="Messages Deleted", value=f"{delete_days} days", inline=False)
            
            await interaction.response.send_message(embed=embed)
            await self.log_action(interaction.guild, "Ban", interaction.user, member, reason)
            
        except discord.Forbidden:
            embed = discord.Embed(
                title="❌ Failed to Ban",
                description="I don't have permission to ban this member.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="unban", description="Unban a user from the server")
    @app_commands.describe(
        user_id="The ID of the user to unban",
        reason="Reason for unbanning"
    )
    async def unban(self, interaction: discord.Interaction, user_id: str, reason: str = "No reason provided"):
        """Unban a user from the server"""
        if not is_moderator(interaction.user, self.bot.config):
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You need moderator permissions to use this command.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        if not interaction.guild.me.guild_permissions.ban_members:
            embed = discord.Embed(
                title="❌ Missing Permissions",
                description="I don't have permission to unban members.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            user_id = int(user_id)
        except ValueError:
            embed = discord.Embed(
                title="❌ Invalid User ID",
                description="Please provide a valid user ID.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            user = await self.bot.fetch_user(user_id)
            await interaction.guild.unban(user, reason=f"{reason} | Moderator: {interaction.user}")
            
            embed = discord.Embed(
                title="✅ User Unbanned",
                description=f"**{user}** has been unbanned from the server.",
                color=discord.Color.green()
            )
            embed.add_field(name="Reason", value=reason, inline=False)
            embed.add_field(name="Moderator", value=str(interaction.user), inline=False)
            
            await interaction.response.send_message(embed=embed)
            await self.log_action(interaction.guild, "Unban", interaction.user, user, reason)
            
        except discord.NotFound:
            embed = discord.Embed(
                title="❌ User Not Found",
                description="This user is not banned or doesn't exist.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
        except discord.Forbidden:
            embed = discord.Embed(
                title="❌ Failed to Unban",
                description="I don't have permission to unban this user.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="mute", description="Mute a member")
    @app_commands.describe(
        member="The member to mute",
        duration="Duration (e.g., 10m, 1h, 1d)",
        reason="Reason for muting"
    )
    async def mute(self, interaction: discord.Interaction, member: discord.Member, duration: str = None, reason: str = "No reason provided"):
        """Mute a member by adding the mute role"""
        if not is_moderator(interaction.user, self.bot.config):
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You need moderator permissions to use this command.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Get or create mute role
        mute_role = discord.utils.get(interaction.guild.roles, name=self.bot.config.mute_role)
        if not mute_role:
            try:
                mute_role = await interaction.guild.create_role(
                    name=self.bot.config.mute_role,
                    reason="Auto-created mute role",
                    permissions=discord.Permissions(send_messages=False, speak=False)
                )
                
                # Set up channel overwrites for mute role
                for channel in interaction.guild.channels:
                    try:
                        if isinstance(channel, discord.TextChannel):
                            await channel.set_permissions(mute_role, send_messages=False, add_reactions=False)
                        elif isinstance(channel, discord.VoiceChannel):
                            await channel.set_permissions(mute_role, speak=False)
                    except:
                        continue
                        
            except discord.Forbidden:
                embed = discord.Embed(
                    title="❌ Cannot Create Mute Role",
                    description="I don't have permission to create roles.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
        
        if mute_role in member.roles:
            embed = discord.Embed(
                title="❌ Already Muted",
                description="This member is already muted.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Parse duration
        until = None
        if duration:
            duration_seconds = parse_time(duration)
            if duration_seconds:
                until = datetime.now() + timedelta(seconds=duration_seconds)
        
        try:
            await member.add_roles(mute_role, reason=f"{reason} | Moderator: {interaction.user}")
            
            # Add to database
            self.bot.db.add_mute(interaction.guild.id, member.id, until)
            
            embed = discord.Embed(
                title="✅ Member Muted",
                description=f"**{member}** has been muted.",
                color=discord.Color.orange()
            )
            embed.add_field(name="Reason", value=reason, inline=False)
            embed.add_field(name="Moderator", value=str(interaction.user), inline=False)
            
            if until:
                embed.add_field(name="Duration", value=format_time(duration_seconds), inline=False)
                embed.add_field(name="Expires", value=f"<t:{int(until.timestamp())}:F>", inline=False)
            
            await interaction.response.send_message(embed=embed)
            await self.log_action(interaction.guild, "Mute", interaction.user, member, reason, 
                                format_time(duration_seconds) if duration_seconds else "Permanent")
            
            # Auto-unmute if duration is set
            if until:
                await asyncio.sleep(duration_seconds)
                if self.bot.db.is_muted(interaction.guild.id, member.id):
                    await member.remove_roles(mute_role, reason="Mute duration expired")
                    self.bot.db.remove_mute(interaction.guild.id, member.id)
            
        except discord.Forbidden:
            embed = discord.Embed(
                title="❌ Failed to Mute",
                description="I don't have permission to manage roles for this member.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="unmute", description="Unmute a member")
    @app_commands.describe(
        member="The member to unmute",
        reason="Reason for unmuting"
    )
    async def unmute(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
        """Unmute a member by removing the mute role"""
        if not is_moderator(interaction.user, self.bot.config):
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You need moderator permissions to use this command.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        mute_role = discord.utils.get(interaction.guild.roles, name=self.bot.config.mute_role)
        if not mute_role or mute_role not in member.roles:
            embed = discord.Embed(
                title="❌ Not Muted",
                description="This member is not muted.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            await member.remove_roles(mute_role, reason=f"{reason} | Moderator: {interaction.user}")
            self.bot.db.remove_mute(interaction.guild.id, member.id)
            
            embed = discord.Embed(
                title="✅ Member Unmuted",
                description=f"**{member}** has been unmuted.",
                color=discord.Color.green()
            )
            embed.add_field(name="Reason", value=reason, inline=False)
            embed.add_field(name="Moderator", value=str(interaction.user), inline=False)
            
            await interaction.response.send_message(embed=embed)
            await self.log_action(interaction.guild, "Unmute", interaction.user, member, reason)
            
        except discord.Forbidden:
            embed = discord.Embed(
                title="❌ Failed to Unmute",
                description="I don't have permission to manage roles for this member.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="warn", description="Warn a member")
    @app_commands.describe(
        member="The member to warn",
        reason="Reason for warning"
    )
    async def warn(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
        """Warn a member"""
        if not is_moderator(interaction.user, self.bot.config):
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You need moderator permissions to use this command.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Add warning to database
        warning_count = self.bot.db.add_warning(interaction.guild.id, member.id, interaction.user.id, reason)
        
        embed = discord.Embed(
            title="⚠️ Member Warned",
            description=f"**{member}** has been warned.",
            color=discord.Color.yellow()
        )
        embed.add_field(name="Reason", value=reason, inline=False)
        embed.add_field(name="Moderator", value=str(interaction.user), inline=False)
        embed.add_field(name="Total Warnings", value=str(warning_count), inline=False)
        
        # Check if user should be punished for too many warnings
        max_warnings = self.bot.config.get("max_warnings", 3)
        if warning_count >= max_warnings:
            punishment = self.bot.config.get("warn_punishment", "mute")
            embed.add_field(name="⚠️ Warning Limit Reached", 
                          value=f"This user has reached the warning limit and will be {punishment}d.", 
                          inline=False)
        
        await interaction.response.send_message(embed=embed)
        await self.log_action(interaction.guild, "Warn", interaction.user, member, reason)
        
        # Send DM to warned user
        try:
            dm_embed = discord.Embed(
                title="⚠️ You have been warned",
                description=f"You received a warning in **{interaction.guild.name}**",
                color=discord.Color.yellow()
            )
            dm_embed.add_field(name="Reason", value=reason, inline=False)
            dm_embed.add_field(name="Moderator", value=str(interaction.user), inline=False)
            dm_embed.add_field(name="Total Warnings", value=str(warning_count), inline=False)
            await member.send(embed=dm_embed)
        except:
            pass
    
    @app_commands.command(name="warnings", description="View warnings for a member")
    @app_commands.describe(member="The member to check warnings for")
    async def warnings(self, interaction: discord.Interaction, member: discord.Member):
        """View warnings for a member"""
        if not is_moderator(interaction.user, self.bot.config):
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You need moderator permissions to use this command.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        warnings = self.bot.db.get_warnings(interaction.guild.id, member.id)
        
        if not warnings:
            embed = discord.Embed(
                title="📋 No Warnings",
                description=f"**{member}** has no warnings.",
                color=discord.Color.green()
            )
            await interaction.response.send_message(embed=embed)
            return
        
        embed = discord.Embed(
            title=f"📋 Warnings for {member}",
            description=f"Total warnings: {len(warnings)}",
            color=discord.Color.orange()
        )
        
        for i, warning in enumerate(warnings[-5:], 1):  # Show last 5 warnings
            moderator = self.bot.get_user(warning["moderator_id"])
            moderator_name = moderator.name if moderator else "Unknown"
            
            timestamp = datetime.fromisoformat(warning["timestamp"])
            embed.add_field(
                name=f"Warning #{len(warnings) - 5 + i}",
                value=f"**Reason:** {warning['reason']}\n**Moderator:** {moderator_name}\n**Date:** <t:{int(timestamp.timestamp())}:f>",
                inline=False
            )
        
        if len(warnings) > 5:
            embed.set_footer(text=f"Showing last 5 of {len(warnings)} warnings")
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="clearwarnings", description="Clear all warnings for a member")
    @app_commands.describe(member="The member to clear warnings for")
    async def clearwarnings(self, interaction: discord.Interaction, member: discord.Member):
        """Clear all warnings for a member"""
        if not is_admin(interaction.user, self.bot.config):
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You need administrator permissions to use this command.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        cleared_count = self.bot.db.clear_warnings(interaction.guild.id, member.id)
        
        if cleared_count == 0:
            embed = discord.Embed(
                title="📋 No Warnings",
                description=f"**{member}** has no warnings to clear.",
                color=discord.Color.blue()
            )
        else:
            embed = discord.Embed(
                title="✅ Warnings Cleared",
                description=f"Cleared {cleared_count} warning(s) for **{member}**.",
                color=discord.Color.green()
            )
            embed.add_field(name="Moderator", value=str(interaction.user), inline=False)
        
        await interaction.response.send_message(embed=embed)
        
        if cleared_count > 0:
            await self.log_action(interaction.guild, "Clear Warnings", interaction.user, member)
    
    @app_commands.command(name="clear", description="Clear messages from a channel")
    @app_commands.describe(
        amount="Number of messages to delete (1-100)",
        member="Only delete messages from this member (optional)"
    )
    async def clear(self, interaction: discord.Interaction, amount: int, member: discord.Member = None):
        """Clear messages from a channel"""
        if not is_moderator(interaction.user, self.bot.config):
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You need moderator permissions to use this command.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        if not interaction.guild.me.guild_permissions.manage_messages:
            embed = discord.Embed(
                title="❌ Missing Permissions",
                description="I don't have permission to manage messages.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        if amount < 1 or amount > 100:
            embed = discord.Embed(
                title="❌ Invalid Amount",
                description="Amount must be between 1 and 100 messages.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Defer response since message deletion might take time
        await interaction.response.defer(ephemeral=True)
        
        try:
            deleted_messages = []
            
            if member:
                # Delete messages from specific member
                def check(message):
                    return message.author == member
                
                deleted_messages = await interaction.channel.purge(
                    limit=amount, 
                    check=check,
                    reason=f"Bulk delete by {interaction.user}"
                )
            else:
                # Delete messages regardless of author
                deleted_messages = await interaction.channel.purge(
                    limit=amount,
                    reason=f"Bulk delete by {interaction.user}"
                )
            
            deleted_count = len(deleted_messages)
            
            if deleted_count == 0:
                embed = discord.Embed(
                    title="📝 No Messages Deleted",
                    description="No messages were found to delete.",
                    color=discord.Color.blue()
                )
            else:
                embed = discord.Embed(
                    title="✅ Messages Cleared",
                    description=f"Successfully deleted {deleted_count} message(s).",
                    color=discord.Color.green()
                )
                embed.add_field(name="Channel", value=interaction.channel.mention, inline=True)
                embed.add_field(name="Moderator", value=interaction.user.mention, inline=True)
                
                if member:
                    embed.add_field(name="Target User", value=member.mention, inline=True)
            
            await interaction.followup.send(embed=embed, ephemeral=True)
            
            # Log the action
            if deleted_count > 0:
                log_reason = f"Cleared {deleted_count} messages"
                if member:
                    log_reason += f" from {member}"
                await self.log_action(interaction.guild, "Clear Messages", interaction.user, interaction.channel, log_reason)
            
        except discord.Forbidden:
            embed = discord.Embed(
                title="❌ Failed to Clear Messages",
                description="I don't have permission to delete messages in this channel.",
                color=discord.Color.red()
            )
            await interaction.followup.send(embed=embed, ephemeral=True)
        except discord.HTTPException as e:
            embed = discord.Embed(
                title="❌ Failed to Clear Messages",
                description=f"An error occurred: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.followup.send(embed=embed, ephemeral=True)

    # Prefix command versions for moderation
    @commands.command(name="ban")
    @commands.has_permissions(ban_members=True)
    async def ban_prefix(self, ctx, member: discord.Member, *, reason="No reason provided"):
        """Ban a member (prefix version)"""
        if not is_moderator(ctx.author, self.bot.config):
            await ctx.send("❌ You need moderator permissions to use this command.")
            return
        
        try:
            await member.ban(reason=f"Banned by {ctx.author} | {reason}")
            embed = discord.Embed(
                title="🔨 Member Banned",
                description=f"**{member}** has been banned.",
                color=discord.Color.red()
            )
            embed.add_field(name="Reason", value=reason, inline=False)
            embed.add_field(name="Moderator", value=str(ctx.author), inline=False)
            await ctx.send(embed=embed)
        except discord.Forbidden:
            await ctx.send("❌ I don't have permission to ban this member.")
        except Exception as e:
            await ctx.send(f"❌ An error occurred: {str(e)}")

    @commands.command(name="kick")
    @commands.has_permissions(kick_members=True)
    async def kick_prefix(self, ctx, member: discord.Member, *, reason="No reason provided"):
        """Kick a member (prefix version)"""
        if not is_moderator(ctx.author, self.bot.config):
            await ctx.send("❌ You need moderator permissions to use this command.")
            return
        
        try:
            await member.kick(reason=f"Kicked by {ctx.author} | {reason}")
            embed = discord.Embed(
                title="👢 Member Kicked",
                description=f"**{member}** has been kicked.",
                color=discord.Color.orange()
            )
            embed.add_field(name="Reason", value=reason, inline=False)
            embed.add_field(name="Moderator", value=str(ctx.author), inline=False)
            await ctx.send(embed=embed)
        except discord.Forbidden:
            await ctx.send("❌ I don't have permission to kick this member.")
        except Exception as e:
            await ctx.send(f"❌ An error occurred: {str(e)}")

    @commands.command(name="warn")
    async def warn_prefix(self, ctx, member: discord.Member, *, reason="No reason provided"):
        """Warn a member (prefix version)"""
        if not is_moderator(ctx.author, self.bot.config):
            await ctx.send("❌ You need moderator permissions to use this command.")
            return
        
        warning_count = self.bot.db.add_warning(ctx.guild.id, member.id, ctx.author.id, reason)
        
        embed = discord.Embed(
            title="⚠️ Member Warned",
            description=f"**{member}** has been warned.",
            color=discord.Color.yellow()
        )
        embed.add_field(name="Reason", value=reason, inline=False)
        embed.add_field(name="Moderator", value=str(ctx.author), inline=False)
        embed.add_field(name="Total Warnings", value=str(warning_count), inline=False)
        await ctx.send(embed=embed)

    @commands.command(name="mute")
    async def mute_prefix(self, ctx, member: discord.Member, duration: str = "permanent", *, reason="No reason provided"):
        """Mute a member (prefix version)"""
        if not is_moderator(ctx.author, self.bot.config):
            await ctx.send("❌ You need moderator permissions to use this command.")
            return
        
        try:
            await member.timeout(None if duration == "permanent" else discord.utils.utcnow() + timedelta(minutes=int(duration)), reason=reason)
            embed = discord.Embed(
                title="🔇 Member Muted",
                description=f"**{member}** has been muted.",
                color=discord.Color.orange()
            )
            embed.add_field(name="Duration", value=duration, inline=False)
            embed.add_field(name="Reason", value=reason, inline=False)
            embed.add_field(name="Moderator", value=str(ctx.author), inline=False)
            await ctx.send(embed=embed)
        except discord.Forbidden:
            await ctx.send("❌ I don't have permission to timeout this member.")
        except ValueError:
            await ctx.send("❌ Invalid duration. Use minutes as a number or 'permanent'.")
        except Exception as e:
            await ctx.send(f"❌ An error occurred: {str(e)}")

    @commands.command(name="clear", aliases=["purge"])
    @commands.has_permissions(manage_messages=True)
    async def clear_prefix(self, ctx, amount: int, member: discord.Member = None):
        """Clear messages (prefix version)"""
        if not is_moderator(ctx.author, self.bot.config):
            await ctx.send("❌ You need moderator permissions to use this command.")
            return
        
        if amount < 1 or amount > 100:
            await ctx.send("❌ Amount must be between 1 and 100.")
            return
        
        def check(message):
            if member:
                return message.author == member
            return True
        
        try:
            deleted = await ctx.channel.purge(limit=amount, check=check)
            embed = discord.Embed(
                title="🗑️ Messages Cleared",
                description=f"Deleted **{len(deleted)}** messages" + (f" from **{member}**" if member else ""),
                color=discord.Color.green()
            )
            embed.add_field(name="Moderator", value=str(ctx.author), inline=False)
            await ctx.send(embed=embed, delete_after=5)
        except discord.Forbidden:
            await ctx.send("❌ I don't have permission to delete messages.")
        except Exception as e:
            await ctx.send(f"❌ An error occurred: {str(e)}")

async def setup(bot):
    await bot.add_cog(Moderation(bot))
