"""
Auto-moderation cog
"""

import discord
from discord.ext import commands
import re
import asyncio
from datetime import datetime, timedelta

class AutoMod(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.spam_cache = {}  # {user_id: [timestamps]}
        self.load_automod_config()
    
    def load_automod_config(self):
        """Load auto-moderation configuration"""
        try:
            import json
            import os
            
            config_path = "config/automod_config.json"
            default_config = {
                "enabled": True,
                "spam_detection": {
                    "enabled": True,
                    "max_messages": 5,
                    "time_window": 10,
                    "punishment": "mute",
                    "duration": 300
                },
                "profanity_filter": {
                    "enabled": True,
                    "words": [
                        # Basic profanity list - can be expanded
                        "badword1", "badword2", "profanity"
                    ],
                    "punishment": "warn"
                },
                "caps_filter": {
                    "enabled": True,
                    "percentage": 70,
                    "min_length": 10,
                    "punishment": "delete"
                },
                "invite_filter": {
                    "enabled": True,
                    "punishment": "delete"
                },
                "link_filter": {
                    "enabled": False,
                    "whitelist": ["discord.com", "github.com"],
                    "punishment": "delete"
                },
                "mention_spam": {
                    "enabled": True,
                    "max_mentions": 5,
                    "punishment": "warn"
                },
                "exempt_roles": ["Moderator", "Administrator"],
                "exempt_channels": []
            }
            
            if os.path.exists(config_path):
                with open(config_path, 'r') as f:
                    config = json.load(f)
                    # Merge with defaults
                    for key, value in default_config.items():
                        if key not in config:
                            config[key] = value
                    self.automod_config = config
            else:
                os.makedirs(os.path.dirname(config_path), exist_ok=True)
                with open(config_path, 'w') as f:
                    json.dump(default_config, f, indent=4)
                self.automod_config = default_config
                
        except Exception as e:
            print(f"Error loading automod config: {e}")
            # Fallback to basic config
            self.automod_config = {"enabled": False}
    
    def is_exempt(self, member, channel):
        """Check if user or channel is exempt from auto-moderation"""
        if not self.automod_config.get("enabled", False):
            return True
        
        # Check exempt roles
        exempt_roles = self.automod_config.get("exempt_roles", [])
        if any(role.name in exempt_roles for role in member.roles):
            return True
        
        # Check exempt channels
        exempt_channels = self.automod_config.get("exempt_channels", [])
        if channel.name in exempt_channels or channel.id in exempt_channels:
            return True
        
        # Check permissions
        if member.guild_permissions.manage_messages:
            return True
        
        return False
    
    async def punish_user(self, member, punishment, reason, duration=None):
        """Apply punishment to user"""
        try:
            if punishment == "delete":
                return  # Message already deleted
            
            elif punishment == "warn":
                # Add warning
                self.bot.db.add_warning(member.guild.id, member.id, self.bot.user.id, reason)
                
                # Send DM
                try:
                    embed = discord.Embed(
                        title="⚠️ Auto-Moderation Warning",
                        description=f"You received an automatic warning in **{member.guild.name}**",
                        color=discord.Color.yellow()
                    )
                    embed.add_field(name="Reason", value=reason, inline=False)
                    await member.send(embed=embed)
                except:
                    pass
            
            elif punishment == "mute":
                # Get or create mute role
                mute_role = discord.utils.get(member.guild.roles, name=self.bot.config.mute_role)
                if not mute_role:
                    try:
                        mute_role = await member.guild.create_role(
                            name=self.bot.config.mute_role,
                            reason="Auto-created mute role",
                            permissions=discord.Permissions(send_messages=False, speak=False)
                        )
                    except:
                        return
                
                if mute_role not in member.roles:
                    await member.add_roles(mute_role, reason=f"Auto-mod: {reason}")
                    
                    # Add to database
                    until = None
                    if duration:
                        until = datetime.now() + timedelta(seconds=duration)
                    self.bot.db.add_mute(member.guild.id, member.id, until)
                    
                    # Auto-unmute after duration
                    if duration:
                        await asyncio.sleep(duration)
                        if self.bot.db.is_muted(member.guild.id, member.id):
                            await member.remove_roles(mute_role, reason="Auto-mod mute expired")
                            self.bot.db.remove_mute(member.guild.id, member.id)
                
                # Send DM
                try:
                    embed = discord.Embed(
                        title="🔇 Auto-Moderation Mute",
                        description=f"You were temporarily muted in **{member.guild.name}**",
                        color=discord.Color.orange()
                    )
                    embed.add_field(name="Reason", value=reason, inline=False)
                    if duration:
                        embed.add_field(name="Duration", value=f"{duration} seconds", inline=False)
                    await member.send(embed=embed)
                except:
                    pass
                    
        except Exception as e:
            print(f"Error applying punishment: {e}")
    
    async def log_automod_action(self, guild, action, user, reason, message=None):
        """Log auto-moderation actions"""
        if not self.bot.config.log_channel:
            return
        
        log_channel = guild.get_channel(self.bot.config.log_channel)
        if not log_channel:
            return
        
        embed = discord.Embed(
            title=f"🛡️ Auto-Moderation: {action}",
            color=discord.Color.red(),
            timestamp=datetime.now()
        )
        
        embed.add_field(name="User", value=f"{user} ({user.id})", inline=True)
        embed.add_field(name="Reason", value=reason, inline=True)
        
        if message:
            embed.add_field(name="Channel", value=message.channel.mention, inline=True)
            if message.content:
                content = message.content[:100] + "..." if len(message.content) > 100 else message.content
                embed.add_field(name="Message Content", value=f"```{content}```", inline=False)
        
        try:
            await log_channel.send(embed=embed)
        except:
            pass
    
    @commands.Cog.listener()
    async def on_message(self, message):
        """Main auto-moderation message handler"""
        if message.author.bot or not message.guild:
            return
        
        if self.is_exempt(message.author, message.channel):
            return
        
        # Check various filters
        await self.check_spam(message)
        await self.check_profanity(message)
        await self.check_caps(message)
        await self.check_invites(message)
        await self.check_links(message)
        await self.check_mention_spam(message)
    
    async def check_spam(self, message):
        """Check for spam messages"""
        config = self.automod_config.get("spam_detection", {})
        if not config.get("enabled", False):
            return
        
        user_id = message.author.id
        current_time = datetime.now().timestamp()
        
        # Initialize user in cache
        if user_id not in self.spam_cache:
            self.spam_cache[user_id] = []
        
        # Add current message timestamp
        self.spam_cache[user_id].append(current_time)
        
        # Remove old timestamps outside time window
        time_window = config.get("time_window", 10)
        self.spam_cache[user_id] = [
            timestamp for timestamp in self.spam_cache[user_id]
            if current_time - timestamp <= time_window
        ]
        
        # Check if spam threshold exceeded
        max_messages = config.get("max_messages", 5)
        if len(self.spam_cache[user_id]) >= max_messages:
            try:
                await message.delete()
            except:
                pass
            
            punishment = config.get("punishment", "mute")
            duration = config.get("duration", 300)
            
            await self.punish_user(
                message.author,
                punishment,
                "Spam detection triggered",
                duration if punishment == "mute" else None
            )
            
            await self.log_automod_action(
                message.guild,
                "Spam Detection",
                message.author,
                f"Sent {len(self.spam_cache[user_id])} messages in {time_window} seconds",
                message
            )
            
            # Clear cache for user
            self.spam_cache[user_id] = []
    
    async def check_profanity(self, message):
        """Check for profanity in messages"""
        config = self.automod_config.get("profanity_filter", {})
        if not config.get("enabled", False):
            return
        
        content = message.content.lower()
        profanity_words = config.get("words", [])
        
        for word in profanity_words:
            if word.lower() in content:
                try:
                    await message.delete()
                except:
                    pass
                
                punishment = config.get("punishment", "warn")
                await self.punish_user(
                    message.author,
                    punishment,
                    f"Used prohibited language: {word}"
                )
                
                await self.log_automod_action(
                    message.guild,
                    "Profanity Filter",
                    message.author,
                    f"Used prohibited word: {word}",
                    message
                )
                break
    
    async def check_caps(self, message):
        """Check for excessive caps"""
        config = self.automod_config.get("caps_filter", {})
        if not config.get("enabled", False):
            return
        
        content = message.content
        min_length = config.get("min_length", 10)
        
        if len(content) < min_length:
            return
        
        caps_percentage = config.get("percentage", 70)
        caps_count = sum(1 for char in content if char.isupper())
        total_letters = sum(1 for char in content if char.isalpha())
        
        if total_letters > 0:
            actual_percentage = (caps_count / total_letters) * 100
            
            if actual_percentage >= caps_percentage:
                try:
                    await message.delete()
                except:
                    pass
                
                punishment = config.get("punishment", "delete")
                if punishment != "delete":
                    await self.punish_user(
                        message.author,
                        punishment,
                        f"Excessive caps usage ({actual_percentage:.1f}%)"
                    )
                
                await self.log_automod_action(
                    message.guild,
                    "Caps Filter",
                    message.author,
                    f"Excessive caps: {actual_percentage:.1f}%",
                    message
                )
    
    async def check_invites(self, message):
        """Check for Discord invites"""
        config = self.automod_config.get("invite_filter", {})
        if not config.get("enabled", False):
            return
        
        # Discord invite patterns
        invite_pattern = r'(?:https?://)?(?:www\.)?(?:discord\.(?:gg|io|me|li)|discordapp\.com/invite)/[a-zA-Z0-9]+'
        
        if re.search(invite_pattern, message.content, re.IGNORECASE):
            try:
                await message.delete()
            except:
                pass
            
            punishment = config.get("punishment", "delete")
            if punishment != "delete":
                await self.punish_user(
                    message.author,
                    punishment,
                    "Posted Discord invite link"
                )
            
            await self.log_automod_action(
                message.guild,
                "Invite Filter",
                message.author,
                "Posted Discord invite link",
                message
            )
    
    async def check_links(self, message):
        """Check for links"""
        config = self.automod_config.get("link_filter", {})
        if not config.get("enabled", False):
            return
        
        # URL pattern
        url_pattern = r'https?://[^\s]+'
        urls = re.findall(url_pattern, message.content, re.IGNORECASE)
        
        if urls:
            whitelist = config.get("whitelist", [])
            for url in urls:
                allowed = False
                for domain in whitelist:
                    if domain.lower() in url.lower():
                        allowed = True
                        break
                
                if not allowed:
                    try:
                        await message.delete()
                    except:
                        pass
                    
                    punishment = config.get("punishment", "delete")
                    if punishment != "delete":
                        await self.punish_user(
                            message.author,
                            punishment,
                            "Posted unauthorized link"
                        )
                    
                    await self.log_automod_action(
                        message.guild,
                        "Link Filter",
                        message.author,
                        f"Posted unauthorized link: {url}",
                        message
                    )
                    break
    
    async def check_mention_spam(self, message):
        """Check for mention spam"""
        config = self.automod_config.get("mention_spam", {})
        if not config.get("enabled", False):
            return
        
        max_mentions = config.get("max_mentions", 5)
        total_mentions = len(message.mentions) + len(message.role_mentions)
        
        if total_mentions >= max_mentions:
            try:
                await message.delete()
            except:
                pass
            
            punishment = config.get("punishment", "warn")
            await self.punish_user(
                message.author,
                punishment,
                f"Mention spam ({total_mentions} mentions)"
            )
            
            await self.log_automod_action(
                message.guild,
                "Mention Spam",
                message.author,
                f"Too many mentions: {total_mentions}",
                message
            )

async def setup(bot):
    await bot.add_cog(AutoMod(bot))
