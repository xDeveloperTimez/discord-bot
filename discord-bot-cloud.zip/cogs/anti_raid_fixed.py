"""
Advanced Anti-Raid Protection System
Comprehensive protection against server raids while maintaining attack capabilities
"""

import discord
from discord.ext import commands
import json
import asyncio
from datetime import datetime, timedelta
from collections import defaultdict, deque

class AntiRaidConfigView(discord.ui.View):
    """Interactive view for anti-raid configuration dashboard"""
    
    def __init__(self, cog):
        super().__init__(timeout=300)  # 5 minutes timeout
        self.cog = cog
    
    # Row 0: Main protection controls (3 buttons)
    @discord.ui.button(label="Toggle Protection", style=discord.ButtonStyle.primary, emoji="🛡️", row=0)
    async def toggle_protection(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.cog.config["enabled"] = not self.cog.config["enabled"]
        self.cog.save_config()
        
        status = "enabled" if self.cog.config["enabled"] else "disabled"
        embed = self.cog.create_config_embed()
        await interaction.response.edit_message(embed=embed, view=self)
        await interaction.followup.send(f"✅ Anti-raid protection {status}!", ephemeral=True)
    
    @discord.ui.button(label="Auto-Lockdown", style=discord.ButtonStyle.secondary, emoji="🔒", row=0)
    async def toggle_lockdown(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.cog.config["auto_lockdown"] = not self.cog.config["auto_lockdown"]
        self.cog.save_config()
        
        status = "enabled" if self.cog.config["auto_lockdown"] else "disabled"
        embed = self.cog.create_config_embed()
        await interaction.response.edit_message(embed=embed, view=self)
        await interaction.followup.send(f"✅ Auto-lockdown {status}!", ephemeral=True)
    
    @discord.ui.button(label="Auto-Ban Raiders", style=discord.ButtonStyle.secondary, emoji="🔨", row=0)
    async def toggle_autoban(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.cog.config["auto_ban_raiders"] = not self.cog.config["auto_ban_raiders"]
        self.cog.save_config()
        
        status = "enabled" if self.cog.config["auto_ban_raiders"] else "disabled"
        embed = self.cog.create_config_embed()
        await interaction.response.edit_message(embed=embed, view=self)
        await interaction.followup.send(f"✅ Auto-ban raiders {status}!", ephemeral=True)
    
    # Row 1: Auto-protection features (2 buttons)
    @discord.ui.button(label="Anti-Spam", style=discord.ButtonStyle.success, emoji="🚫", row=1)
    async def toggle_anti_spam(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.cog.config["auto_spam_protection"] = not self.cog.config.get("auto_spam_protection", True)
        self.cog.save_config()
        
        status = "enabled" if self.cog.config["auto_spam_protection"] else "disabled"
        embed = self.cog.create_config_embed()
        await interaction.response.edit_message(embed=embed, view=self)
        await interaction.followup.send(f"✅ Auto anti-spam {status}!", ephemeral=True)
    
    @discord.ui.button(label="Channel Protection", style=discord.ButtonStyle.success, emoji="🔒", row=1)
    async def toggle_channel_protection(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.cog.config["auto_channel_protection"] = not self.cog.config.get("auto_channel_protection", True)
        self.cog.save_config()
        
        status = "enabled" if self.cog.config["auto_channel_protection"] else "disabled"
        embed = self.cog.create_config_embed()
        await interaction.response.edit_message(embed=embed, view=self)
        await interaction.followup.send(f"✅ Auto channel protection {status}!", ephemeral=True)

    # Row 2: Join threshold dropdown (1 select)
    @discord.ui.select(
        placeholder="🔢 Set Join Threshold (users/min)",
        options=[
            discord.SelectOption(label="3 users/min", description="Very strict", value="3"),
            discord.SelectOption(label="5 users/min", description="Strict", value="5"),
            discord.SelectOption(label="8 users/min", description="Moderate", value="8"),
            discord.SelectOption(label="10 users/min", description="Relaxed", value="10"),
            discord.SelectOption(label="15 users/min", description="Very relaxed", value="15"),
        ],
        row=2
    )
    async def set_join_threshold(self, interaction: discord.Interaction, select: discord.ui.Select):
        threshold = int(select.values[0])
        self.cog.config["join_threshold"] = threshold
        self.cog.save_config()
        
        embed = self.cog.create_config_embed()
        await interaction.response.edit_message(embed=embed, view=self)
        await interaction.followup.send(f"✅ Join threshold set to {threshold} users/min!", ephemeral=True)
    
    # Row 3: Message threshold dropdown (1 select)
    @discord.ui.select(
        placeholder="💬 Set Message Threshold (messages/min)",
        options=[
            discord.SelectOption(label="10 messages/min", description="Very strict", value="10"),
            discord.SelectOption(label="15 messages/min", description="Strict", value="15"),
            discord.SelectOption(label="20 messages/min", description="Moderate", value="20"),
            discord.SelectOption(label="25 messages/min", description="Relaxed", value="25"),
            discord.SelectOption(label="30 messages/min", description="Very relaxed", value="30"),
        ],
        row=3
    )
    async def set_message_threshold(self, interaction: discord.Interaction, select: discord.ui.Select):
        threshold = int(select.values[0])
        self.cog.config["message_threshold"] = threshold
        self.cog.save_config()
        
        embed = self.cog.create_config_embed()
        await interaction.response.edit_message(embed=embed, view=self)
        await interaction.followup.send(f"✅ Message threshold set to {threshold} messages/min!", ephemeral=True)
    
    # Row 4: Sensitivity dropdown (1 select) + Save button (1 button)
    @discord.ui.select(
        placeholder="⚡ Set Detection Sensitivity",
        options=[
            discord.SelectOption(label="Low", description="Less sensitive, fewer false positives", value="low", emoji="🟢"),
            discord.SelectOption(label="Medium", description="Balanced detection", value="medium", emoji="🟡"),
            discord.SelectOption(label="High", description="Very sensitive, maximum protection", value="high", emoji="🔴"),
        ],
        row=4
    )
    async def set_sensitivity(self, interaction: discord.Interaction, select: discord.ui.Select):
        sensitivity = select.values[0]
        self.cog.config["sensitivity"] = sensitivity
        self.cog.save_config()
        
        embed = self.cog.create_config_embed()
        await interaction.response.edit_message(embed=embed, view=self)
        await interaction.followup.send(f"✅ Detection sensitivity set to {sensitivity.title()}!", ephemeral=True)
    
    @discord.ui.button(label="Save & Close", style=discord.ButtonStyle.success, emoji="💾", row=4)
    async def save_close(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="✅ Configuration Saved",
            description="All anti-raid settings have been saved successfully!",
            color=discord.Color.green()
        )
        await interaction.response.edit_message(embed=embed, view=None)