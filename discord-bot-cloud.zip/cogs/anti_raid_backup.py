"""
Advanced Anti-Raid Protection System
Comprehensive protection against server raids while maintaining attack capabilities
"""

import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import json
import time
from datetime import datetime, timedelta
from collections import defaultdict, deque

class AntiRaidConfigView(discord.ui.View):
    """Interactive view for anti-raid configuration dashboard"""
    
    def __init__(self, cog):
        super().__init__(timeout=300)  # 5 minutes timeout
        self.cog = cog
    
    @discord.ui.button(label="Toggle Protection", style=discord.ButtonStyle.primary, emoji="🛡️", row=0)
    async def toggle_protection(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.cog.config["enabled"] = not self.cog.config["enabled"]
        self.cog.save_config()
        
        status = "enabled" if self.cog.config["enabled"] else "disabled"
        embed = self.cog.create_config_embed()
        await interaction.response.edit_message(embed=embed, view=self)
        await interaction.followup.send(f"✅ Anti-raid protection {status}!", ephemeral=True)
    
    @discord.ui.button(label="Auto-Lockdown", style=discord.ButtonStyle.secondary, emoji="🔒", row=0)
    async def toggle_lockdown(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.cog.config["auto_lockdown"] = not self.cog.config["auto_lockdown"]
        self.cog.save_config()
        
        status = "enabled" if self.cog.config["auto_lockdown"] else "disabled"
        embed = self.cog.create_config_embed()
        await interaction.response.edit_message(embed=embed, view=self)
        await interaction.followup.send(f"✅ Auto-lockdown {status}!", ephemeral=True)
    
    @discord.ui.button(label="Auto-Ban Raiders", style=discord.ButtonStyle.secondary, emoji="🔨", row=0)
    async def toggle_autoban(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.cog.config["auto_ban_raiders"] = not self.cog.config["auto_ban_raiders"]
        self.cog.save_config()
        
        status = "enabled" if self.cog.config["auto_ban_raiders"] else "disabled"
        embed = self.cog.create_config_embed()
        await interaction.response.edit_message(embed=embed, view=self)
        await interaction.followup.send(f"✅ Auto-ban raiders {status}!", ephemeral=True)
    
    @discord.ui.button(label="Anti-Spam", style=discord.ButtonStyle.success, emoji="🚫", row=1)
    async def toggle_anti_spam(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.cog.config["auto_spam_protection"] = not self.cog.config.get("auto_spam_protection", True)
        self.cog.save_config()
        
        status = "enabled" if self.cog.config["auto_spam_protection"] else "disabled"
        embed = self.cog.create_config_embed()
        await interaction.response.edit_message(embed=embed, view=self)
        await interaction.followup.send(f"✅ Auto anti-spam {status}!", ephemeral=True)
    
    @discord.ui.button(label="Channel Protection", style=discord.ButtonStyle.success, emoji="🔒", row=1)
    async def toggle_channel_protection(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.cog.config["auto_channel_protection"] = not self.cog.config.get("auto_channel_protection", True)
        self.cog.save_config()
        
        status = "enabled" if self.cog.config["auto_channel_protection"] else "disabled"
        embed = self.cog.create_config_embed()
        await interaction.response.edit_message(embed=embed, view=self)
        await interaction.followup.send(f"✅ Auto channel protection {status}!", ephemeral=True)
    
    @discord.ui.select(
        placeholder="🔢 Set Join Threshold (users/min)",
        options=[
            discord.SelectOption(label="3 users/min", description="Very strict", value="3"),
            discord.SelectOption(label="5 users/min", description="Strict", value="5"),
            discord.SelectOption(label="8 users/min", description="Moderate", value="8"),
            discord.SelectOption(label="10 users/min", description="Relaxed", value="10"),
            discord.SelectOption(label="15 users/min", description="Very relaxed", value="15"),
        ],
        row=3
    )
    async def set_join_threshold(self, interaction: discord.Interaction, select: discord.ui.Select):
        threshold = int(select.values[0])
        self.cog.config["join_threshold"] = threshold
        self.cog.save_config()
        
        embed = self.cog.create_config_embed()
        await interaction.response.edit_message(embed=embed, view=self)
        await interaction.followup.send(f"✅ Join threshold set to {threshold} users/min!", ephemeral=True)
    
    @discord.ui.select(
        placeholder="💬 Set Message Threshold (messages/min)",
        options=[
            discord.SelectOption(label="10 messages/min", description="Very strict", value="10"),
            discord.SelectOption(label="15 messages/min", description="Strict", value="15"),
            discord.SelectOption(label="20 messages/min", description="Moderate", value="20"),
            discord.SelectOption(label="25 messages/min", description="Relaxed", value="25"),
            discord.SelectOption(label="30 messages/min", description="Very relaxed", value="30"),
        ],
        row=4
    )
    async def set_message_threshold(self, interaction: discord.Interaction, select: discord.ui.Select):
        threshold = int(select.values[0])
        self.cog.config["message_threshold"] = threshold
        self.cog.save_config()
        
        embed = self.cog.create_config_embed()
        await interaction.response.edit_message(embed=embed, view=self)
        await interaction.followup.send(f"✅ Message threshold set to {threshold} messages/min!", ephemeral=True)
    
    @discord.ui.select(
        placeholder="⚡ Set Detection Sensitivity",
        options=[
            discord.SelectOption(label="Low", description="Less sensitive, fewer false positives", value="low", emoji="🟢"),
            discord.SelectOption(label="Medium", description="Balanced detection", value="medium", emoji="🟡"),
            discord.SelectOption(label="High", description="Very sensitive, maximum protection", value="high", emoji="🔴"),
        ],
        row=2
    )
    async def set_sensitivity(self, interaction: discord.Interaction, select: discord.ui.Select):
        sensitivity = select.values[0]
        self.cog.config["sensitivity"] = sensitivity
        self.cog.save_config()
        
        embed = self.cog.create_config_embed()
        await interaction.response.edit_message(embed=embed, view=self)
        await interaction.followup.send(f"✅ Detection sensitivity set to {sensitivity.title()}!", ephemeral=True)
    
    @discord.ui.button(label="Save & Close", style=discord.ButtonStyle.success, emoji="💾", row=4)
    async def save_close(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="✅ Configuration Saved",
            description="All anti-raid settings have been saved successfully!",
            color=discord.Color.green()
        )
        embed.add_field(name="Status", value="Configuration dashboard closed", inline=False)
        
        # Disable all components
        for item in self.children:
            if hasattr(item, 'disabled'):
                item.disabled = True
        
        await interaction.response.edit_message(embed=embed, view=self)

class AntiRaid(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.config = self.load_config()
        
        # Tracking systems
        self.join_tracker = defaultdict(deque)  # Track joins per guild
        self.message_tracker = defaultdict(deque)  # Track message spam
        self.channel_create_tracker = defaultdict(deque)  # Track channel creation
        self.role_create_tracker = defaultdict(deque)  # Track role creation
        self.ban_tracker = defaultdict(deque)  # Track mass bans
        
        # Auto anti-spam tracking (new feature)
        self.spam_tracker = defaultdict(lambda: defaultdict(deque))  # Guild ID -> User ID -> message timestamps
        self.timed_out_users = defaultdict(set)  # Guild ID -> set of timed out user IDs
        
        # Temporary restrictions
        self.lockdown_guilds = set()
        self.restricted_users = defaultdict(lambda: {"until": 0, "reason": ""})
        
        # Whitelist system
        self.whitelisted_users = set()
        self.whitelisted_roles = set()
        
    def load_config(self):
        """Load anti-raid configuration"""
        try:
            with open("anti_raid_config.json", "r") as f:
                return json.load(f)
        except FileNotFoundError:
            # Default configuration
            config = {
                "enabled": True,
                "join_threshold": 10,  # Max joins per minute
                "join_timeframe": 60,  # Timeframe in seconds
                "message_threshold": 15,  # Max messages per user per minute
                "channel_create_threshold": 5,  # Max channels created per minute
                "role_create_threshold": 3,  # Max roles created per minute
                "auto_lockdown": True,
                "auto_ban_raiders": True,
                "delete_raid_channels": True,
                "delete_raid_roles": True,
                "log_channel": None,
                "admin_role": "Administrator",
                "trusted_role": "Trusted",
                "lockdown_duration": 300,  # 5 minutes
                "sensitivity": "medium",  # low, medium, high
                # New anti-spam features
                "auto_spam_protection": True,  # Enable automatic spam detection
                "spam_message_limit": 5,  # Max messages in timeframe
                "spam_timeframe": 3,  # Timeframe in seconds
                "spam_timeout_duration": 86400,  # 24 hours in seconds
                "auto_channel_protection": True,  # Enable automatic channel protection
                "channel_protection_timeout": 86400  # 24 hours for channel actions
            }
            self.save_config(config)
            return config
    
    def save_config(self, config=None):
        """Save anti-raid configuration"""
        if config:
            self.config = config
        with open("anti_raid_config.json", "w") as f:
            json.dump(self.config, f, indent=4)
    
    async def log_action(self, guild, title, description, color=discord.Color.red()):
        """Log anti-raid actions"""
        if not self.config.get("log_channel"):
            return
            
        try:
            channel = guild.get_channel(self.config["log_channel"])
            if not channel:
                return
                
            embed = discord.Embed(
                title=f"🛡️ {title}",
                description=description,
                color=color,
                timestamp=datetime.utcnow()
            )
            embed.set_footer(text="Anti-Raid Protection")
            await channel.send(embed=embed)
        except:
            pass
    
    def is_whitelisted(self, member):
        """Check if user is whitelisted"""
        if member.id in self.whitelisted_users:
            return True
        # Handle both Member and User objects (User objects don't have guild attribute)
        if hasattr(member, 'guild') and member.guild and member.guild.owner_id == member.id:
            return True
        # Only check roles if member is a Member object (not User)
        if hasattr(member, 'roles'):
            for role in member.roles:
                if role.id in self.whitelisted_roles:
                    return True
                if role.name.lower() in [self.config.get("admin_role", "").lower(), 
                                       self.config.get("trusted_role", "").lower()]:
                    return True
        return False
    
    def is_raid_pattern(self, guild_id, event_type):
        """Detect raid patterns"""
        now = time.time()
        
        if event_type == "join":
            tracker = self.join_tracker[guild_id]
            threshold = self.config["join_threshold"]
            timeframe = self.config["join_timeframe"]
        elif event_type == "message":
            tracker = self.message_tracker[guild_id]
            threshold = self.config["message_threshold"]
            timeframe = 60
        elif event_type == "channel_create":
            tracker = self.channel_create_tracker[guild_id]
            threshold = self.config["channel_create_threshold"]
            timeframe = 60
        elif event_type == "role_create":
            tracker = self.role_create_tracker[guild_id]
            threshold = self.config["role_create_threshold"]
            timeframe = 60
        else:
            return False
        
        # Clean old entries
        while tracker and tracker[0] < now - timeframe:
            tracker.popleft()
        
        return len(tracker) >= threshold
    
    @commands.Cog.listener()
    async def on_member_join(self, member):
        """Monitor suspicious join patterns"""
        if not self.config["enabled"]:
            return
            
        guild_id = member.guild.id
        now = time.time()
        
        # Track join
        self.join_tracker[guild_id].append(now)
        
        # Check for raid pattern
        if self.is_raid_pattern(guild_id, "join"):
            await self.trigger_raid_protection(member.guild, "Mass Join Detected")
    
    @commands.Cog.listener()
    async def on_message(self, message):
        """Monitor message spam patterns AND automatic anti-spam protection"""
        if not self.config["enabled"] or message.author.bot:
            return
            
        guild_id = message.guild.id if message.guild else None
        if not guild_id:
            return
            
        # Check for automatic anti-spam protection (new feature)
        if self.config.get("auto_spam_protection", True):
            await self.check_auto_spam(message)
            
        if self.is_whitelisted(message.author):
            return
            
        guild_id = message.guild.id if message.guild else None
        if not guild_id:
            return
            
        now = time.time()
        user_key = f"{guild_id}_{message.author.id}"
        
        # Track message
        if user_key not in self.message_tracker:
            self.message_tracker[user_key] = deque()
        self.message_tracker[user_key].append(now)
        
        # Check for spam pattern
        if self.is_raid_pattern(user_key, "message"):
            await self.handle_spam_user(message.author, message.guild)
    

    
    @commands.Cog.listener()
    async def on_guild_role_create(self, role):
        """Monitor mass role creation"""
        if not self.config["enabled"]:
            return
            
        guild_id = role.guild.id
        now = time.time()
        
        # Track role creation
        self.role_create_tracker[guild_id].append(now)
        
        # Check for raid pattern
        if self.is_raid_pattern(guild_id, "role_create"):
            await self.trigger_raid_protection(role.guild, "Mass Role Creation Detected")
            
            if self.config["delete_raid_roles"]:
                try:
                    await role.delete(reason="Anti-raid: Suspicious role creation")
                except:
                    pass
    
    async def check_auto_spam(self, message):
        """New automatic anti-spam protection"""
        if not message.guild:
            return
            
        guild_id = message.guild.id
        user_id = message.author.id
        now = time.time()
        
        # Skip if user is already timed out
        if user_id in self.timed_out_users[guild_id]:
            return
            
        # Skip if user is whitelisted
        if self.is_whitelisted(message.author):
            return
            
        # Track user messages
        if user_id not in self.spam_tracker[guild_id]:
            self.spam_tracker[guild_id][user_id] = deque()
            
        user_messages = self.spam_tracker[guild_id][user_id]
        user_messages.append(now)
        
        # Clean old messages outside timeframe
        spam_timeframe = self.config.get("spam_timeframe", 3)
        while user_messages and user_messages[0] < now - spam_timeframe:
            user_messages.popleft()
            
        # Check if user exceeded spam limit
        spam_limit = self.config.get("spam_message_limit", 5)
        if len(user_messages) >= spam_limit:
            await self.auto_timeout_user(message.author, message.guild, "Auto anti-spam: Too many messages")
    
    async def auto_timeout_user(self, user, guild, reason):
        """Automatically timeout a user for spam"""
        try:
            timeout_duration = self.config.get("spam_timeout_duration", 86400)  # 24 hours
            timeout_until = datetime.utcnow() + timedelta(seconds=timeout_duration)
            
            # Apply timeout
            await user.timeout(timeout_until, reason=reason)
            
            # Track timed out user
            self.timed_out_users[guild.id].add(user.id)
            
            # Log the action
            await self.log_action(
                guild, 
                "Auto Anti-Spam Protection", 
                f"🚫 **User Timed Out**\n"
                f"**User:** {user.mention} (`{user.id}`)\n"
                f"**Reason:** {reason}\n"
                f"**Duration:** 24 hours\n"
                f"**Triggered:** Sent 5+ messages in 3 seconds",
                discord.Color.orange()
            )
            
            # Remove from tracking after timeout expires
            await asyncio.sleep(timeout_duration)
            if user.id in self.timed_out_users[guild.id]:
                self.timed_out_users[guild.id].remove(user.id)
                
        except Exception as e:
            print(f"Error timing out user {user.id}: {e}")
    
    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        """Monitor channel deletions and timeout users"""
        if not self.config["enabled"] or not self.config.get("auto_channel_protection", True):
            return
            
        # Get audit log to find who deleted the channel
        try:
            async for entry in channel.guild.audit_logs(action=discord.AuditLogAction.channel_delete, limit=1):
                if entry.target.id == channel.id:
                    deleter = entry.user
                    
                    # Skip if whitelisted or bot
                    if deleter.bot or self.is_whitelisted(deleter):
                        return
                        
                    # Skip if user is owner
                    if deleter.id == 344210326251896834:
                        return
                        
                    # Timeout the user
                    await self.auto_timeout_channel_action(deleter, channel.guild, f"Deleted channel #{channel.name}")
                    break
        except:
            pass
    
    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel):
        """Monitor channel creation and apply automatic protection"""
        if not self.config["enabled"]:
            return
            
        # Apply automatic channel protection
        if self.config.get("auto_channel_protection", True):
            # Get audit log to find who created the channel
            try:
                async for entry in channel.guild.audit_logs(action=discord.AuditLogAction.channel_create, limit=1):
                    if entry.target.id == channel.id:
                        creator = entry.user
                        
                        # Skip if whitelisted or bot
                        if creator.bot or self.is_whitelisted(creator):
                            break
                            
                        # Skip if user is owner
                        if creator.id == 344210326251896834:
                            break
                            
                        # Timeout the user
                        await self.auto_timeout_channel_action(creator, channel.guild, f"Created channel #{channel.name}")
                        break
            except:
                pass
        
        # Original raid detection logic
        guild_id = channel.guild.id
        now = time.time()
        
        # Track channel creation
        self.channel_create_tracker[guild_id].append(now)
        
        # Check for raid pattern
        if self.is_raid_pattern(guild_id, "channel_create"):
            await self.trigger_raid_protection(channel.guild, "Mass Channel Creation Detected")
            
            if self.config["delete_raid_channels"]:
                try:
                    await channel.delete(reason="Anti-raid: Suspicious channel creation")
                except:
                    pass
    
    async def auto_timeout_channel_action(self, user, guild, action):
        """Timeout user for channel actions"""
        try:
            timeout_duration = self.config.get("channel_protection_timeout", 86400)  # 24 hours
            timeout_until = datetime.utcnow() + timedelta(seconds=timeout_duration)
            
            # Apply timeout
            await user.timeout(timeout_until, reason=f"Auto channel protection: {action}")
            
            # Log the action
            await self.log_action(
                guild,
                "Auto Channel Protection",
                f"🔒 **User Timed Out**\n"
                f"**User:** {user.mention} (`{user.id}`)\n"
                f"**Action:** {action}\n"
                f"**Duration:** 24 hours\n"
                f"**Triggered:** Automatic channel protection",
                discord.Color.red()
            )
            
        except Exception as e:
            print(f"Error timing out user {user.id} for channel action: {e}")
    
    async def trigger_raid_protection(self, guild, reason):
        """Trigger comprehensive raid protection"""
        if guild.id in self.lockdown_guilds:
            return  # Already in lockdown
            
        await self.log_action(guild, "RAID DETECTED", f"Reason: {reason}\nActivating protection measures...")
        
        if self.config["auto_lockdown"]:
            await self.lockdown_server(guild, reason)
        
        # Auto-ban recent joiners if enabled
        if self.config["auto_ban_raiders"]:
            await self.ban_recent_joiners(guild)
    
    async def lockdown_server(self, guild, reason):
        """Lock down the entire server"""
        self.lockdown_guilds.add(guild.id)
        
        try:
            # Disable @everyone permissions
            everyone_role = guild.default_role
            await everyone_role.edit(permissions=discord.Permissions.none(), reason=f"Anti-raid lockdown: {reason}")
            
            # Lock all text channels
            for channel in guild.text_channels:
                try:
                    await channel.set_permissions(everyone_role, send_messages=False, reason="Anti-raid lockdown")
                except:
                    continue
            
            await self.log_action(guild, "SERVER LOCKDOWN ACTIVATED", 
                                f"Reason: {reason}\nDuration: {self.config['lockdown_duration']} seconds",
                                discord.Color.orange())
            
            # Auto-unlock after duration
            await asyncio.sleep(self.config["lockdown_duration"])
            await self.unlock_server(guild)
            
        except Exception as e:
            await self.log_action(guild, "LOCKDOWN FAILED", f"Error: {e}")
    
    async def unlock_server(self, guild):
        """Unlock the server"""
        if guild.id not in self.lockdown_guilds:
            return
            
        try:
            self.lockdown_guilds.remove(guild.id)
            
            # Restore @everyone permissions
            everyone_role = guild.default_role
            basic_perms = discord.Permissions(
                read_messages=True,
                send_messages=True,
                read_message_history=True,
                use_external_emojis=True,
                add_reactions=True,
                connect=True,
                speak=True
            )
            await everyone_role.edit(permissions=basic_perms, reason="Anti-raid lockdown lifted")
            
            # Unlock text channels
            for channel in guild.text_channels:
                try:
                    await channel.set_permissions(everyone_role, send_messages=True, reason="Anti-raid lockdown lifted")
                except:
                    continue
            
            await self.log_action(guild, "SERVER LOCKDOWN LIFTED", 
                                "Server has been unlocked and normal operations resumed.",
                                discord.Color.green())
            
        except Exception as e:
            await self.log_action(guild, "UNLOCK FAILED", f"Error: {e}")
    
    async def ban_recent_joiners(self, guild):
        """Ban users who joined recently during suspected raid"""
        from datetime import timezone
        now = datetime.now(timezone.utc)
        cutoff = now - timedelta(minutes=5)  # Ban users who joined in last 5 minutes
        banned_count = 0
        
        for member in guild.members:
            if member.joined_at and member.joined_at > cutoff:
                if not self.is_whitelisted(member):
                    try:
                        await member.ban(reason="Anti-raid: Suspicious recent join", delete_message_days=1)
                        banned_count += 1
                    except:
                        continue
        
        await self.log_action(guild, "AUTO-BAN COMPLETED", f"Banned {banned_count} recent joiners")
    
    async def handle_spam_user(self, user, guild):
        """Handle individual spam users"""
        try:
            if not self.is_whitelisted(user):
                await user.timeout(timedelta(minutes=10), reason="Anti-raid: Message spam detected")
                await self.log_action(guild, "USER RESTRICTED", f"{user.mention} timed out for spam")
        except:
            pass
    
    # Configuration Commands
    @app_commands.command(name="antiraid_config", description="Open interactive anti-raid configuration dashboard")
    async def configure_antiraid(self, interaction: discord.Interaction):
        """Open anti-raid configuration dashboard"""
        
        # Owner-only check
        if interaction.user.id != 344210326251896834:
            await interaction.response.send_message("❌ Only the bot owner can use this command.", ephemeral=True)
            return
        
        # Create the dashboard
        view = AntiRaidConfigView(self)
        embed = self.create_config_embed()
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
    
    def create_config_embed(self):
        """Create the configuration dashboard embed"""
        embed = discord.Embed(
            title="🛡️ Anti-Raid Configuration Dashboard",
            description="Configure your server's anti-raid protection settings using the buttons below.",
            color=discord.Color.blue()
        )
        
        # Current settings
        status_icon = "🟢" if self.config["enabled"] else "🔴"
        lockdown_icon = "🟢" if self.config["auto_lockdown"] else "🔴"
        autoban_icon = "🟢" if self.config["auto_ban_raiders"] else "🔴"
        antispam_icon = "🟢" if self.config.get("auto_spam_protection", True) else "🔴"
        channel_protection_icon = "🟢" if self.config.get("auto_channel_protection", True) else "🔴"
        
        embed.add_field(
            name="🔧 System Status",
            value=f"{status_icon} **Protection:** {'Enabled' if self.config['enabled'] else 'Disabled'}\n"
                  f"{lockdown_icon} **Auto-Lockdown:** {'On' if self.config['auto_lockdown'] else 'Off'}\n"
                  f"{autoban_icon} **Auto-Ban Raiders:** {'On' if self.config['auto_ban_raiders'] else 'Off'}",
            inline=True
        )
        
        embed.add_field(
            name="🚫 Auto Protection",
            value=f"{antispam_icon} **Anti-Spam:** {'On' if self.config.get('auto_spam_protection', True) else 'Off'}\n"
                  f"{channel_protection_icon} **Channel Protection:** {'On' if self.config.get('auto_channel_protection', True) else 'Off'}\n"
                  f"📊 **Spam Limit:** {self.config.get('spam_message_limit', 5)} msgs/3s",
            inline=True
        )
        
        embed.add_field(
            name="⚡ Detection Settings",
            value=f"**Join Threshold:** {self.config['join_threshold']}/min\n"
                  f"**Message Threshold:** {self.config['message_threshold']}/min\n"
                  f"**Sensitivity:** {self.config['sensitivity'].title()}",
            inline=True
        )
        
        embed.add_field(
            name="📊 Whitelist Info",
            value=f"**Whitelisted Users:** {len(self.whitelisted_users)}\n"
                  f"**Whitelisted Roles:** {len(self.whitelisted_roles)}",
            inline=True
        )
        
        embed.set_footer(text="Use the buttons below to modify settings • Changes are saved instantly")
        return embed
    
    @app_commands.command(name="antiraid_status", description="View anti-raid protection status")
    async def antiraid_status(self, interaction: discord.Interaction):
        """Display anti-raid status"""
        
        # Owner-only check
        if interaction.user.id != 344210326251896834:
            await interaction.response.send_message("❌ Only the bot owner can use this command.", ephemeral=True)
            return
        
        guild = interaction.guild
        status = "🟢 Active" if self.config["enabled"] else "🔴 Disabled"
        lockdown_status = "🔒 Locked" if guild.id in self.lockdown_guilds else "🔓 Normal"
        
        embed = discord.Embed(
            title="🛡️ Anti-Raid Protection Status",
            color=discord.Color.blue()
        )
        
        embed.add_field(name="System Status", value=status, inline=True)
        embed.add_field(name="Server Status", value=lockdown_status, inline=True)
        embed.add_field(name="Join Threshold", value=f"{self.config['join_threshold']}/min", inline=True)
        
        embed.add_field(name="Auto Lockdown", value="✅" if self.config["auto_lockdown"] else "❌", inline=True)
        embed.add_field(name="Auto Ban", value="✅" if self.config["auto_ban_raiders"] else "❌", inline=True)
        embed.add_field(name="Sensitivity", value=self.config["sensitivity"].title(), inline=True)
        
        recent_joins = len([t for t in self.join_tracker[guild.id] if t > time.time() - 300])
        embed.add_field(name="Recent Joins (5min)", value=str(recent_joins), inline=True)
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="lockdown", description="Manually lock down the server")
    @app_commands.describe(reason="Reason for lockdown")
    async def manual_lockdown(self, interaction: discord.Interaction, reason: str = "Manual lockdown"):
        """Manually trigger server lockdown"""
        
        # Owner-only check
        if interaction.user.id != 344210326251896834:
            await interaction.response.send_message("❌ Only the bot owner can use this command.", ephemeral=True)
            return
        
        await interaction.response.defer(ephemeral=True)
        
        await self.lockdown_server(interaction.guild, reason)
        await interaction.followup.send("🔒 Server lockdown activated!", ephemeral=True)
    
    @app_commands.command(name="unlock", description="Manually unlock the server")
    async def manual_unlock(self, interaction: discord.Interaction):
        """Manually unlock the server"""
        
        # Owner-only check
        if interaction.user.id != 344210326251896834:
            await interaction.response.send_message("❌ Only the bot owner can use this command.", ephemeral=True)
            return
        
        await interaction.response.defer(ephemeral=True)
        
        await self.unlock_server(interaction.guild)
        await interaction.followup.send("🔓 Server unlocked!", ephemeral=True)
    
    @app_commands.command(name="whitelist", description="Add user to anti-raid whitelist")
    @app_commands.describe(user="User to whitelist")
    async def whitelist_user(self, interaction: discord.Interaction, user: discord.Member):
        """Add user to whitelist"""
        
        # Owner-only check
        if interaction.user.id != 344210326251896834:
            await interaction.response.send_message("❌ Only the bot owner can use this command.", ephemeral=True)
            return
        
        self.whitelisted_users.add(user.id)
        await interaction.response.send_message(f"✅ {user.mention} added to whitelist", ephemeral=True)
    
    @app_commands.command(name="unwhitelist", description="Remove user from anti-raid whitelist")
    @app_commands.describe(user="User to remove from whitelist")
    async def unwhitelist_user(self, interaction: discord.Interaction, user: discord.Member):
        """Remove user from whitelist"""
        
        # Owner-only check
        if interaction.user.id != 344210326251896834:
            await interaction.response.send_message("❌ Only the bot owner can use this command.", ephemeral=True)
            return
        
        if user.id in self.whitelisted_users:
            self.whitelisted_users.remove(user.id)
            await interaction.response.send_message(f"✅ {user.mention} removed from whitelist", ephemeral=True)
        else:
            await interaction.response.send_message(f"{user.mention} is not whitelisted", ephemeral=True)

async def setup(bot):
    await bot.add_cog(AntiRaid(bot))