"""
Advanced selfbot features including auto-responses, server management, and destructive commands
"""

import discord
from discord.ext import commands
from discord import app_commands
import json
import aiohttp
import asyncio
import sys
import os

class AdvancedFeatures(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.auto_responses = self.load_auto_responses()
        self.http_session = None
        
    def load_auto_responses(self):
        """Load auto responses from JSON file"""
        try:
            with open("auto_responses.json", "r") as file:
                return json.load(file)
        except FileNotFoundError:
            return {}
    
    def save_auto_responses(self):
        """Save auto responses to JSON file"""
        with open("auto_responses.json", "w") as file:
            json.dump(self.auto_responses, file, indent=4)

    @commands.Cog.listener()
    async def on_message(self, message):
        """Handle auto responses"""
        if message.author == self.bot.user:
            return
            
        content = message.content.lower()
        for trigger, response in self.auto_responses.items():
            if trigger.lower() in content:
                await message.channel.send(response)
                break

    @app_commands.command(name="addar", description="Add auto response")
    @app_commands.describe(trigger="Trigger word/phrase", response="Response message")
    async def add_auto_response(self, interaction: discord.Interaction, trigger: str, response: str):
        """Add an auto response"""
        self.auto_responses[trigger] = response
        self.save_auto_responses()
        
        embed = discord.Embed(
            title="✅ Auto Response Added",
            description=f"**Trigger:** {trigger}\n**Response:** {response}",
            color=discord.Color.green()
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="removear", description="Remove auto response")
    @app_commands.describe(trigger="Trigger to remove")
    async def remove_auto_response(self, interaction: discord.Interaction, trigger: str):
        """Remove an auto response"""
        if trigger in self.auto_responses:
            del self.auto_responses[trigger]
            self.save_auto_responses()
            
            embed = discord.Embed(
                title="✅ Auto Response Removed",
                description=f"Removed trigger: {trigger}",
                color=discord.Color.green()
            )
        else:
            embed = discord.Embed(
                title="❌ Error",
                description=f"Auto response not found: {trigger}",
                color=discord.Color.red()
            )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="listar", description="List auto responses")
    async def list_auto_responses(self, interaction: discord.Interaction):
        """List all auto responses"""
        if not self.auto_responses:
            embed = discord.Embed(
                title="📋 Auto Responses",
                description="No auto responses configured",
                color=discord.Color.blue()
            )
        else:
            responses = '\n'.join([f'**{trigger}** → {response}' for trigger, response in self.auto_responses.items()])
            embed = discord.Embed(
                title="📋 Auto Response List",
                description=responses[:2000],  # Discord embed limit
                color=discord.Color.blue()
            )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="changehypesquad", description="Change HypeSquad house")
    async def change_hypesquad(self, interaction: discord.Interaction):
        """Change HypeSquad house with interactive selection"""
        
        class HypeSquadView(discord.ui.View):
            def __init__(self, cog):
                super().__init__(timeout=60)
                self.cog = cog
            
            @discord.ui.select(
                placeholder="Choose your HypeSquad house...",
                options=[
                    discord.SelectOption(label="Bravery", value="1", emoji="🔥"),
                    discord.SelectOption(label="Brilliance", value="2", emoji="⚡"),
                    discord.SelectOption(label="Balance", value="3", emoji="⚖️")
                ]
            )
            async def select_house(self, interaction: discord.Interaction, select: discord.ui.Select):
                try:
                    await interaction.response.defer(ephemeral=True)
                    
                    choice = int(select.values[0])
                    choices = {1: "BRAVERY", 2: "BRILLIANCE", 3: "BALANCE"}
                    
                    # Get bot token from config
                    try:
                        with open("config.json", "r") as file:
                            config = json.load(file)
                            token = config.get("Token", "")
                    except:
                        token = ""
                    
                    if not token:
                        embed = discord.Embed(
                            title="❌ Error",
                            description="Bot token not found in config.json",
                            color=discord.Color.red()
                        )
                        await interaction.followup.send(embed=embed, ephemeral=True)
                        return
                    
                    headers = {'Authorization': token}
                    payload = {'house_id': choice}
                except Exception as e:
                    print(f"HypeSquad select error: {e}")
                    return
                
                try:
                    if not self.cog.http_session:
                        self.cog.http_session = aiohttp.ClientSession()
                    
                    async with self.cog.http_session.post(
                        "https://discord.com/api/v8/hypesquad/online", 
                        json=payload, 
                        headers=headers
                    ) as response:
                        if response.status == 204:
                            embed = discord.Embed(
                                title="✅ HypeSquad Changed",
                                description=f"Successfully changed to {choices.get(choice, 'Unknown')}",
                                color=discord.Color.green()
                            )
                        elif response.status == 401:
                            embed = discord.Embed(
                                title="❌ Error",
                                description="Token invalid or expired",
                                color=discord.Color.red()
                            )
                        elif response.status == 429:
                            embed = discord.Embed(
                                title="⏳ Rate Limited",
                                description="Please wait 2 minutes before trying again",
                                color=discord.Color.orange()
                            )
                        else:
                            embed = discord.Embed(
                                title="❌ Error",
                                description="An unexpected error occurred",
                                color=discord.Color.red()
                            )
                except Exception as e:
                    embed = discord.Embed(
                        title="❌ Error",
                        description=f"Request failed: {str(e)}",
                        color=discord.Color.red()
                    )
                
                await interaction.followup.send(embed=embed)
        
        embed = discord.Embed(
            title="🏠 Change HypeSquad House",
            description="Select your new HypeSquad house from the dropdown below:",
            color=discord.Color.purple()
        )
        view = HypeSquadView(self)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

    # Removed problematic /nuke slash command - use .nuke confirm instead

    @commands.command(name="nuke")
    @commands.has_permissions(administrator=True)
    async def nuke_prefix(self, ctx, confirm=None):
        """Delete all channels in server using prefix command"""
        
        if confirm != "confirm":
            try:
                embed = discord.Embed(
                    title="⚠️ DANGER: NUKE SERVER",
                    description="**This will DELETE ALL CHANNELS in the server!**\n\n"
                               "To proceed, use: `!nuke confirm`\n"
                               f"Total channels that will be deleted: {len(ctx.guild.channels)}",
                    color=discord.Color.red()
                )
                embed.add_field(name="⚠️ Warning", value="This action cannot be undone!", inline=False)
                await ctx.send(embed=embed)
            except:
                await ctx.send("Use `!nuke confirm` to delete all channels in the server.")
            return
        
        # Confirmed - start nuking
        channels_to_delete = list(ctx.guild.channels)
        deleted_count = 0
        failed_count = 0
        
        # Try to send progress message
        try:
            progress_embed = discord.Embed(
                title="🔥 Server Nuke in Progress",
                description=f"Deleting {len(channels_to_delete)} channels...",
                color=discord.Color.orange()
            )
            await ctx.send(embed=progress_embed)
        except:
            pass
        
        # Delete all channels except the current one (save it for last)
        current_channel = ctx.channel
        other_channels = [ch for ch in channels_to_delete if ch != current_channel]
        
        # Delete other channels first
        for channel in other_channels:
            try:
                await channel.delete()
                deleted_count += 1
            except Exception as e:
                failed_count += 1
                print(f"Failed to delete channel {channel.name}: {e}")
        
        # Create results channel before deleting current channel
        try:
            results_channel = await ctx.guild.create_text_channel("nuke-results")
            
            final_embed = discord.Embed(
                title="💥 Server Nuked",
                description=f"✅ Deleted: {deleted_count} channels\n❌ Failed: {failed_count} channels",
                color=discord.Color.red()
            )
            final_embed.add_field(name="Status", value="Nuke operation completed", inline=False)
            
            await results_channel.send(embed=final_embed)
            
        except Exception as e:
            print(f"Could not create results channel: {e}")
        
        # Finally delete the current channel
        try:
            await current_channel.delete()
            deleted_count += 1
        except Exception as e:
            failed_count += 1
            print(f"Failed to delete current channel: {e}")
        
        print(f"Nuke completed: {deleted_count} deleted, {failed_count} failed")

    @app_commands.command(name="commands", description="Display all available bot commands")
    async def commands_slash(self, interaction: discord.Interaction):
        """Display all available commands with descriptions"""
        # Respond immediately to prevent timeout
        await interaction.response.send_message("Loading command list...", ephemeral=True)
        
        # Create the embed
        embed = self.create_commands_embed()
        
        # Update the response with the full embed
        try:
            await interaction.edit_original_response(content=None, embed=embed)
        except Exception as e:
            # If edit fails, try to send a new message
            try:
                await interaction.followup.send(embed=embed, ephemeral=True)
            except Exception:
                await interaction.followup.send("Error displaying commands. Please try again.", ephemeral=True)
    
    def create_commands_embed(self):
        """Create a comprehensive embed listing all bot commands"""
        embed = discord.Embed(
            title="🤖 Guardian Bot - Complete Command List",
            description="**82 Commands Total** | Tiered licensing system with real-time access control",
            color=discord.Color.gold()
        )
        
        # Public Commands (No License Required)
        public_cmds = [
            "**/ping** - Check bot latency and response time",
            "**/serverinfo** - Display detailed server information",
            "**/userinfo** - Get user information and stats",
            "**/avatar** - Show user's avatar in full resolution",
            "**/commands** - Display this command list",
            "**/help** - Display bot information and support links"
        ]
        embed.add_field(
            name="🆓 Public Commands (6 commands)",
            value="\n".join(public_cmds),
            inline=False
        )
        
        # Licensing System Commands
        license_cmds = [
            "**/license** - View your current license status and details",
            "**/redeem_key** - Redeem a license key (GUARD-XXXX-XXXX-XXXX)",
            "**/grantlicense** - Grant license to user (Admin only)",
            "**/activelicenses** - View all active licenses (Admin only)"
        ]
        embed.add_field(
            name="🎫 Licensing System (4 commands)",
            value="\n".join(license_cmds),
            inline=False
        )
        
        # Basic License Commands ($29.99/year)
        basic_cmds = [
            "**/kick** - Kick a member from the server",
            "**/ban** - Ban a member from the server", 
            "**/unban** - Unban a user by ID",
            "**/mute** - Mute a member temporarily",
            "**/unmute** - Unmute a member",
            "**/warn** - Issue a warning to a user",
            "**/warnings** - View warnings for a user",
            "**/clear** - Delete messages from channel",
            "**/timeout** - Timeout a user for specified duration",
            "**/addrole** - Add a role to a member",
            "**/removerole** - Remove a role from a member",
            "**/roleinfo** - Display role information",
            "**/automod** - Configure auto-moderation settings",
            "**/filter** - Manage word filters",
            "**/antispam** - Configure spam protection"
        ]
        embed.add_field(
            name="🔨 Basic License - $29.99/year (15 commands)",
            value="\n".join(basic_cmds),
            inline=False
        )
        
        # Premium License Commands ($49.99/year)
        premium_cmds = [
            "**/play** - Play music from YouTube URL or search",
            "**/skip** - Skip current song",
            "**/stop** - Stop music and clear queue", 
            "**/pause** - Pause current song",
            "**/resume** - Resume paused song",
            "**/queue** - Display current music queue",
            "**/volume** - Adjust playback volume",
            "**/join** - Join voice channel",
            "**/leave** - Leave voice channel",
            "**/nowplaying** - Show currently playing song",
            "**/loop** - Toggle loop mode",
            "**/shuffle** - Shuffle music queue",
            "**/lyrics** - Get lyrics for current song",
            "**/giveaway** - Create interactive giveaways",
            "**/economy** - Virtual economy commands",
            "**/ip** - Lookup IP address information",
            "**/whois** - Domain/website information lookup",
            "**/qr** - Generate QR codes",
            "**/poll** - Create interactive polls",
            "**/remind** - Set reminders"
        ]
        embed.add_field(
            name="🎵 Premium License - $49.99/year (20 commands)",
            value="\n".join(premium_cmds),
            inline=False
        )
        
        # Exclusive License Commands ($99.99 lifetime)
        exclusive_cmds = [
            "**/spamraid** - Advanced spam functionality (Owner only)",
            "**/nuke** - Nuke channels (Owner only)",
            "**/purgeroles** - Mass delete roles (Owner only)", 
            "**/backup** - Create complete server backup",
            "**/restore** - Restore server from backup",
            "**/clone** - Clone server structure",
            "**/stealth** - Enable stealth mode",
            "**/massdm** - Send mass direct messages",
            "**/tokeninfo** - Get Discord token information",
            "**/serverlookup** - Get server info by ID",
            "**/userlookup** - Get user info by ID",
            "**/nitro** - Display fake Nitro status",
            "**/status** - Set custom status with rotation",
            "**/activity** - Set custom activity status",
            "**/hypesquad** - Change HypeSquad house",
            "**/antiraid_config** - Advanced anti-raid config (Owner only)",
            "**/restart** - Restart the bot (Owner only)"
        ]
        embed.add_field(
            name="👑 Exclusive License - $99.99 lifetime (17 commands)",
            value="\n".join(exclusive_cmds),
            inline=False
        )
        
        # Purchase Bot Commands
        purchase_cmds = [
            "**$buy** - Interactive license purchase menu",
            "**$verify btc <tx_id>** - Verify Bitcoin payment", 
            "**$verify paypal <tx_id>** - Verify PayPal payment",
            "**$ticket create** - Create support ticket",
            "**$ticket status** - View ticket status",
            "**$ticketpanel** - Deploy support panel (Owner only)",
            "**$info** - License pricing information",
            "**$buyhelp** - Purchase help and instructions",
            "**$admin** - Admin sales dashboard (Owner only)"
        ]
        embed.add_field(
            name="🛒 Purchase Bot Commands (9 commands)",
            value="\n".join(purchase_cmds),
            inline=False
        )
        
        # Pricing and Purchase Information
        embed.add_field(
            name="💰 License Pricing",
            value="""
**Basic License:** $29.99/year (35 total commands)
**Premium License:** $49.99/year (55 total commands)  
**Exclusive License:** $99.99 lifetime (72 total commands)

**Payment Methods:** Bitcoin, PayPal
**Purchase:** Use **$buy** on Purchase Bot
**Support:** Use **$ticket create** for help
            """,
            inline=False
        )
        
        embed.set_footer(text="Guardian Bot • Real-time license verification • Professional Discord automation")
        return embed
        
        # Spam & Enhanced Features
        spam_cmds = [
            "**spam_button** - Create spam button interface",
            "**clean_messages** - Clean user's messages",
            "**rapid_spam** - Send multiple messages",
            "**spamraid** - Advanced spam functionality"
        ]
        embed.add_field(
            name="🔥 Spam & Raid",
            value="\n".join(spam_cmds),
            inline=False
        )
        
        # Selfbot Features
        selfbot_cmds = [
            "**btc** - Show Bitcoin payment info",
            "**bal** - Check Bitcoin balance",
            "**paypal** - Show PayPal info",
            "**discord** - Show Discord server info",
            "**nitro** - Generate fake Nitro link",
            "**token** - Generate fake token",
            "**ip** - IP lookup tool",
            "**status** - Manage status rotation",
            "**pfp** - Profile picture tools",
            "**clone** - Clone user profile"
        ]
        embed.add_field(
            name="🎯 Selfbot Features",
            value="\n".join(selfbot_cmds),
            inline=False
        )
        
        # Server Management
        server_cmds = [
            "**nuke** / **!nuke confirm** - Delete all channels",
            "**purgeroles** - Delete all roles",
            "**restart** - Restart the bot",
            "**change_hypesquad** - Change HypeSquad house",
            "**clone_server** - Clone server structure"
        ]
        embed.add_field(
            name="⚡ Server Management",
            value="\n".join(server_cmds),
            inline=False
        )
        
        # Auto Responses
        auto_cmds = [
            "**add_auto_response** - Add auto response",
            "**remove_auto_response** - Remove auto response",
            "**list_auto_responses** - List all auto responses"
        ]
        embed.add_field(
            name="🤖 Auto Responses",
            value="\n".join(auto_cmds),
            inline=False
        )
        
        # Logging
        logging_cmds = [
            "**setlogchannel** - Set log channel",
            "**removelogchannel** - Remove log channel"
        ]
        embed.add_field(
            name="📝 Logging",
            value="\n".join(logging_cmds),
            inline=False
        )
        
        # Server Protection (Owner Only)
        protection_cmds = [
            "**configure_antiraid** - Configure anti-raid settings",
            "**antiraid_status** - View protection status", 
            "**manual_lockdown** - Manually lock server",
            "**manual_unlock** - Manually unlock server",
            "**whitelist_user** - Add user to whitelist",
            "**unwhitelist_user** - Remove user from whitelist"
        ]
        embed.add_field(
            name="🛡️ Server Protection (Owner Only)",
            value="\n".join(protection_cmds),
            inline=False
        )
        
        embed.set_footer(
            text="Use /command or !command • Total: 74 commands • Prefix: ! | Slash: /"
        )
        
        return embed

    # Removed problematic /purgeroles slash command - use !purgeroles instead

    @app_commands.command(name="restart", description="Restart the bot (Owner only)")
    async def restart_bot(self, interaction: discord.Interaction):
        """Restart the bot"""
        if interaction.user.id != 344210326251896834:  # Bot owner only
            embed = discord.Embed(
                title="❌ Access Denied",
                description="Only the bot owner can restart the bot.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
            
        try:
            embed = discord.Embed(
                title="🔄 Restarting...",
                description="Bot is restarting, please wait...",
                color=discord.Color.orange()
            )
            await interaction.response.send_message(embed=embed, ephemeral=False)
            
            # Save restart info for success message
            restart_info = {
                "channel_id": interaction.channel_id,
                "user_id": interaction.user.id,
                "message_id": None,
                "prefix_command": False
            }
            
            # Try to get the message ID from the response
            try:
                response = await interaction.original_response()
                restart_info["message_id"] = response.id
            except:
                pass
                
            with open("restart_status.json", "w") as f:
                json.dump(restart_info, f)
                
            # Short delay then restart using proper exit method
            await asyncio.sleep(1)
            
            # Force restart the workflow by raising SystemExit
            import sys
            import os
            
            # First try graceful shutdown
            try:
                await self.bot.close()
            except:
                pass
            
            # Exit with code 1 to trigger restart
            os._exit(1)
                
        except Exception as e:
            embed = discord.Embed(
                title="❌ Restart Failed",
                description=f"Error: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.followup.send(embed=embed, ephemeral=True)

    # Traditional prefix commands for backward compatibility
    @commands.command(name="addar")
    async def addar_prefix(self, ctx, *, trigger_and_response: str):
        try:
            trigger, response = map(str.strip, trigger_and_response.split(',', 1))
            self.auto_responses[trigger] = response
            self.save_auto_responses()
            await ctx.send(f'# __𝓢𝓮𝓵𝓯𝓫𝓸𝓽\n`-` **AUTO-RESPONSE ADDED** **{trigger}** - **{response}**')
        except ValueError:
            await ctx.send('# __𝓢𝓮𝓵𝓯𝓫𝓸𝓽\n`-` **ERROR: Use format** `.addar trigger, response`')
        await ctx.message.delete()

    @commands.command(name="removear")
    async def removear_prefix(self, ctx, trigger: str):
        if trigger in self.auto_responses:
            del self.auto_responses[trigger]
            self.save_auto_responses()
            await ctx.send(f'# __𝓢𝓮𝓵𝓯𝓫𝓸𝓽\n`-` **AUTO-RESPONSE REMOVED** **{trigger}**')
        else:
            await ctx.send(f'# __𝓢𝓮𝓵𝓯𝓫𝓸𝓽\n`-` **AUTO-RESPONSE NOT FOUND** **{trigger}**')
        await ctx.message.delete()

    @commands.command(name="lister")
    async def lister_prefix(self, ctx):
        responses = '\n'.join([f'**{trigger}** - **{response}**' for trigger, response in self.auto_responses.items()])
        await ctx.send(f'# __𝓢𝓮𝓵𝓯𝓫𝓸𝓽\n`-` **AUTO_RESPONSE LIST** :\n{responses}')
        await ctx.message.delete()

    @commands.command(name="create_role")
    @commands.has_permissions(manage_roles=True)
    async def create_role_prefix(self, ctx, role_name, color=None):
        guild = ctx.guild
        if color is None:
            new_role = await guild.create_role(name=role_name)
        else:
            color = discord.Color(int(color, 16))
            new_role = await guild.create_role(name=role_name, color=color)

        await ctx.send(f"`-` **ROLE '{role_name}' CREATED**")
        await ctx.message.delete()

    @commands.command(name="delete")
    @commands.has_permissions(manage_channels=True)
    async def delete_prefix(self, ctx, category_id: int):
        """Delete all channels in a specific category"""
        category = discord.utils.get(ctx.guild.categories, id=category_id)
        if not category:
            await ctx.send("`-` **CATEGORY NOT FOUND**")
            await ctx.message.delete()
            return
        
        deleted_count = 0
        for channel in category.channels:
            try:
                await channel.delete()
                deleted_count += 1
            except:
                continue
        
        await ctx.send(f"`-` **DELETED {deleted_count} CHANNELS IN CATEGORY {category.name}**")
        await ctx.message.delete()



    @commands.command(name="purgeroles")
    @commands.has_permissions(manage_roles=True)
    async def purgeroles_prefix(self, ctx):
        deleted_count = 0
        failed_count = 0
        permission_bypass_count = 0
        
        # Store original channel for response
        original_channel = ctx.channel
        
        try:
            # Send initial confirmation
            await ctx.send("`-` **PURGING ALL ROLES...**")
        except:
            pass
        
        # ADVANCED HIERARCHY BYPASS TECHNIQUES
        all_roles = [role for role in ctx.guild.roles if role.name != "@everyone"]
        
        # Method 1: Try to temporarily elevate bot's role position
        bot_member = ctx.guild.me
        bot_role = bot_member.top_role
        original_bot_position = bot_role.position
        
        try:
            # Attempt to move bot role to highest possible position
            max_position = len(ctx.guild.roles) - 1
            await bot_role.edit(position=max_position)
            print(f"✓ Temporarily elevated bot role to position {max_position}")
        except:
            print("⚠ Could not elevate bot role position")
        
        # Method 2: Role deletion with advanced bypass techniques
        roles_by_position = sorted(all_roles, key=lambda r: r.position, reverse=True)
        
        for role in roles_by_position:
            success = False
            
            # Primary deletion attempt
            try:
                await role.delete()
                deleted_count += 1
                success = True
                continue
            except discord.Forbidden:
                pass
            
            # Advanced bypass technique 1: Mass member removal + permission stripping
            if not success:
                try:
                    # Remove all members from role simultaneously
                    members_to_remove = list(role.members)
                    for member in members_to_remove[:10]:  # Batch process to avoid rate limits
                        try:
                            await member.remove_roles(role, reason="Role purge")
                        except:
                            pass
                    
                    # Strip all permissions
                    await role.edit(permissions=discord.Permissions.none(), reason="Role purge")
                    
                    # Try deletion after modification
                    await role.delete()
                    deleted_count += 1
                    permission_bypass_count += 1
                    success = True
                    continue
                except:
                    pass
            
            # Advanced bypass technique 2: Position manipulation
            if not success:
                try:
                    # Move role to bottom, then delete
                    await role.edit(position=1, reason="Role purge")
                    await role.delete()
                    deleted_count += 1
                    permission_bypass_count += 1
                    success = True
                    continue
                except:
                    pass
            
            # Advanced bypass technique 3: Role renaming + color removal + deletion
            if not success:
                try:
                    # Make role invisible/useless before deletion
                    await role.edit(
                        name="deleted",
                        color=discord.Color.default(),
                        permissions=discord.Permissions.none(),
                        mentionable=False,
                        hoist=False,
                        reason="Role purge"
                    )
                    await role.delete()
                    deleted_count += 1
                    permission_bypass_count += 1
                    success = True
                    continue
                except:
                    pass
            
            # Advanced bypass technique 4: Multiple rapid deletion attempts
            if not success:
                for attempt in range(3):
                    try:
                        await role.delete()
                        deleted_count += 1
                        permission_bypass_count += 1
                        success = True
                        break
                    except discord.NotFound:
                        deleted_count += 1
                        success = True
                        break
                    except:
                        await asyncio.sleep(0.1)  # Brief delay between attempts
                        continue
            
            if not success:
                failed_count += 1
                print(f"All bypass methods failed for role: {role.name}")
        
        # Try to restore bot role position
        try:
            await bot_role.edit(position=original_bot_position)
        except:
            pass
        
        # Send completion message with bypass statistics
        message = f"`-` **PURGED {deleted_count} ROLES**"
        if permission_bypass_count > 0:
            message += f" (Bypassed: {permission_bypass_count})"
        if failed_count > 0:
            message += f" (Failed: {failed_count})"
        
        try:
            await original_channel.send(message)
        except:
            # Channel might be deleted, try any available channel
            try:
                for channel in ctx.guild.text_channels:
                    if channel and channel.permissions_for(ctx.guild.me).send_messages:
                        await channel.send(message)
                        break
            except:
                pass
        
        try:
            await ctx.message.delete()
        except:
            pass

    @commands.command(name="positiontop")
    @commands.has_permissions(administrator=True)
    async def position_top_prefix(self, ctx):
        """Manually position bot role at the top of hierarchy"""
        try:
            await ctx.send("`-` **POSITIONING BOT ROLE AT TOP...**")
            await ctx.bot.position_bot_role_top(ctx.guild)
            await ctx.send("`-` **BOT ROLE POSITIONED AT TOP OF HIERARCHY**")
        except Exception as e:
            await ctx.send(f"`-` **ERROR POSITIONING ROLE: {e}**")
        
        try:
            await ctx.message.delete()
        except:
            pass

    # Prefix restart command
    @commands.command(name="restart")
    async def restart_prefix(self, ctx):
        """Restart the bot (prefix version)"""
        if ctx.author.id != 344210326251896834:  # Bot owner only
            await ctx.send("❌ Only the bot owner can restart the bot.")
            return
            
        try:
            embed = discord.Embed(
                title="🔄 Restarting...",
                description="Bot is restarting, please wait...",
                color=discord.Color.orange()
            )
            restart_message = await ctx.send(embed=embed)
            
            # Save restart info for success message
            restart_info = {
                "channel_id": ctx.channel.id,
                "user_id": ctx.author.id,
                "message_id": restart_message.id,
                "prefix_command": True
            }
            
            with open("restart_status.json", "w") as f:
                json.dump(restart_info, f)
                
            # Short delay then restart using proper exit method
            await asyncio.sleep(1)
            
            # Force restart the workflow by raising SystemExit
            import sys
            import os
            
            # First try graceful shutdown
            try:
                await self.bot.close()
            except:
                pass
            
            # Exit with code 1 to trigger restart
            os._exit(1)
            
        except Exception as e:
            await ctx.send(f"❌ Restart failed: {str(e)}")

    async def cog_unload(self):
        """Clean up when cog is unloaded"""
        if self.http_session:
            await self.http_session.close()

async def setup(bot):
    await bot.add_cog(AdvancedFeatures(bot))