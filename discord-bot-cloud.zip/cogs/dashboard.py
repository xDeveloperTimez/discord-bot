"""
Dashboard commands for Guardian Bot
"""
import discord
from discord.ext import commands
from discord import app_commands

class Dashboard(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="dashboard", description="Get Guardian Bot server dashboard link")
    async def dashboard(self, interaction: discord.Interaction):
        """Get Guardian Bot server dashboard link with license verification"""
        try:
            # Send immediate response to prevent timeout
            user_id = interaction.user.id
            guild_id = interaction.guild.id if interaction.guild else None
            
            if not guild_id:
                await interaction.response.send_message("❌ This command can only be used in a server.", ephemeral=True)
                return
            
            # Check user license (bypass for owner)
            db_manager = self.bot.db_manager
            
            if user_id == 344210326251896834:
                # Owner has full access
                license_type = 'EXCLUSIVE'
            else:
                user_license = db_manager.get_user_license(user_id)
                
                if not user_license or user_license.status != 'ACTIVE':
                    embed = discord.Embed(
                        title="🔒 Dashboard Access Restricted",
                        description="Guardian Bot dashboard requires an active license.",
                        color=0xdc3545
                    )
                    embed.add_field(
                        name="💎 Get Access",
                        value="Purchase a license to access the dashboard:\n• Basic License: $4.99/month\n• Premium License: $9.99/month\n• Exclusive License: $19.99/month",
                        inline=False
                    )
                    embed.add_field(
                        name="🛒 Purchase",
                        value="Use `/purchase` command or visit our store",
                        inline=False
                    )
                    await interaction.response.send_message(embed=embed, ephemeral=True)
                    return
                
                license_type = user_license.license_type
            
            # Generate dashboard link with authentication
            dashboard_url = f"https://{self.replit_url}/dashboard?user_id={user_id}&guild_id={guild_id}"
            
            embed = discord.Embed(
                title="🎛️ Guardian Bot Dashboard",
                description="Access your server configuration dashboard",
                color=0x17a2b8
            )
            
            # Show available features based on license
            features = self.get_dashboard_features(license_type)
            
            embed.add_field(
                name=f"📋 Your License: {license_type}",
                value=f"Available dashboard features:\n{chr(10).join(features)}",
                inline=False
            )
            
            embed.add_field(
                name="🔗 Dashboard Link",
                value=f"[Open Dashboard]({dashboard_url})",
                inline=False
            )
            
            embed.add_field(
                name="⚠️ Security Notice",
                value="This link is personalized for your account. Do not share it with others.",
                inline=False
            )
            
            embed.set_footer(text="Dashboard access is restricted based on your license tier")
            
            await interaction.response.send_message(embed=embed, ephemeral=True)
            
        except Exception as e:
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(f"❌ Error generating dashboard link: {str(e)}", ephemeral=True)
                else:
                    await interaction.followup.send(f"❌ Error generating dashboard link: {str(e)}", ephemeral=True)
            except:
                pass

    @app_commands.command(name="customdashboard", description="Get custom bot management dashboard (for custom bot owners)")
    async def custom_dashboard(self, interaction: discord.Interaction):
        """Get custom bot management dashboard link"""
        try:
            user_id = interaction.user.id
            
            # Check if user has custom bots
            db_manager = self.bot.db_manager
            session = db_manager.get_session()
            
            try:
                from models import CustomBot
                custom_bots = session.query(CustomBot).filter_by(customer_id=user_id).all()
                
                # For demo/testing purposes, allow owner to access custom dashboard
                if not custom_bots and user_id == 344210326251896834:
                    # Show demo dashboard for owner
                    embed = discord.Embed(
                        title="🎛️ Custom Bot Dashboard (Demo)",
                        description="Manage your personalized Discord bots",
                        color=0x6f42c1
                    )
                    
                    demo_dashboard_url = f"https://{self.replit_url}/custom-dashboard?id=demo123&user_id={user_id}"
                    
                    embed.add_field(
                        name="🤖 Demo Custom Bot",
                        value=f"• [Demo CustomBot]({demo_dashboard_url}) - Status: online",
                        inline=False
                    )
                    
                    embed.add_field(
                        name="⚙️ Dashboard Features",
                        value="• Bot status monitoring\n• Restart and manage bot\n• Configure settings\n• Manage custom commands\n• View bot statistics",
                        inline=False
                    )
                    
                    embed.add_field(
                        name="⚠️ Demo Notice",
                        value="This is a demo dashboard for testing purposes.",
                        inline=False
                    )
                    
                    embed.set_footer(text="Custom Bot Dashboard - Demo Mode")
                    await interaction.response.send_message(embed=embed, ephemeral=True)
                    return
                
                if not custom_bots:
                    embed = discord.Embed(
                        title="🤖 No Custom Bots Found",
                        description="You don't have any custom bots to manage.",
                        color=0xdc3545
                    )
                    embed.add_field(
                        name="🛒 Get Custom Bot",
                        value="Purchase a Custom Bot Setup for $50 to get your own personalized Discord bot.",
                        inline=False
                    )
                    embed.add_field(
                        name="📞 Order Process",
                        value="Use `/purchase` command and select Custom Bot Setup option.",
                        inline=False
                    )
                    await interaction.response.send_message(embed=embed, ephemeral=True)
                    return
                
                # User has custom bots - show dashboard options
                embed = discord.Embed(
                    title="🎛️ Custom Bot Dashboard",
                    description="Manage your personalized Discord bots",
                    color=0x6f42c1
                )
                
                dashboard_links = []
                for bot in custom_bots:
                    dashboard_url = f"https://{self.replit_url}/custom-dashboard?id={bot.deployment_id}&user_id={user_id}"
                    dashboard_links.append(f"• [{bot.bot_name}]({dashboard_url}) - Status: {bot.status}")
                
                embed.add_field(
                    name="🤖 Your Custom Bots",
                    value="\n".join(dashboard_links),
                    inline=False
                )
                
                embed.add_field(
                    name="⚙️ Dashboard Features",
                    value="• Bot status monitoring\n• Restart and manage bot\n• Configure settings\n• Manage custom commands\n• View bot statistics",
                    inline=False
                )
                
                embed.add_field(
                    name="⚠️ Security Notice",
                    value="These links are personalized for your account. Do not share them with others.",
                    inline=False
                )
                
                embed.set_footer(text="Custom Bot Dashboard - Exclusive for Custom Bot owners")
                
                await interaction.response.send_message(embed=embed, ephemeral=True)
                
            finally:
                db_manager.close_session(session)
                
        except Exception as e:
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(f"❌ Error generating custom dashboard link: {str(e)}", ephemeral=True)
                else:
                    await interaction.followup.send(f"❌ Error generating custom dashboard link: {str(e)}", ephemeral=True)
            except:
                pass

    def get_dashboard_features(self, license_type):
        """Get available dashboard features based on license type"""
        features = {
            'BASIC': [
                "✅ Basic moderation settings",
                "✅ Logging configuration", 
                "✅ Auto-moderation toggles",
                "✅ Auto responses management"
            ],
            'PREMIUM': [
                "✅ Basic moderation settings",
                "✅ Logging configuration",
                "✅ Auto-moderation toggles", 
                "✅ Auto responses management",
                "✅ Anti-raid protection",
                "✅ Advanced moderation tools"
            ],
            'EXCLUSIVE': [
                "✅ Basic moderation settings",
                "✅ Logging configuration",
                "✅ Auto-moderation toggles",
                "✅ Auto responses management", 
                "✅ Anti-raid protection",
                "✅ Advanced moderation tools",
                "✅ Custom commands",
                "✅ Premium features access"
            ]
        }
        return features.get(license_type, features['BASIC'])

    @property
    def replit_url(self):
        """Get Replit URL for dashboard links"""
        import os
        return os.getenv('REPLIT_DEV_DOMAIN', 'localhost:5000')

async def setup(bot):
    await bot.add_cog(Dashboard(bot))