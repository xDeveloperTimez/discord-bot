"""
Enhanced spam functionality with button interface
"""

import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import random
from utils.security import SecurityManager

class SpamButton(discord.ui.View):
    def __init__(self, message, amount=5):
        super().__init__(timeout=300)
        self.message = message
        self.amount = amount

    @discord.ui.button(label="🚀 Spam", style=discord.ButtonStyle.red)
    async def spam_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        
        try:
            for i in range(self.amount):
                await interaction.followup.send(self.message)
                await asyncio.sleep(0.5)  # Rate limit protection
            
            embed = discord.Embed(
                title="✅ Spam Complete",
                description=f"Sent {self.amount} messages successfully",
                color=discord.Color.green()
            )
            await interaction.followup.send(embed=embed, ephemeral=True)
        except Exception as e:
            embed = discord.Embed(
                title="❌ Error",
                description=f"Failed to spam: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.followup.send(embed=embed, ephemeral=True)

class CleanupButton(discord.ui.View):
    def __init__(self, user_id, amount):
        super().__init__(timeout=300)
        self.user_id = user_id
        self.amount = amount

    @discord.ui.button(label="🗑️ Clean Messages", style=discord.ButtonStyle.secondary)
    async def cleanup_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("❌ You can't use this button!", ephemeral=True)
            return
            
        await interaction.response.defer(ephemeral=True)
        
        try:
            def is_user(m):
                return m.author.id == self.user_id
            
            deleted = await interaction.channel.purge(limit=self.amount, check=is_user)
            
            embed = discord.Embed(
                title="✅ Cleanup Complete",
                description=f"Deleted {len(deleted)} messages",
                color=discord.Color.green()
            )
            await interaction.followup.send(embed=embed, ephemeral=True)
        except Exception as e:
            embed = discord.Embed(
                title="❌ Error", 
                description=f"Failed to clean messages: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.followup.send(embed=embed, ephemeral=True)

class EnhancedSpam(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="spambutton", description="Create a spam button interface")
    @app_commands.describe(
        message="Message to spam",
        amount="Number of times to spam (max 10)"
    )
    async def spam_button(self, interaction: discord.Interaction, message: str, amount: int = 5):
        """Create a spam button interface"""
        if amount > 10:
            amount = 10
        elif amount < 1:
            amount = 1
            
        view = SpamButton(message, amount)
        
        embed = discord.Embed(
            title="💥 Spam Interface",
            description=f"**Message:** {message}\n**Amount:** {amount}",
            color=discord.Color.orange()
        )
        embed.add_field(name="Instructions", value="Click the button below to start spamming", inline=False)
        
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

    @app_commands.command(name="cleanmessages", description="Clean your recent messages")
    @app_commands.describe(amount="Number of your messages to delete (max 50)")
    async def clean_messages(self, interaction: discord.Interaction, amount: int = 10):
        """Clean user's recent messages with button interface"""
        if amount > 50:
            amount = 50
        elif amount < 1:
            amount = 1
            
        view = CleanupButton(interaction.user.id, amount)
        
        embed = discord.Embed(
            title="🗑️ Message Cleanup",
            description=f"Ready to delete your last {amount} messages",
            color=discord.Color.blue()
        )
        embed.add_field(name="Warning", value="This action cannot be undone!", inline=False)
        
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

    @app_commands.command(name="rapidspam", description="Send multiple messages quickly")
    @app_commands.describe(
        message="Message to send",
        count="Number of messages (max 20)",
        delay="Delay between messages in seconds"
    )
    async def rapid_spam(self, interaction: discord.Interaction, message: str, count: int = 5, delay: float = 1.0):
        """Send multiple messages with custom delay"""
        if count > 20:
            count = 20
        elif count < 1:
            count = 1
            
        if delay < 0.1:
            delay = 0.1
        elif delay > 10.0:
            delay = 10.0
            
        await interaction.response.defer(ephemeral=True)
        
        try:
            for i in range(count):
                await interaction.followup.send(f"{message}")
                if i < count - 1:  # Don't delay after the last message
                    await asyncio.sleep(delay)
            
            embed = discord.Embed(
                title="✅ Rapid Spam Complete",
                description=f"Sent {count} messages with {delay}s delay",
                color=discord.Color.green()
            )
            await interaction.followup.send(embed=embed, ephemeral=True)
        except Exception as e:
            embed = discord.Embed(
                title="❌ Error",
                description=f"Failed to send messages: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.followup.send(embed=embed, ephemeral=True)

async def setup(bot):
    await bot.add_cog(EnhancedSpam(bot))