"""
Music cog for Discord bot with voice channel support
"""

import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import yt_dlp
import os
from collections import deque
import logging
from utils.voice_manager import VoiceManager

# Suppress noise about console usage from errors
yt_dlp.utils.bug_reports_message = lambda: ''

ytdl_format_options = {
    'format': 'bestaudio/best',
    'outtmpl': '%(extractor)s-%(id)s-%(title)s.%(ext)s',
    'restrictfilenames': True,
    'noplaylist': False,  # Allow playlist extraction for better search results
    'nocheckcertificate': True,
    'ignoreerrors': False,
    'logtostderr': False,
    'quiet': True,
    'no_warnings': True,
    'default_search': 'ytsearch',  # Use YouTube search by default
    'source_address': '0.0.0.0',
    'extract_flat': False,  # Extract full metadata
}

ffmpeg_options = {
    'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5',
    'options': '-vn'
}

ytdl = yt_dlp.YoutubeDL(ytdl_format_options)

class YTDLSource(discord.PCMVolumeTransformer):
    def __init__(self, source, *, data, volume=0.5):
        super().__init__(source, volume)
        self.data = data
        self.title = data.get('title')
        self.url = data.get('url')
        self.duration = data.get('duration')
        self.uploader = data.get('uploader')

    @classmethod
    async def from_url(cls, url, *, loop=None, stream=False):
        loop = loop or asyncio.get_event_loop()
        data = await loop.run_in_executor(None, lambda: ytdl.extract_info(url, download=not stream))

        if 'entries' in data:
            # Take first item from a playlist
            data = data['entries'][0]

        filename = data['url'] if stream else ytdl.prepare_filename(data)
        return cls(discord.FFmpegPCMAudio(filename, **ffmpeg_options), data=data)

    @classmethod
    async def search_youtube(cls, query):
        """Search YouTube for a query and return the first result"""
        loop = asyncio.get_event_loop()
        try:
            # Use a properly configured search
            search_query = f"ytsearch1:{query}"
            data = await loop.run_in_executor(
                None, 
                lambda: ytdl.extract_info(search_query, download=False)
            )
            if data and 'entries' in data and len(data['entries']) > 0:
                return data['entries'][0]
        except Exception as e:
            print(f"Search error: {e}")
        return None

class MusicQueue:
    def __init__(self):
        self.queue = deque()
        self.current = None
        self.loop_mode = False

    def add(self, item):
        self.queue.append(item)

    def get_next(self):
        if self.loop_mode and self.current:
            return self.current
        if self.queue:
            self.current = self.queue.popleft()
            return self.current
        return None

    def clear(self):
        self.queue.clear()
        self.current = None

    def skip(self):
        if self.queue:
            self.current = self.queue.popleft()
            return self.current
        return None

    def toggle_loop(self):
        self.loop_mode = not self.loop_mode
        return self.loop_mode

class Music(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.queues = {}  # Guild-specific queues

    def get_queue(self, guild_id):
        if guild_id not in self.queues:
            self.queues[guild_id] = MusicQueue()
        return self.queues[guild_id]

    async def play_next(self, guild):
        """Play the next song in queue"""
        queue = self.get_queue(guild.id)
        next_song = queue.get_next()
        
        if next_song and guild.voice_client:
            try:
                source = await YTDLSource.from_url(next_song['url'], stream=True)
                guild.voice_client.play(source, after=lambda e: self.bot.loop.create_task(self.play_next(guild)) if e is None else print(f'Player error: {e}'))
                
                # Find a text channel to send now playing message
                for channel in guild.text_channels:
                    if channel.permissions_for(guild.me).send_messages:
                        embed = discord.Embed(
                            title="🎵 Now Playing",
                            description=f"**{source.title}**",
                            color=discord.Color.green()
                        )
                        if source.uploader:
                            embed.add_field(name="Uploader", value=source.uploader, inline=True)
                        if source.duration:
                            minutes = source.duration // 60
                            seconds = source.duration % 60
                            embed.add_field(name="Duration", value=f"{minutes}:{seconds:02d}", inline=True)
                        await channel.send(embed=embed)
                        break
            except Exception as e:
                print(f"Error playing next song: {e}")

    @app_commands.command(name="join", description="Join your voice channel")
    async def join(self, interaction: discord.Interaction):
        """Join the user's voice channel with improved stability"""
        if not interaction.user.voice:
            await interaction.response.send_message("❌ You need to be in a voice channel!", ephemeral=True)
            return

        channel = interaction.user.voice.channel
        
        # Send immediate response
        await interaction.response.send_message(f"🔄 Connecting to {channel.name}...")
        
        try:
            # Use VoiceManager for stable connection
            voice_client = await VoiceManager.connect_with_retry(channel, max_retries=2)
            await interaction.edit_original_response(content=f"✅ Successfully joined {channel.name}")
                
        except discord.ClientException as e:
            # Try emergency fallback for persistent WebSocket errors
            await interaction.edit_original_response(content=f"🚨 Attempting emergency connection...")
            emergency_client = await VoiceManager.emergency_connect(channel)
            
            if emergency_client:
                await interaction.edit_original_response(content=f"✅ Emergency connection successful to {channel.name}")
            else:
                # Provide detailed feedback about the issue
                embed = discord.Embed(
                    title="🔧 Voice Connection Issue",
                    description="Unable to establish stable voice connection due to Discord WebSocket errors (4006).\n\n"
                               "**This is a known Discord infrastructure issue that affects hosted bots.**\n\n"
                               "**Alternatives:**\n"
                               "• Try again in a few minutes\n"
                               "• Use voice commands when Discord's voice servers are more stable\n"
                               "• Consider using the bot during off-peak hours",
                    color=discord.Color.orange()
                )
                embed.add_field(
                    name="🎵 Music Features",
                    value="All other bot features work normally.\nMusic commands will retry automatically when voice improves.",
                    inline=False
                )
                await interaction.edit_original_response(content="", embed=embed)
                
        except Exception as e:
            await interaction.edit_original_response(content=f"❌ Failed to join {channel.name}: {str(e)}")

    @app_commands.command(name="leave", description="Leave the voice channel")
    async def leave(self, interaction: discord.Interaction):
        """Leave the voice channel with improved error handling"""
        if not interaction.guild.voice_client:
            await interaction.response.send_message("❌ Not connected to a voice channel!", ephemeral=True)
            return

        # Send immediate response
        await interaction.response.send_message("🔄 Disconnecting from voice channel...")
        
        try:
            # Clear queue and disconnect
            queue = self.get_queue(interaction.guild.id)
            queue.clear()
            
            await interaction.guild.voice_client.disconnect(force=True)
            await interaction.edit_original_response(content="✅ Successfully left the voice channel")
            
        except Exception as e:
            await interaction.edit_original_response(content=f"❌ Error disconnecting: {str(e)}")

    @app_commands.command(name="play", description="Play a song from YouTube")
    @app_commands.describe(query="Song name or YouTube URL")
    async def play(self, interaction: discord.Interaction, query: str):
        """Play a song from YouTube"""
        # Send immediate response
        await interaction.response.send_message("🔄 Searching for music...")

        if not interaction.user.voice:
            await interaction.edit_original_response(content="❌ You need to be in a voice channel!")
            return

        # Join voice channel if not already connected
        if not interaction.guild.voice_client:
            await interaction.edit_original_response(content="🔄 Joining voice channel...")
            try:
                channel = interaction.user.voice.channel
                await channel.connect()
            except Exception as e:
                await interaction.edit_original_response(content=f"❌ Failed to join voice channel: {str(e)}")
                return

        queue = self.get_queue(interaction.guild.id)

        try:
            # Search for the song
            await interaction.edit_original_response(content=f"🔍 Searching for: {query}")
            
            if not query.startswith('http'):
                search_result = await YTDLSource.search_youtube(query)
                if not search_result:
                    await interaction.edit_original_response(content="❌ No results found!")
                    return
                song_data = search_result
            else:
                # Direct URL
                loop = asyncio.get_event_loop()
                try:
                    song_data = await loop.run_in_executor(
                        None, 
                        lambda: ytdl.extract_info(query, download=False)
                    )
                    if 'entries' in song_data:
                        song_data = song_data['entries'][0]
                except Exception as e:
                    await interaction.edit_original_response(content=f"❌ Error processing URL: {str(e)}")
                    return

            # Add to queue
            queue.add(song_data)

            # If nothing is playing, start playing
            if not interaction.guild.voice_client.is_playing():
                await self.play_next(interaction.guild)
                embed = discord.Embed(
                    title="🎵 Now Playing",
                    description=f"**{song_data['title']}**",
                    color=discord.Color.green()
                )
            else:
                embed = discord.Embed(
                    title="📋 Added to Queue",
                    description=f"**{song_data['title']}**",
                    color=discord.Color.blue()
                )
                embed.add_field(name="Position", value=len(queue.queue), inline=True)

            if song_data.get('uploader'):
                embed.add_field(name="Uploader", value=song_data['uploader'], inline=True)
            if song_data.get('duration'):
                minutes = song_data['duration'] // 60
                seconds = song_data['duration'] % 60
                embed.add_field(name="Duration", value=f"{minutes}:{seconds:02d}", inline=True)

            await interaction.edit_original_response(content="", embed=embed)

        except Exception as e:
            await interaction.edit_original_response(content=f"❌ Error: {str(e)}")

    @app_commands.command(name="skip", description="Skip the current song")
    async def skip(self, interaction: discord.Interaction):
        """Skip the current song"""
        if not interaction.guild.voice_client or not interaction.guild.voice_client.is_playing():
            await interaction.response.send_message("❌ Nothing is playing!", ephemeral=True)
            return

        interaction.guild.voice_client.stop()
        
        embed = discord.Embed(
            title="⏭️ Skipped",
            description="Skipped the current song",
            color=discord.Color.orange()
        )
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="pause", description="Pause the current song")
    async def pause(self, interaction: discord.Interaction):
        """Pause the current song"""
        if not interaction.guild.voice_client or not interaction.guild.voice_client.is_playing():
            await interaction.response.send_message("❌ Nothing is playing!", ephemeral=True)
            return

        interaction.guild.voice_client.pause()
        
        embed = discord.Embed(
            title="⏸️ Paused",
            description="Paused the current song",
            color=discord.Color.orange()
        )
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="resume", description="Resume the current song")
    async def resume(self, interaction: discord.Interaction):
        """Resume the current song"""
        if not interaction.guild.voice_client or interaction.guild.voice_client.is_playing():
            await interaction.response.send_message("❌ Nothing is paused!", ephemeral=True)
            return

        interaction.guild.voice_client.resume()
        
        embed = discord.Embed(
            title="▶️ Resumed",
            description="Resumed the current song",
            color=discord.Color.green()
        )
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="queue", description="Show the current music queue")
    async def queue_command(self, interaction: discord.Interaction):
        """Show the current music queue"""
        queue = self.get_queue(interaction.guild.id)
        
        if not queue.queue and not queue.current:
            await interaction.response.send_message("📭 Queue is empty!", ephemeral=True)
            return

        embed = discord.Embed(
            title="📋 Music Queue",
            color=discord.Color.blue()
        )

        if queue.current:
            embed.add_field(
                name="🎵 Currently Playing",
                value=f"**{queue.current['title']}**",
                inline=False
            )

        if queue.queue:
            queue_list = []
            for i, song in enumerate(list(queue.queue)[:10], 1):  # Show max 10 songs
                queue_list.append(f"{i}. {song['title']}")
            
            embed.add_field(
                name="📝 Up Next",
                value="\n".join(queue_list),
                inline=False
            )
            
            if len(queue.queue) > 10:
                embed.add_field(
                    name="➕ More",
                    value=f"And {len(queue.queue) - 10} more songs...",
                    inline=False
                )

        embed.add_field(
            name="🔄 Loop Mode",
            value="✅ Enabled" if queue.loop_mode else "❌ Disabled",
            inline=True
        )

        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="clearqueue", description="Clear the music queue")
    async def clear_queue(self, interaction: discord.Interaction):
        """Clear the music queue"""
        queue = self.get_queue(interaction.guild.id)
        queue.clear()
        
        embed = discord.Embed(
            title="🗑️ Cleared",
            description="Cleared the music queue",
            color=discord.Color.red()
        )
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="loop", description="Toggle loop mode for the current song")
    async def loop(self, interaction: discord.Interaction):
        """Toggle loop mode"""
        queue = self.get_queue(interaction.guild.id)
        loop_status = queue.toggle_loop()
        
        embed = discord.Embed(
            title="🔄 Loop Mode",
            description=f"Loop mode {'enabled' if loop_status else 'disabled'}",
            color=discord.Color.green() if loop_status else discord.Color.red()
        )
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="volume", description="Change the music volume")
    @app_commands.describe(volume="Volume level (0-100)")
    async def volume(self, interaction: discord.Interaction, volume: int):
        """Change the music volume"""
        if not interaction.guild.voice_client:
            await interaction.response.send_message("❌ Not connected to voice!", ephemeral=True)
            return

        if not 0 <= volume <= 100:
            await interaction.response.send_message("❌ Volume must be between 0 and 100!", ephemeral=True)
            return

        if interaction.guild.voice_client.source:
            interaction.guild.voice_client.source.volume = volume / 100
        
        embed = discord.Embed(
            title="🔊 Volume Changed",
            description=f"Set volume to {volume}%",
            color=discord.Color.blue()
        )
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="nowplaying", description="Show currently playing song")
    async def nowplaying(self, interaction: discord.Interaction):
        """Show currently playing song"""
        if not interaction.guild.voice_client or not interaction.guild.voice_client.is_playing():
            await interaction.response.send_message("❌ Nothing is playing!", ephemeral=True)
            return

        queue = self.get_queue(interaction.guild.id)
        if not queue.current:
            await interaction.response.send_message("❌ Nothing is playing!", ephemeral=True)
            return

        song = queue.current
        embed = discord.Embed(
            title="🎵 Now Playing",
            description=f"**{song['title']}**",
            color=discord.Color.green()
        )
        
        if song.get('uploader'):
            embed.add_field(name="Uploader", value=song['uploader'], inline=True)
        if song.get('duration'):
            minutes = song['duration'] // 60
            seconds = song['duration'] % 60
            embed.add_field(name="Duration", value=f"{minutes}:{seconds:02d}", inline=True)
        
        embed.add_field(name="Loop Mode", value="✅ Enabled" if queue.loop_mode else "❌ Disabled", inline=True)
        
        if interaction.guild.voice_client.source:
            volume = int(interaction.guild.voice_client.source.volume * 100)
            embed.add_field(name="Volume", value=f"{volume}%", inline=True)

        await interaction.response.send_message(embed=embed)

async def setup(bot):
    await bot.add_cog(Music(bot))