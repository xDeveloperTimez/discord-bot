"""
Main bot class and setup
"""

import discord
from discord.ext import commands
import asyncio
import json
import os
from bot.config import BotConfig
from bot.database import Database
from database import db_manager

class ModBot(commands.Bot):
    def __init__(self):
        # Set up intents
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = True
        intents.guilds = True
        intents.reactions = True
        
        # Load configuration
        self.config = BotConfig()
        
        # Initialize bot with command prefix and intents
        super().__init__(
            command_prefix=self.config.get_prefix,
            intents=intents,
            help_command=None,
            case_insensitive=True
        )
        
        # Initialize database
        self.db = Database()
        self.db_manager = db_manager
        
        # Bot startup flag
        self.ready = False
        
        # Target server ID for user count status
        self.target_server_id = 1378215721611558952
    
    async def setup_hook(self):
        """Called when the bot is starting up"""
        print("Setting up bot...")
        
        # Load all cogs
        cogs = [
            'cogs.moderation',
            'cogs.utility', 
            'cogs.automod',
            'cogs.roles',
            'cogs.logging',
            'cogs.spam_new',
            'cogs.music',
            'cogs.selfbot_features',
            'cogs.enhanced_spam',
            'cogs.advanced_features',
            'cogs.server_cloning',
            'cogs.anti_raid',
            'cogs.licensing',
            'cogs.custom_bot_deployment',
            'cogs.dashboard'
        ]
        
        for cog in cogs:
            try:
                await self.load_extension(cog)
                print(f"✓ Loaded {cog}")
            except Exception as e:
                print(f"✗ Failed to load {cog}: {e}")
        
        # Sync slash commands
        try:
            synced = await self.tree.sync()
            print(f"✓ Synced {len(synced)} slash commands")
        except Exception as e:
            print(f"✗ Failed to sync commands: {e}")
    
    async def update_status(self):
        """Update bot status to show watching for attacks"""
        activity = discord.Activity(
            type=discord.ActivityType.watching,
            name="for attacks"
        )
        
        await self.change_presence(activity=activity)
    
    async def position_bot_role_top(self, guild):
        """Position the bot's role at the top of the role hierarchy"""
        try:
            bot_member = guild.me
            if not bot_member:
                return
                
            bot_roles = [role for role in bot_member.roles if role.name != "@everyone"]
            if not bot_roles:
                return
                
            # Get the bot's highest role
            bot_top_role = bot_member.top_role
            
            # Calculate the position to move to (just below the highest possible position)
            max_position = len(guild.roles) - 1
            target_position = max_position
            
            # Try to move the role to the top
            await bot_top_role.edit(position=target_position)
            print(f"✓ Positioned bot role '{bot_top_role.name}' at top of hierarchy in {guild.name}")
            
        except discord.Forbidden:
            print(f"⚠ Cannot position bot role at top in {guild.name} - insufficient permissions")
        except Exception as e:
            print(f"⚠ Error positioning bot role in {guild.name}: {e}")
    
    async def check_restart_status(self):
        """Check if bot was restarted and update the restart message accordingly"""
        import os
        import json
        
        if not os.path.exists("restart_status.json"):
            return
            
        try:
            with open("restart_status.json", "r") as f:
                restart_info = json.load(f)
                
            # Get the channel where restart was initiated
            channel_id = restart_info.get("channel_id")
            user_id = restart_info.get("user_id")
            failed = restart_info.get("failed", False)
            
            if not channel_id:
                return
                
            channel = self.get_channel(channel_id)
            if not channel:
                return
                
            if failed:
                # Restart failed, send error message
                error = restart_info.get("error", "Unknown error")
                embed = discord.Embed(
                    title="❌ Restart Failed",
                    description=f"Bot restart encountered an error:\n```{error}```",
                    color=discord.Color.red()
                )
                embed.add_field(name="Status", value="Bot is still running on previous session", inline=False)
            else:
                # Restart successful
                embed = discord.Embed(
                    title="✅ Restart Successful",
                    description="Bot has successfully restarted and is now online!",
                    color=discord.Color.green()
                )
                embed.add_field(name="Status", value="All systems operational", inline=False)
                embed.add_field(name="Uptime", value="Just restarted", inline=True)
                
            # Send the status message
            await channel.send(embed=embed)
            
            # Clean up the restart status file
            os.remove("restart_status.json")
            
        except Exception as e:
            print(f"Error checking restart status: {e}")
            # Clean up the file even if there was an error
            try:
                os.remove("restart_status.json")
            except:
                pass
    
    async def on_ready(self):
        """Called when the bot is ready"""
        if not self.ready:
            print(f"\n🤖 {self.user} is now online!")
            print(f"📊 Connected to {len(self.guilds)} guilds")
            print(f"👥 Serving {sum(guild.member_count or 0 for guild in self.guilds)} users")
            
            # Set bot status to show users from specific server
            await self.update_status()
            
            # Check for restart status and send success/failure message
            await self.check_restart_status()
            
            # Initialize database for all existing guilds and position bot roles
            for guild in self.guilds:
                self.db_manager.get_or_create_guild(guild.id, guild.name)
                await self.position_bot_role_top(guild)
            
            print(f"✓ Database initialized for {len(self.guilds)} guilds")
            
            self.ready = True
    
    async def on_guild_join(self, guild):
        """Called when bot joins a new guild"""
        print(f"✓ Joined new guild: {guild.name} ({guild.id})")
        
        # Initialize guild in database
        self.db_manager.get_or_create_guild(guild.id, guild.name)
        print(f"✓ Initialized database for guild: {guild.name}")
        
        # Automatically position bot role at the top
        await self.position_bot_role_top(guild)
        
        # Update status
        await self.update_status()
    
    async def on_guild_remove(self, guild):
        """Called when bot leaves a guild"""
        print(f"✗ Left guild: {guild.name} ({guild.id})")
        
        # Update status
        await self.update_status()
    
    async def on_command_error(self, ctx, error):
        """Global error handler"""
        if isinstance(error, commands.CommandNotFound):
            return
        
        if isinstance(error, commands.MissingPermissions):
            embed = discord.Embed(
                title="❌ Missing Permissions",
                description="You don't have permission to use this command.",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed, delete_after=10)
            return
        
        if isinstance(error, commands.BotMissingPermissions):
            embed = discord.Embed(
                title="❌ Bot Missing Permissions",
                description="I don't have the required permissions to execute this command.",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed, delete_after=10)
            return
        
        if isinstance(error, commands.MissingRequiredArgument):
            embed = discord.Embed(
                title="❌ Missing Argument",
                description=f"Missing required argument: `{error.param.name}`",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed, delete_after=10)
            return
        
        # Log unexpected errors
        print(f"Unexpected error in command {ctx.command}: {error}")
        
        embed = discord.Embed(
            title="❌ An Error Occurred",
            description="An unexpected error occurred while executing this command.",
            color=discord.Color.red()
        )
        await ctx.send(embed=embed, delete_after=10)
