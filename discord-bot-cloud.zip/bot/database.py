"""
Simple JSON-based database for storing bot data
"""

import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Any

class Database:
    def __init__(self):
        self.data_dir = "data"
        self.warnings_file = os.path.join(self.data_dir, "warnings.json")
        self.muted_users_file = os.path.join(self.data_dir, "muted_users.json")
        
        # Ensure data directory exists
        os.makedirs(self.data_dir, exist_ok=True)
        
        # Initialize data files
        self._init_file(self.warnings_file, {})
        self._init_file(self.muted_users_file, {})
    
    def _init_file(self, filepath: str, default_data: Any):
        """Initialize a data file if it doesn't exist"""
        if not os.path.exists(filepath):
            with open(filepath, 'w') as f:
                json.dump(default_data, f, indent=4)
    
    def _load_data(self, filepath: str) -> Any:
        """Load data from a JSON file"""
        try:
            with open(filepath, 'r') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return {}
    
    def _save_data(self, filepath: str, data: Any):
        """Save data to a JSON file"""
        try:
            with open(filepath, 'w') as f:
                json.dump(data, f, indent=4)
        except Exception as e:
            print(f"Error saving data to {filepath}: {e}")
    
    # Warning system methods
    def add_warning(self, guild_id: int, user_id: int, moderator_id: int, reason: str) -> int:
        """Add a warning to a user and return total warning count"""
        warnings = self._load_data(self.warnings_file)
        guild_key = str(guild_id)
        user_key = str(user_id)
        
        if guild_key not in warnings:
            warnings[guild_key] = {}
        
        if user_key not in warnings[guild_key]:
            warnings[guild_key][user_key] = []
        
        warning = {
            "timestamp": datetime.now().isoformat(),
            "moderator_id": moderator_id,
            "reason": reason
        }
        
        warnings[guild_key][user_key].append(warning)
        self._save_data(self.warnings_file, warnings)
        
        return len(warnings[guild_key][user_key])
    
    def get_warnings(self, guild_id: int, user_id: int) -> List[Dict]:
        """Get all warnings for a user"""
        warnings = self._load_data(self.warnings_file)
        guild_key = str(guild_id)
        user_key = str(user_id)
        
        if guild_key in warnings and user_key in warnings[guild_key]:
            return warnings[guild_key][user_key]
        return []
    
    def clear_warnings(self, guild_id: int, user_id: int) -> int:
        """Clear all warnings for a user and return the number cleared"""
        warnings = self._load_data(self.warnings_file)
        guild_key = str(guild_id)
        user_key = str(user_id)
        
        if guild_key in warnings and user_key in warnings[guild_key]:
            count = len(warnings[guild_key][user_key])
            del warnings[guild_key][user_key]
            self._save_data(self.warnings_file, warnings)
            return count
        return 0
    
    # Mute system methods
    def add_mute(self, guild_id: int, user_id: int, until: datetime = None):
        """Add a user to the muted users list"""
        muted_users = self._load_data(self.muted_users_file)
        guild_key = str(guild_id)
        user_key = str(user_id)
        
        if guild_key not in muted_users:
            muted_users[guild_key] = {}
        
        mute_data = {
            "muted_at": datetime.now().isoformat(),
            "until": until.isoformat() if until else None
        }
        
        muted_users[guild_key][user_key] = mute_data
        self._save_data(self.muted_users_file, muted_users)
    
    def remove_mute(self, guild_id: int, user_id: int):
        """Remove a user from the muted users list"""
        muted_users = self._load_data(self.muted_users_file)
        guild_key = str(guild_id)
        user_key = str(user_id)
        
        if guild_key in muted_users and user_key in muted_users[guild_key]:
            del muted_users[guild_key][user_key]
            self._save_data(self.muted_users_file, muted_users)
            return True
        return False
    
    def is_muted(self, guild_id: int, user_id: int) -> bool:
        """Check if a user is muted"""
        muted_users = self._load_data(self.muted_users_file)
        guild_key = str(guild_id)
        user_key = str(user_id)
        
        if guild_key in muted_users and user_key in muted_users[guild_key]:
            mute_data = muted_users[guild_key][user_key]
            
            # Check if mute has expired
            if mute_data.get("until"):
                until = datetime.fromisoformat(mute_data["until"])
                if datetime.now() >= until:
                    # Mute has expired, remove it
                    self.remove_mute(guild_id, user_id)
                    return False
            
            return True
        return False
    
    def get_expired_mutes(self, guild_id: int) -> List[int]:
        """Get list of user IDs whose mutes have expired"""
        muted_users = self._load_data(self.muted_users_file)
        guild_key = str(guild_id)
        expired = []
        
        if guild_key not in muted_users:
            return expired
        
        current_time = datetime.now()
        
        for user_id, mute_data in muted_users[guild_key].items():
            if mute_data.get("until"):
                until = datetime.fromisoformat(mute_data["until"])
                if current_time >= until:
                    expired.append(int(user_id))
        
        return expired
