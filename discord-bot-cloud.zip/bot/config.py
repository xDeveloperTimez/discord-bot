"""
Bot configuration management
"""

import json
import os
from typing import Union

class BotConfig:
    def __init__(self):
        self.config_path = "config/bot_config.json"
        self.default_config = {
            "prefix": "!",
            "log_channel": None,
            "mod_role": "Moderator",
            "admin_role": "Administrator",
            "mute_role": "Muted",
            "auto_role": None,
            "welcome_channel": None,
            "welcome_message": "Welcome to the server, {user}!",
            "max_warnings": 3,
            "warn_punishment": "mute",
            "delete_after_days": 7,
            "bot_owner_id": None
        }
        self.config = self.load_config()
    
    def load_config(self) -> dict:
        """Load configuration from JSON file"""
        try:
            with open(self.config_path, 'r') as f:
                config = json.load(f)
                # Merge with defaults for any missing keys
                for key, value in self.default_config.items():
                    if key not in config:
                        config[key] = value
                return config
        except FileNotFoundError:
            # Create config directory if it doesn't exist
            os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
            # Create default config file
            self.save_config(self.default_config)
            return self.default_config.copy()
        except json.JSONDecodeError:
            print(f"Error: Invalid JSON in {self.config_path}")
            return self.default_config.copy()
    
    def save_config(self, config: dict = None):
        """Save configuration to JSON file"""
        if config is None:
            config = self.config
        
        try:
            os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
            with open(self.config_path, 'w') as f:
                json.dump(config, f, indent=4)
        except Exception as e:
            print(f"Error saving config: {e}")
    
    def get(self, key: str, default=None):
        """Get a configuration value"""
        return self.config.get(key, default)
    
    def set(self, key: str, value):
        """Set a configuration value"""
        self.config[key] = value
        self.save_config()
    
    @property
    def prefix(self) -> str:
        """Get command prefix"""
        return self.config.get("prefix", "!")
    
    def get_prefix(self, bot, message) -> str:
        """Get command prefix for discord.py"""
        return self.prefix
    
    @property
    def log_channel(self) -> Union[int, None]:
        """Get log channel ID"""
        return self.config.get("log_channel")
    
    @property
    def mod_role(self) -> str:
        """Get moderator role name"""
        return self.config.get("mod_role", "Moderator")
    
    @property
    def admin_role(self) -> str:
        """Get administrator role name"""
        return self.config.get("admin_role", "Administrator")
    
    @property
    def mute_role(self) -> str:
        """Get mute role name"""
        return self.config.get("mute_role", "Muted")
    
    def bot_owner_id(self) -> int:
        """Get bot owner ID"""
        return self.config.get("bot_owner_id", None)
